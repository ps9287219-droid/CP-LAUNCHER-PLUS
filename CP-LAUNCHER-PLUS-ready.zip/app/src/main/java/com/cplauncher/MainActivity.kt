package com.cplauncher

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val background = Color.rgb(18, 22, 30)
    private val panel = Color.rgb(31, 38, 50)
    private val accent = Color.rgb(100, 210, 120)
    private var selectedVersion = "1.20.1"

    private fun addText(
        parent: LinearLayout,
        value: String,
        size: Float,
        color: Int = Color.WHITE,
        bold: Boolean = false
    ): TextView {
        val view = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            setPadding(12, 10, 12, 10)
            if (bold) setTypeface(null, Typeface.BOLD)
        }
        parent.addView(
            view,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        return view
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(
            button,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 5, 0, 5) }
        )
    }

    private fun addCard(parent: LinearLayout, heading: String, subtitle: String): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(panel)
        }
        parent.addView(
            card,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 10, 0, 10) }
        )
        addText(card, heading, 19f, accent, true)
        addText(card, subtitle, 14f, Color.LTGRAY)
        return card
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = background
        window.navigationBarColor = background

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 24)
            setBackgroundColor(background)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        addText(root, "⛏ CP LAUNCHER PLUS", 27f, accent, true)
        addText(root, "Minecraft Java Edition • Android", 15f, Color.LTGRAY)

        val status = addCard(root, "Launcher status", "Android launcher shell")
        addText(
            status,
            "The Android interface is ready to build. A compatible Java game runtime and legitimate game files are still required to play.",
            14f
        )

        val versions = addCard(root, "Game version", "Select a version to prepare")
        val selected = addText(versions, "Selected: $selectedVersion", 16f, accent)
        listOf("1.20.1", "1.19.4", "1.18.2").forEach { version ->
            addButton(versions, "Minecraft $version") {
                selectedVersion = version
                selected.text = "Selected: $selectedVersion"
            }
        }

        val play = addCard(root, "Play", "Choose a version above")
        addButton(play, "Prepare / Launch") {
            Toast.makeText(
                this,
                "Game runtime is not integrated yet. Selected: $selectedVersion",
                Toast.LENGTH_LONG
            ).show()
        }
        addButton(root, "Settings") {
            Toast.makeText(
                this,
                "Runtime and memory settings are planned for a later step.",
                Toast.LENGTH_SHORT
            ).show()
        }
        addButton(root, "About CP Launcher") {
            Toast.makeText(
                this,
                "CP Launcher Plus • Community project; not affiliated with Mojang or Microsoft.",
                Toast.LENGTH_LONG
            ).show()
        }
        addText(root, "Minecraft game files are not included.", 12f, Color.LTGRAY)
    }
}
