# CP-LAUNCHER-PLUS

Android launcher UI starter project with a GitHub Actions workflow to build a debug APK.

## Build APK
1. Push the project to GitHub.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and run the workflow, or push a commit to `main`.
4. Open the completed workflow run and download the `CP-LAUNCHER-PLUS-debug-apk` artifact.

## Important
This project currently builds a launcher UI shell. It does **not** include a Minecraft Java runtime, game assets, or Microsoft/Minecraft sign-in. The Play button is a placeholder until a compatible runtime and legitimate game files are integrated.
