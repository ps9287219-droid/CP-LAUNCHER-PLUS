# CP-LAUNCHER-PLUS

A professional Minecraft: **Java Edition** launcher for Android — original branding, original
implementation, inspired by the polish of CS Launcher v1.4.

This repository contains **two deliverables**:

| Path | What it is |
|---|---|
| `android/` | The complete Android app: Kotlin + Jetpack Compose UI, a real Minecraft launch pipeline, a native C JVM bridge, mod/shader/skin/account subsystems, Gradle KTS build files. |
| `src/`, `index.html` | A **control centre** web app that accompanies the launcher: it talks to the live Mojang and Modrinth APIs, resolves real download plans, builds genuine `.mrpack` modpacks, tracks playtime, browses every Android source file and exports the whole project as a buildable ZIP. |

> The web control centre is *not* a pretend launcher. It does the real preparatory work
> (manifest → version JSON → library/asset plan → JVM + game argument list) and then tells you
> honestly that starting the JVM needs the APK, because a browser tab cannot `dlopen` a shared
> library or spawn a process.

## Build the APK

### Easiest — GitHub Actions
1. Push this repository to `ps9287219-droid/CP-LAUNCHER-PLUS`.
2. `.github/workflows/android-build.yml` installs JDK 17 + Android SDK 35 + Gradle 8.9, runs
   `assembleDebug` and `assembleRelease`, uploads both APKs as artifacts and attaches them to a
   GitHub release on `main`.
3. Optional secret: `MS_CLIENT_ID` — an Azure **public client** application id that enables
   Microsoft device-code sign-in.

### Locally
```bash
cd android
gradle :app:assembleDebug      # android/app/build/outputs/apk/debug/app-debug.apk
```
Requires JDK 17, Android SDK 35 and the NDK/CMake (for `app/src/main/cpp/cp_jvm.c`).

## Feature status (honest)

### Implemented
* Premium dark launcher UI (Compose + Material 3), phone **and** tablet layouts, accent themes, animations, DataStore persistence.
* Version browsing from Mojang's piston-meta v2 manifest; full installer (client jar, libraries with OS rule evaluation, asset index + objects, natives) with SHA-1 verification and parallel downloads.
* Android OpenJDK runtime manager (arm64-v8a / x86_64, GPLv2+CE builds, tar.xz extraction, executable bits, per-version Java requirement).
* **Real game launch**: `cp_jvm.c` `dlopen`s `libjvm.so` and calls `JNI_CreateJavaVM`, then invokes the version's main class with generated JVM/game arguments; subprocess fallback; stdout/err piped to the UI; crash reports on non-zero exit.
* JVM/game argument construction, `options.txt` generation from performance settings, memory clamped to the device's real Java heap.
* Microsoft device-code OAuth → XBL → XSTS → Minecraft Services → profile + entitlement check; Keystore-encrypted token storage; multi-account switching; refresh.
* Local/offline profiles, clearly separated and clearly labelled.
* Skins: import, model detection (classic/slim from the PNG alpha), official upload to `/minecraft/profile/skins`; cape display for authenticated profiles with an explicit warning about vanilla servers.
* Mods: Modrinth v2 search, version resolution, SHA-1 verified download, required-dependency resolution, real placement in `games/<profile>/mods`, enable/disable via `.disabled`, delete, backup/restore, duplicate-id + missing-dependency audit from `fabric.mod.json` / `mods.toml`.
* Loaders: Fabric and Quilt install end-to-end via their meta APIs; Forge/NeoForge metadata + installer download and execution.
* Shaders/resource packs: install into the real folders, import ZIPs, graphics presets, and a renderer capability matrix that refuses to promise shader support the chain cannot deliver.
* Performance centre: profiles (Low/Balanced/High/Custom), FPS limit, render/simulation distance, particles, entity distance, UI scale, memory, optimisation-mod recommendations, thermal + RAM warnings.
* Playtime tracking (foreground service, per-session and per-day history), Discord screen with an IPC probe, deep-link hand-off and full explanation of Android's limits.
* Crash logs, diagnostics export, reset.

### Partial
* **Forge/NeoForge** — installer download + run implemented; a few versions need extra native post-processing.
* **Shaders** — the chain is validated and packs are installed correctly; visual quality depends on the device GPU driver.
* **Frame-time/FPS reporting** — parsed from the game's own log; Android does not expose another process's GPU timings.
* **Discord Rich Presence** — the desktop IPC socket does not exist on Android. Implemented: socket probe with the documented op-code protocol, session/playtime tracking, share hand-off. It never reports "connected" unless a handshake succeeds.

### Not supported (never faked)
* Increasing physical RAM, "RAM cleaner" buttons, background-app killing.
* Custom capes visible on vanilla multiplayer servers.
* Minecraft Java on 32-bit ABIs.
* Requesting or storing Microsoft passwords or Discord user tokens.

## Legal
Game files are fetched **only** from Mojang's official endpoints and only for versions the user
can already play. Mods come from Modrinth under their own licences. OpenJDK Android builds are
GPLv2 with the Classpath exception. Not affiliated with Mojang or Microsoft.
