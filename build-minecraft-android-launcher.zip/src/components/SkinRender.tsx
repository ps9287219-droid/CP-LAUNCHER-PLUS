import { useEffect, useRef, useState } from "react";
import { cn } from "@/utils/cn";

/**
 * Isometric 2.5D character renderer drawn from a real 64x64 Minecraft skin PNG.
 * Nothing is faked: the pixels come from the skin file (Crafatar/Mojang), the model
 * (classic vs slim) is detected from the alpha channel of the arm second layer.
 */
export function SkinRender({ skinUrl, size = 260, className }: { skinUrl: string | null; size?: number; className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [model, setModel] = useState<"classic" | "slim">("classic");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!skinUrl) return;
    let cancelled = false;
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      if (cancelled) return;
      const canvas = canvasRef.current;
      if (!canvas) return;
      // Slim models have transparent pixels in the 4th column of the arm layer.
      const probe = document.createElement("canvas");
      probe.width = img.width;
      probe.height = img.height;
      const pctx = probe.getContext("2d");
      pctx?.drawImage(img, 0, 0);
      let slim = false;
      if (img.width === 64 && pctx) {
        const data = pctx.getImageData(54, 20, 2, 12).data;
        let transparent = 0;
        for (let i = 3; i < data.length; i += 4) if (data[i] === 0) transparent++;
        slim = transparent > 6;
      }
      setModel(slim ? "slim" : "classic");
      draw(canvas, img, slim);
    };
    img.onerror = () => setError("Skin could not be loaded (offline or CORS blocked)");
    img.src = skinUrl;
    return () => {
      cancelled = true;
    };
  }, [skinUrl]);

  return (
    <div className={cn("flex flex-col items-center", className)}>
      <canvas ref={canvasRef} width={size} height={size * 1.15} className="floaty" />
      <div className="mono mt-2 flex items-center gap-2 text-[10px] uppercase tracking-widest text-[var(--muted)]">
        <span className={model === "slim" ? "accent-text" : ""}>{model}</span>
        <span>·</span>
        <span>64×64</span>
        <span>·</span>
        <span>real pixels</span>
      </div>
      {error && <p className="mt-1 text-[11px] text-amber-300">{error}</p>}
    </div>
  );
}

function draw(canvas: HTMLCanvasElement, img: HTMLImageElement, slim: boolean) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.imageSmoothingEnabled = false;

  const s = canvas.width / 90; // pixel scale
  const armW = slim ? 3 : 4;
  const cx = canvas.width / 2;

  const px = (sx: number, sy: number, sw: number, sh: number, dx: number, dy: number, dw: number, dh: number, depth = 0) => {
    ctx.drawImage(img, sx, sy, sw, sh, dx, dy, dw, dh);
    if (depth) {
      ctx.fillStyle = `rgba(0,0,0,${depth})`;
      ctx.fillRect(dx, dy, dw, dh);
    }
  };

  // Back shadow / platform
  ctx.fillStyle = "rgba(63,212,106,0.06)";
  ctx.beginPath();
  ctx.ellipse(cx, canvas.height * 0.9, 60 * s, 12 * s, 0, 0, Math.PI * 2);
  ctx.fill();

  const headTop = canvas.height * 0.1;

  // HEAD (front, 8x8 at 16,16) with right/left side shading
  px(8, 8, 8, 8, cx - 8 * s, headTop, 8 * s, 8 * s);
  px(24, 8, 8, 8, cx - 8 * s, headTop, 8 * s, 8 * s, 0); // hat layer
  px(0, 8, 8, 8, cx - 16 * s, headTop + 1 * s, 8 * s, 8 * s, 0.22); // right side
  px(16, 8, 8, 8, cx + 8 * s, headTop + 1 * s, 8 * s, 8 * s, 0.32); // left side
  px(8, 0, 8, 8, cx - 8 * s, headTop - 6 * s, 8 * s, 6 * s, 0.15); // top

  // BODY front (20,20 8x12)
  px(20, 20, 8, 12, cx - 8 * s, headTop + 10 * s, 16 * s, 24 * s);
  px(20, 36, 8, 12, cx - 8 * s, headTop + 10 * s, 16 * s, 24 * s, 0); // jacket layer

  // ARMS
  const armWpx = armW * 2 * s;
  px(44, 20, armW, 12, cx + 8 * s, headTop + 10 * s, armWpx, 24 * s, 0.1);
  px(44, 36, armW, 12, cx + 8 * s, headTop + 10 * s, armWpx, 24 * s);
  px(36, 20, armW, 12, cx - 8 * s - armWpx, headTop + 10 * s, armWpx, 24 * s, 0.18);
  px(36, 36, armW, 12, cx - 8 * s - armWpx, headTop + 10 * s, armWpx, 24 * s);

  // LEGS
  px(4, 20, 4, 12, cx - 8 * s, headTop + 34 * s, 8 * s, 24 * s, 0.12);
  px(4, 36, 4, 12, cx - 8 * s, headTop + 34 * s, 8 * s, 24 * s);
  px(12, 20, 4, 12, cx, headTop + 34 * s, 8 * s, 24 * s, 0.2);
  px(12, 36, 4, 12, cx, headTop + 34 * s, 8 * s, 24 * s);
}

/** Head-only render used in small profile chips. */
export function SkinHead({ url, size = 40, className }: { url: string; size?: number; className?: string }) {
  return (
    <span className={className}>
      <PixelFace url={url} size={size} />
    </span>
  );
}

function PixelFace({ url, size }: { url: string; size: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const c = ref.current;
      const ctx = c?.getContext("2d");
      if (!c || !ctx) return;
      ctx.imageSmoothingEnabled = false;
      ctx.clearRect(0, 0, c.width, c.height);
      ctx.drawImage(img, 8, 8, 8, 8, 0, 0, size, size);
      ctx.drawImage(img, 40, 8, 8, 8, 0, 0, size, size); // hat layer
    };
    img.src = url;
  }, [url, size]);
  return <canvas ref={ref} width={size} height={size} style={{ imageRendering: "pixelated", borderRadius: 8 }} />;
}

export function skinUrlFor(uuid: string) {
  return `https://crafatar.com/skins/${uuid}?overlay`;
}
export function bodyRenderUrl(uuid: string) {
  return `https://crafatar.com/renders/body/${uuid}?overlay`;
}
export function avatarFor(name: string) {
  return `https://mc-heads.net/avatar/${encodeURIComponent(name)}/64`;
}
