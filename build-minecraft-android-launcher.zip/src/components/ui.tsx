import type { ReactNode } from "react";
import { cn } from "@/utils/cn";

export function Panel({ children, className, title, subtitle, action }: { children?: ReactNode; className?: string; title?: string; subtitle?: string; action?: ReactNode }) {
  return (
    <section className={cn("panel p-4 sm:p-5", className)}>
      {(title || action) && (
        <header className="mb-3 flex items-start justify-between gap-3">
          <div>
            {title && <h3 className="text-sm font-semibold tracking-wide text-[var(--text)]">{title}</h3>}
            {subtitle && <p className="mt-0.5 text-xs text-[var(--muted)]">{subtitle}</p>}
          </div>
          {action}
        </header>
      )}
      {children}
    </section>
  );
}

export function SectionTitle({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <div className="mb-2 flex items-center justify-between">
      <h2 className="mono text-[11px] font-bold uppercase tracking-[0.18em] accent-text">{children}</h2>
      {right}
    </div>
  );
}

export function Pill({ children, tone = "accent" }: { children: ReactNode; tone?: "accent" | "warn" | "danger" | "muted" | "info" }) {
  const tones: Record<string, string> = {
    accent: "border-[var(--accent-line)] text-[var(--accent)] bg-[var(--accent-soft)]",
    warn: "border-amber-400/40 text-amber-300 bg-amber-400/10",
    danger: "border-red-400/40 text-red-300 bg-red-400/10",
    info: "border-sky-400/40 text-sky-300 bg-sky-400/10",
    muted: "border-[var(--line)] text-[var(--muted)] bg-white/5",
  };
  return (
    <span className={cn("mono inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider", tones[tone])}>
      {children}
    </span>
  );
}

export function Button({
  children,
  onClick,
  variant = "primary",
  className,
  disabled,
  title,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "outline" | "danger";
  className?: string;
  disabled?: boolean;
  title?: string;
}) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold transition-all disabled:cursor-not-allowed disabled:opacity-40";
  const styles: Record<string, string> = {
    primary: "accent-bg text-black hover:brightness-110 active:scale-[0.98]",
    outline: "border hairline text-[var(--text)] hover:bg-white/5",
    ghost: "text-[var(--muted)] hover:text-[var(--text)] hover:bg-white/5",
    danger: "border border-red-400/40 text-red-300 hover:bg-red-400/10",
  };
  return (
    <button title={title} disabled={disabled} onClick={onClick} className={cn(base, styles[variant], className)}>
      {children}
    </button>
  );
}

export function Chip({ active, onClick, children }: { active?: boolean; onClick?: () => void; children: ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
        active ? "border-[var(--accent-line)] bg-[var(--accent-soft)] text-[var(--accent)]" : "border-[var(--line)] text-[var(--muted)] hover:text-[var(--text)]",
      )}
    >
      {children}
    </button>
  );
}

export function Progress({ value, indeterminate, label, right }: { value?: number; indeterminate?: boolean; label?: string; right?: string }) {
  return (
    <div className="w-full">
      {(label || right) && (
        <div className="mb-1 flex items-center justify-between gap-2 text-xs">
          <span className="truncate text-[var(--text)]">{label}</span>
          <span className="mono shrink-0 text-[var(--muted)]">{right}</span>
        </div>
      )}
      <div className="h-2 w-full overflow-hidden rounded-full bg-white/8">
        {indeterminate ? (
          <div className="relative h-full w-1/3 overflow-hidden rounded-full accent-bg sweep" />
        ) : (
          <div className="h-full rounded-full accent-bg transition-[width] duration-300" style={{ width: `${Math.min(100, Math.max(0, (value ?? 0) * 100))}%` }} />
        )}
      </div>
    </div>
  );
}

export function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  suffix = "",
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  suffix?: string;
  onChange: (v: number) => void;
}) {
  return (
    <label className="block py-2">
      <div className="mb-1.5 flex items-center justify-between">
        <span className="text-sm">{label}</span>
        <span className="mono text-sm font-bold accent-text">
          {value}
          {suffix}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/10 accent-[var(--accent)]"
        style={{ accentColor: "var(--accent)" }}
      />
    </label>
  );
}

export function Toggle({ label, hint, checked, onChange }: { label: string; hint?: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-start justify-between gap-4 py-2">
      <div>
        <div className="text-sm">{label}</div>
        {hint && <div className="mt-0.5 text-xs leading-relaxed text-[var(--muted)]">{hint}</div>}
      </div>
      <button
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn("relative h-6 w-11 shrink-0 rounded-full border transition-colors", checked ? "accent-bg border-transparent" : "border-[var(--line)] bg-white/8")}
      >
        <span className={cn("absolute top-0.5 h-4.5 w-4.5 rounded-full bg-white transition-all", checked ? "left-[22px]" : "left-0.5")} style={{ height: 18, width: 18 }} />
      </button>
    </div>
  );
}

export function TextField({ label, value, onChange, placeholder, mono, multiline }: { label?: string; value: string; onChange: (v: string) => void; placeholder?: string; mono?: boolean; multiline?: boolean }) {
  const cls = cn(
    "w-full rounded-xl border hairline bg-black/30 px-3 py-2 text-sm outline-none placeholder:text-[var(--muted)] focus:border-[var(--accent-line)]",
    mono && "mono text-xs",
  );
  return (
    <label className="block">
      {label && <span className="mb-1 block text-xs text-[var(--muted)]">{label}</span>}
      {multiline ? (
        <textarea value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className={cn(cls, "min-h-24 resize-y")} />
      ) : (
        <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className={cls} />
      )}
    </label>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="rounded-xl border border-dashed hairline px-4 py-8 text-center text-xs text-[var(--muted)]">{children}</div>;
}

export function Stat({ label, value, tone }: { label: string; value: string; tone?: "accent" | "plain" }) {
  return (
    <div>
      <div className={cn("mono text-base font-bold", tone === "accent" ? "accent-text" : "text-[var(--text)]")}>{value}</div>
      <div className="text-[11px] text-[var(--muted)]">{label}</div>
    </div>
  );
}

export function Code({ children, className }: { children: ReactNode; className?: string }) {
  return <pre className={cn("scroll-thin mono overflow-auto rounded-xl border hairline bg-black/40 p-3 text-[11px] leading-relaxed text-[var(--text)]", className)}>{children}</pre>;
}
