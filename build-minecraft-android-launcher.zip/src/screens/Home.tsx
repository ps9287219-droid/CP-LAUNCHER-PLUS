import { useEffect, useState } from "react";
import { formatBytes, formatDuration } from "@/lib/api";
import { PERFORMANCE_PROFILES } from "@/lib/store";
import { useLauncher } from "@/lib/useLauncher";
import { Button, Code, Empty, Panel, Pill, Progress, Stat } from "@/components/ui";
import { SkinRender, skinUrlFor } from "@/components/SkinRender";
import { cn } from "@/utils/cn";

const NEWS = [
  {
    title: "Build pipeline",
    body: "GitHub Actions assembles debug + release APKs on every push and uploads them as artifacts. See Source & Build for the workflow file.",
    tag: "CI",
  },
  {
    title: "Real launch path",
    body: "cp_jvm.c dlopens libjvm.so and calls JNI_CreateJavaVM — the same route Pojav-family launchers use, because Android 10+ blocks exec() from app data.",
    tag: "Runtime",
  },
  {
    title: "Modrinth integration",
    body: "Search, version resolution, SHA-1 verified downloads and required-dependency resolution are all live against the public Modrinth v2 API.",
    tag: "Mods",
  },
  {
    title: "Discord: the honest version",
    body: "Android sandboxes apps, so the desktop Rich Presence pipe does not exist here. The launcher ships a socket probe, session tracking and a share hand-off.",
    tag: "Integrations",
  },
];

export function HomeScreen({ onNavigate }: { onNavigate: (tab: string) => void }) {
  const { activeProfile, activeAccount, launch, runPlay, sessionActive, sessionSeconds, endSession, device, profiles, installedRuntimes, play, totalSeconds, manifestLive, versions } = useLauncher();
  const [busy, setBusy] = useState(false);
  const blocked = launch.stage === "blocked" || launch.stage === "failed";
  const runtimeReady = installedRuntimes.includes(`jre${activeProfile?.javaMajor ?? 17}-arm64`);

  const recent = [...profiles].sort((a, b) => b.lastPlayed - a.lastPlayed).slice(0, 4);

  useEffect(() => () => undefined, []);

  return (
    <div className="space-y-5 fade-up">
      <div className="grid gap-5 lg:grid-cols-[1.35fr_1fr]">
        <Panel className="relative overflow-hidden">
          <div className="grid-bg pointer-events-none absolute inset-0 opacity-60" />
          <div className="relative">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h1 className="mono text-lg font-black tracking-[0.2em] accent-text">CP LAUNCHER PLUS</h1>
                <p className="text-xs text-[var(--muted)]">Minecraft: Java Edition · Android runtime control centre</p>
              </div>
              <Pill tone={sessionActive ? "accent" : blocked ? "warn" : "muted"}>
                {sessionActive ? "IN GAME" : blocked ? launch.stage : "READY"}
              </Pill>
            </div>

            <div className="flex flex-col items-center py-2">
              <div className="relative flex items-center justify-center">
                <div className="pulse-glow absolute h-56 w-56 rounded-full" style={{ background: "radial-gradient(circle, var(--accent) 0%, transparent 70%)" }} />
                <button
                  onClick={async () => {
                    setBusy(true);
                    await runPlay();
                    setBusy(false);
                  }}
                  disabled={busy}
                  className={cn(
                    "relative z-10 flex h-44 w-44 flex-col items-center justify-center rounded-full border-4 transition-all active:scale-95",
                    "border-[var(--accent-line)] bg-gradient-to-b from-[color-mix(in_srgb,var(--accent)_92%,white)] to-[color-mix(in_srgb,var(--accent)_65%,black)] text-black",
                    "accent-glow",
                  )}
                >
                  <span className="mono text-3xl font-black tracking-tight">{busy ? "…" : "PLAY"}</span>
                  <span className="mt-0.5 text-[11px] font-semibold opacity-80">
                    {activeProfile ? `${activeProfile.loader} ${activeProfile.mcVersion}` : "no profile"}
                  </span>
                </button>
              </div>

              <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                <Pill tone={runtimeReady ? "accent" : "warn"}>{runtimeReady ? "runtime ready" : "runtime missing"}</Pill>
                <Pill tone={manifestLive ? "accent" : "warn"}>{manifestLive ? "mojang manifest live" : "manifest fallback"}</Pill>
                <Pill tone={activeAccount?.kind === "microsoft" ? "accent" : "muted"}>{activeAccount ? `${activeAccount.kind} account` : "no account"}</Pill>
              </div>

              <div className="mt-3 flex gap-2">
                <Button variant="outline" onClick={() => onNavigate("library")}>Change version</Button>
                <Button variant="outline" onClick={() => onNavigate("diagnostics")}>Live log</Button>
                {sessionActive ? <Button variant="danger" onClick={endSession}>End session</Button> : null}
              </div>
            </div>

            {launch.stage !== "idle" && (
              <div className="mt-4 space-y-2">
                <Progress
                  value={launch.progress}
                  indeterminate={launch.indeterminate}
                  label={launch.label}
                  right={launch.plan ? formatBytes(launch.plan.totalBytes) : `${Math.round(launch.progress * 100)}%`}
                />
                {launch.problems.map((p, i) => (
                  <p key={i} className="text-xs leading-relaxed text-amber-300/90">• {p}</p>
                ))}
              </div>
            )}
          </div>
        </Panel>

        <div className="space-y-5">
          <Panel title="Player" subtitle="Real profile data — avatar pixels come from the skin file">
            <div className="flex items-start gap-4">
              {activeAccount ? (
                <SkinRender skinUrl={skinUrlFor(activeAccount.uuid)} size={150} />
              ) : (
                <div className="flex h-[180px] flex-1 flex-col items-center justify-center gap-2 text-center">
                  <div className="text-3xl">🧍</div>
                  <p className="max-w-48 text-xs text-[var(--muted)]">
                    Add a Microsoft account or an offline profile to see the isometric skin preview.
                  </p>
                  <Button variant="outline" onClick={() => onNavigate("accounts")}>Add account</Button>
                </div>
              )}
              <div className="flex-1 space-y-1">
                <div className="text-lg font-semibold">{activeAccount?.name ?? "No account"}</div>
                <div className="text-xs text-[var(--muted)]">
                  {activeAccount
                    ? activeAccount.kind === "microsoft"
                      ? activeAccount.ownsGame
                        ? "Microsoft · Java Edition entitlement verified"
                        : "Microsoft · no Java entitlement found"
                      : "Local (offline) profile — not a Minecraft account"
                    : "Sign in to use your Minecraft account"}
                </div>
                {activeAccount && <div className="mono break-all text-[10px] text-[var(--muted)]">{activeAccount.uuid}</div>}
                <div className="pt-2">
                  <Pill tone={activeAccount?.kind === "microsoft" ? "accent" : "muted"}>
                    {activeAccount?.kind === "microsoft" ? "MSA" : activeAccount ? "LOCAL" : "NONE"}
                  </Pill>
                </div>
              </div>
            </div>
          </Panel>

          <Panel title="Session statistics">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Stat label="Total playtime" value={formatDuration(totalSeconds)} tone="accent" />
              <Stat label="Sessions" value={String(play.length)} />
              <Stat label="This session" value={formatDuration(sessionSeconds)} />
              <Stat label="Heap cap here" value={`${device.heapLimitMb} MB`} />
            </div>
            <div className="mt-3 flex flex-wrap gap-1.5">
              <Pill tone="muted">{device.abi}</Pill>
              <Pill tone="muted">{device.cores} cores</Pill>
              <Pill tone="muted">~{device.totalRamGb} GB RAM</Pill>
              <Pill tone="muted">recommended {PERFORMANCE_PROFILES[device.recommendedProfile].renderDistance} chunks</Pill>
            </div>
          </Panel>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Panel title="Recent installations" action={<Button variant="ghost" onClick={() => onNavigate("library")}>Manage →</Button>}>
          {recent.length === 0 ? (
            <Empty>No installations yet.</Empty>
          ) : (
            <ul className="space-y-2">
              {recent.map((p) => (
                <li key={p.id} className="panel-2 flex items-center justify-between px-3 py-2">
                  <div>
                    <div className="text-sm">{p.name}</div>
                    <div className="text-[11px] text-[var(--muted)]">
                      {p.loader} · {p.mcVersion} · {formatDuration(p.totalPlaySeconds)}
                    </div>
                  </div>
                  {p.plannedBytes ? <span className="mono text-[11px] accent-text">{formatBytes(p.plannedBytes)}</span> : null}
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel title="Launcher news" subtitle="What changed and what is genuinely wired up">
          <ul className="space-y-2">
            {NEWS.map((n) => (
              <li key={n.title} className="panel-2 p-3">
                <div className="mb-1 flex items-center gap-2">
                  <span className="text-sm font-semibold">{n.title}</span>
                  <Pill tone="muted">{n.tag}</Pill>
                </div>
                <p className="text-xs leading-relaxed text-[var(--muted)]">{n.body}</p>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[11px] text-[var(--muted)]">
            Version index: {versions.length} entries {manifestLive ? "(live from piston-meta)" : "(offline fallback)"}.
          </p>
        </Panel>
      </div>

      {launch.commandPreview.length > 0 && (
        <Panel title="Launch plan — exact command line the Android app will execute" subtitle="Generated from real Mojang metadata">
          <Code className="max-h-72">{launch.commandPreview.join("\n")}</Code>
        </Panel>
      )}
    </div>
  );
}
