import { useMemo, useState } from "react";
import { formatBytes, formatDuration, triggerDownload } from "@/lib/api";
import { SOURCE_FILES, SOURCE_TOTAL_BYTES, SOURCE_TOTAL_LINES } from "@/lib/source";
import { useLauncher } from "@/lib/useLauncher";
import { Button, Code, Empty, Panel, Pill, Progress, SectionTitle, Stat, Toggle } from "@/components/ui";
import { cn } from "@/utils/cn";

const LEVEL_TONE: Record<string, string> = {
  info: "text-[var(--muted)]",
  ok: "text-[var(--accent)]",
  warn: "text-amber-300",
  error: "text-red-300",
  net: "text-sky-300",
};

export function DiagnosticsScreen() {
  const { logs, launch, planCache, device, play, totalSeconds, sessionSeconds, sessionActive, endSession, settings, patchSettings, resetSettings, clearCart, cart } = useLauncher();
  const [filter, setFilter] = useState<string>("all");

  const shown = useMemo(() => (filter === "all" ? logs : logs.filter((l) => l.level === filter)), [logs, filter]);
  const totalTransferred = Object.values(planCache).reduce((n, p) => n + p.totalBytes, 0);

  return (
    <div className="grid gap-5 lg:grid-cols-[1.4fr_1fr] fade-up">
      <div className="space-y-5">
        <Panel
          title="Live log"
          subtitle={`${logs.length} entries · everything this console did, including what it refused to do`}
          action={
            <div className="flex flex-wrap gap-1">
              {["all", "net", "ok", "warn", "error"].map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={cn(
                    "mono rounded-full border px-2 py-0.5 text-[10px] uppercase",
                    filter === f ? "border-[var(--accent-line)] text-[var(--accent)]" : "border-[var(--line)] text-[var(--muted)]",
                  )}
                >
                  {f}
                </button>
              ))}
            </div>
          }
        >
          <div className="scroll-thin max-h-[420px] overflow-auto rounded-xl border hairline bg-black/40 p-3">
            {shown.length === 0 ? (
              <Empty>No entries for this filter.</Empty>
            ) : (
              <ul className="mono space-y-1 text-[11px] leading-relaxed">
                {shown.slice().reverse().map((l, i) => (
                  <li key={i} className="flex gap-2">
                    <span className="shrink-0 text-[var(--muted)]">{new Date(l.ts).toLocaleTimeString()}</span>
                    <span className={cn("shrink-0 uppercase", LEVEL_TONE[l.level])}>{l.level}</span>
                    <span className="break-all text-[var(--text)]">{l.text}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div className="mt-3 flex gap-2">
            <Button
              variant="outline"
              onClick={() =>
                triggerDownload(
                  new Blob(
                    [
                      [
                        "CP Launcher Plus — diagnostics export",
                        `Generated: ${new Date().toISOString()}`,
                        `Device: ${device.abi}, ${device.cores} cores, ~${device.totalRamGb} GB`,
                        `Active profile: ${settings.activeProfileId}`,
                        `Renderer: ${settings.renderer} · heap ${settings.maxMemoryMb} MB`,
                        "",
                        ...logs.map((l) => `[${new Date(l.ts).toISOString()}] ${l.level.toUpperCase()} ${l.text}`),
                      ].join("\n"),
                    ],
                    { type: "text/plain" },
                  ),
                  "cp-launcher-plus-diagnostics.txt",
                )
              }
            >
              Export diagnostics
            </Button>
            <Button variant="outline" onClick={() => triggerDownload(new Blob([JSON.stringify(settings, null, 2)], { type: "application/json" }), "cp-launcher-settings.json")}>
              Export settings JSON
            </Button>
            <Button variant="danger" onClick={() => { clearCart(); resetSettings(); }}>Reset everything</Button>
          </div>
        </Panel>

        <Panel title="Session & playtime" subtitle="Local only — nothing is uploaded">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Total" value={formatDuration(totalSeconds)} tone="accent" />
            <Stat label="Sessions" value={String(play.length)} />
            <Stat label="Live" value={formatDuration(sessionSeconds)} />
            <Stat label="State" value={sessionActive ? "running" : "stopped"} />
          </div>
          <div className="mt-3 flex gap-2">
            {sessionActive ? <Button variant="danger" onClick={endSession}>End session</Button> : <Pill tone="muted">no live session</Pill>}
          </div>
          {play.length > 0 && (
            <div className="mt-3">
              <SectionTitle>History</SectionTitle>
              <ul className="space-y-1">
                {play.slice(-8).reverse().map((p, i) => (
                  <li key={i} className="panel-2 flex items-center justify-between px-3 py-1.5 text-xs">
                    <span>{p.version} · {p.loader}</span>
                    <span className="mono text-[var(--muted)]">{formatDuration(p.seconds)}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </Panel>
      </div>

      <div className="space-y-5">
        <Panel title="Last launch" subtitle={launch.stage}>
          <Progress value={launch.progress} indeterminate={launch.indeterminate} label={launch.label} right={launch.plan ? formatBytes(launch.plan.totalBytes) : `${Math.round(launch.progress * 100)}%`} />
          {launch.problems.length > 0 && (
            <ul className="mt-3 space-y-1">
              {launch.problems.map((p, i) => (
                <li key={i} className="text-[11px] leading-relaxed text-amber-300/90">• {p}</li>
              ))}
            </ul>
          )}
          {launch.commandPreview.length > 0 && <Code className="mt-3 max-h-52">{launch.commandPreview.join("\n")}</Code>}
        </Panel>

        <Panel title="Resolved download plans" subtitle={`${Object.keys(planCache).length} version(s) resolved from Mojang`}>
          {Object.keys(planCache).length === 0 ? (
            <Empty>Resolve a version from the Library tab.</Empty>
          ) : (
            <ul className="space-y-2">
              {Object.values(planCache).map((p) => (
                <li key={p.id} className="panel-2 p-3 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="mono font-bold accent-text">{p.id}</span>
                    <span className="mono text-[var(--muted)]">{formatBytes(p.totalBytes)}</span>
                  </div>
                  <div className="mt-1 text-[11px] text-[var(--muted)]">
                    Java {p.javaMajor} · {p.libraries.length} libraries · {p.assetCount} assets · main {p.mainClass.split(".").pop()}
                  </div>
                  <div className="mt-1 text-[11px] text-[var(--muted)]">
                    {p.libraries.filter((l) => l.desktopOnly).length} desktop-only artefacts (LWJGL/GLFW/OpenAL) are replaced by Android ports at launch time.
                  </div>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-3 text-[11px] text-[var(--muted)]">
            Total planned transfer: {formatBytes(totalTransferred)} · install plan: {cart.length} mod file(s)
          </p>
        </Panel>

        <Panel title="Preferences">
          <Toggle label="Advanced log detail" checked={settings.showAdvancedLogs} onChange={(v) => patchSettings({ showAdvancedLogs: v })} hint="Include full argument lists and rule evaluation in the log" />
          <Toggle label="Discord presence attempt" checked={settings.discordPresence} onChange={(v) => patchSettings({ discordPresence: v })} hint="Off by default. Android exposes no Discord IPC socket." />
          <Toggle label="Auto-refresh version list" checked={settings.autoUpdate} onChange={(v) => patchSettings({ autoUpdate: v })} />
        </Panel>

        <Panel title="Source bundle" subtitle="The complete Android project, exportable as a ZIP">
          <div className="grid grid-cols-3 gap-3">
            <Stat label="Files" value={String(SOURCE_FILES.length)} tone="accent" />
            <Stat label="Lines" value={SOURCE_TOTAL_LINES.toLocaleString()} />
            <Stat label="Size" value={formatBytes(SOURCE_TOTAL_BYTES)} />
          </div>
        </Panel>
      </div>
    </div>
  );
}
