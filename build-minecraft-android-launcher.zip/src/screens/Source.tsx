import { useMemo, useState } from "react";
import JSZip from "jszip";
import { formatBytes, triggerDownload } from "@/lib/api";
import { SOURCE_FILES, SOURCE_TOTAL_BYTES, SOURCE_TOTAL_LINES, TREE, findFile, type TreeNode } from "@/lib/source";
import { useLauncher } from "@/lib/useLauncher";
import { Button, Code, Empty, Panel, Pill, Stat } from "@/components/ui";
import { cn } from "@/utils/cn";

export function SourceScreen() {
  const { log } = useLauncher();
  const [selected, setSelected] = useState<string>(findDefault());
  const [expanded, setExpanded] = useState<Record<string, boolean>>({ android: true, "android/app": true, "android/app/src": true });
  const [zipping, setZipping] = useState(false);
  const [query, setQuery] = useState("");

  const file = findFile(selected);
  const matches = useMemo(
    () => (query ? SOURCE_FILES.filter((f) => f.path.toLowerCase().includes(query.toLowerCase())).slice(0, 40) : []),
    [query],
  );

  async function exportZip() {
    setZipping(true);
    try {
      const zip = new JSZip();
      SOURCE_FILES.forEach((f) => zip.file(f.path, f.content));
      zip.file(
        "HOW-TO-BUILD.md",
        [
          "# Building CP-LAUNCHER-PLUS",
          "",
          "1. Install JDK 17 and the Android SDK (API 35) — or just push this folder to GitHub;",
          "   `.github/workflows/android-build.yml` builds both APKs automatically and uploads them",
          "   as artifacts, then attaches them to a release on `main`.",
          "",
          "2. Local build:",
          "```",
          "cd android",
          "gradle :app:assembleDebug",
          "# output: android/app/build/outputs/apk/debug/app-debug.apk",
          "```",
          "",
          "3. Optional: set the `MS_CLIENT_ID` gradle property (or GitHub secret) to your Azure",
          "   public-client application id to enable Microsoft device-code sign-in.",
          "",
          "4. The native JVM bridge needs the NDK + CMake (installed by Android Studio by default):",
          "   android/app/src/main/cpp/cp_jvm.c -> libcplauncher_jvm.so",
          "",
          "See android/README.md for the honest feature-status table.",
        ].join("\n"),
      );
      const blob = await zip.generateAsync({ type: "blob", compression: "DEFLATE" });
      triggerDownload(blob, "CP-LAUNCHER-PLUS-source.zip");
      log("ok", `Exported CP-LAUNCHER-PLUS-source.zip (${SOURCE_FILES.length} files, ${formatBytes(SOURCE_TOTAL_BYTES)})`);
    } finally {
      setZipping(false);
    }
  }

  return (
    <div className="space-y-5 fade-up">
      <Panel
        title="Android project — full source"
        subtitle={`${SOURCE_FILES.length} files · ${SOURCE_TOTAL_LINES.toLocaleString()} lines · Kotlin, Compose, C (JNI), Gradle KTS, CI`}
        action={<Button onClick={() => void exportZip()} disabled={zipping}>{zipping ? "Zipping…" : "Download source ZIP"}</Button>}
      >
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Stat label="Kotlin files" value={String(SOURCE_FILES.filter((f) => f.language === "kotlin").length)} tone="accent" />
          <Stat label="Native C" value={String(SOURCE_FILES.filter((f) => f.language === "c").length)} />
          <Stat label="Gradle/CI" value={String(SOURCE_FILES.filter((f) => ["kotlin-dsl", "properties", "yaml"].includes(f.language)).length)} />
          <Stat label="Total size" value={formatBytes(SOURCE_TOTAL_BYTES)} />
        </div>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <div className="panel-2 p-3 text-[11px] leading-relaxed text-[var(--muted)]">
            <strong className="text-[var(--text)]">1 · Clone or unzip</strong>
            <p className="mt-1">Push the contents to your repo, or unzip locally and open <span className="mono">android/</span> in Android Studio.</p>
          </div>
          <div className="panel-2 p-3 text-[11px] leading-relaxed text-[var(--muted)]">
            <strong className="text-[var(--text)]">2 · CI builds the APK</strong>
            <p className="mt-1">GitHub Actions installs JDK 17 + SDK 35 + Gradle 8.9, runs <span className="mono">assembleDebug/Release</span> and uploads artifacts.</p>
          </div>
          <div className="panel-2 p-3 text-[11px] leading-relaxed text-[var(--muted)]">
            <strong className="text-[var(--text)]">3 · Optional secrets</strong>
            <p className="mt-1"><span className="mono">MS_CLIENT_ID</span> enables the Microsoft device-code flow with your own Azure app registration.</p>
          </div>
        </div>
      </Panel>

      <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
        <Panel title="Project tree">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter files…"
            className="mono mb-2 w-full rounded-xl border hairline bg-black/30 px-3 py-2 text-[11px] outline-none focus:border-[var(--accent-line)]"
          />
          {query ? (
            <ul className="scroll-thin max-h-[520px] space-y-0.5 overflow-auto pr-1">
              {matches.map((f) => (
                <li key={f.path}>
                  <button
                    onClick={() => setSelected(f.path)}
                    className={cn("mono w-full truncate rounded-lg px-2 py-1 text-left text-[11px] hover:bg-white/5", selected === f.path && "bg-[var(--accent-soft)] text-[var(--accent)]")}
                  >
                    {f.path}
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="scroll-thin max-h-[520px] overflow-auto pr-1">
              <Node node={TREE} selected={selected} onSelect={setSelected} expanded={expanded} setExpanded={setExpanded} depth={0} />
            </div>
          )}
        </Panel>

        <Panel
          title={file?.path ?? "Select a file"}
          subtitle={file ? `${file.language} · ${file.lines} lines · ${formatBytes(file.size)}` : undefined}
          action={file ? <Button variant="outline" onClick={() => triggerDownload(new Blob([file.content], { type: "text/plain" }), file.path.split("/").pop() ?? "file.txt")}>Download file</Button> : null}
        >
          {file ? (
            <Code className="max-h-[560px] text-[10.5px] leading-[1.6]">{file.content}</Code>
          ) : (
            <Empty>Choose a file from the tree.</Empty>
          )}
          <div className="mt-3 flex flex-wrap gap-1.5">
            <Pill tone="accent">Apache-2.0 style project layout</Pill>
            <Pill tone="muted">Game files only ever come from Mojang</Pill>
            <Pill tone="muted">Mods from Modrinth under their own licences</Pill>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function findDefault() {
  return (
    SOURCE_FILES.find((f) => f.path.endsWith("core/launch/GameLauncher.kt"))?.path ??
    SOURCE_FILES[0]?.path ??
    ""
  );
}

function Node({ node, selected, onSelect, expanded, setExpanded, depth }: { node: TreeNode; selected: string; onSelect: (p: string) => void; expanded: Record<string, boolean>; setExpanded: (e: Record<string, boolean>) => void; depth: number }) {
  const isDir = node.children.length > 0;
  const open = expanded[node.path] ?? depth < 2;
  return (
    <div>
      <button
        onClick={() => (isDir ? setExpanded({ ...expanded, [node.path]: !open }) : onSelect(node.path))}
        className={cn(
          "mono flex w-full items-center gap-1 rounded-lg px-2 py-1 text-left text-[11px] hover:bg-white/5",
          selected === node.path && "bg-[var(--accent-soft)] text-[var(--accent)]",
        )}
        style={{ paddingLeft: 8 + depth * 10 }}
      >
        <span className="text-[var(--muted)]">{isDir ? (open ? "▾" : "▸") : "·"}</span>
        <span className="truncate">{node.name}</span>
        {!isDir && <span className="ml-auto shrink-0 text-[9px] text-[var(--muted)]">{Math.round((node.file?.size ?? 0) / 1024)}k</span>}
      </button>
      {isDir && open && node.children.map((c) => <Node key={c.path} node={c} selected={selected} onSelect={onSelect} expanded={expanded} setExpanded={setExpanded} depth={depth + 1} />)}
    </div>
  );
}
