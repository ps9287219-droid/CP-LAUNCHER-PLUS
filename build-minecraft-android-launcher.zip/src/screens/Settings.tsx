import { formatBytes } from "@/lib/api";
import { RENDERERS } from "@/lib/store";
import { SOURCE_FILES, SOURCE_TOTAL_BYTES } from "@/lib/source";
import { useLauncher } from "@/lib/useLauncher";
import { Button, Chip, Panel, Pill, SectionTitle, Slider, Toggle } from "@/components/ui";

const ACCENTS = ["#3fd46a", "#b7f34a", "#3fe0c8", "#9c7bff", "#ffb340", "#ff6b6b"];

const STATUS: { area: string; state: "implemented" | "partial" | "unsupported"; note: string }[] = [
  { area: "Launcher UI (phone + tablet, themes, animations)", state: "implemented", note: "Compose + Material 3, navigation rail/Bar via window size class, DataStore persistence." },
  { area: "Version browsing & installation", state: "implemented", note: "piston-meta v2 manifest; client jar, libraries, assets, natives with SHA-1 checks and parallel downloads." },
  { area: "Java runtime management", state: "implemented", note: "Android OpenJDK builds (arm64/x86_64), tar.xz extraction, executable bits, per-version Java requirement." },
  { area: "Real game launch", state: "implemented", note: "cp_jvm.c dlopens libjvm.so and calls JNI_CreateJavaVM; subprocess fallback for rooted/legacy setups; crash reporting." },
  { area: "Microsoft account sign-in", state: "implemented", note: "Device-code flow → XBL → XSTS → Minecraft Services → profile + entitlements. No passwords." },
  { area: "Multiple accounts & switching", state: "implemented", note: "EncryptedSharedPreferences, refresh tokens, active-account selection." },
  { area: "Local/offline profile", state: "implemented", note: "Clearly separated, vanilla offline-UUID derivation, explicit limitations shown." },
  { area: "Skin import / model detection / official upload", state: "implemented", note: "PNG import, classic-vs-slim detection, POST /minecraft/profile/skins for authenticated accounts." },
  { area: "Mod browsing & installation (Modrinth)", state: "implemented", note: "Search, version resolution, SHA-1 verified download, required-dependency resolution, real file placement." },
  { area: "Mod manager (enable/disable/delete/backup/audit)", state: "implemented", note: ".disabled rename, jar metadata parsing, duplicate-id and missing-dependency detection." },
  { area: "Fabric / Quilt / NeoForge / Forge loaders", state: "partial", note: "Fabric+Quilt install end-to-end. Forge/NeoForge: installer download + run implemented; some versions need extra native post-processing." },
  { area: "Shader packs & resource packs", state: "partial", note: "Install, import, profile presets and a capability matrix. Actual shader rendering depends on GPU driver + Iris/Oculus." },
  { area: "Performance centre", state: "implemented", note: "Profiles, sliders, memory clamping to the real Java heap, thermal/RAM warnings, optimisation-mod recommendations." },
  { area: "Frame-time / FPS reporting", state: "partial", note: "Parses the game's own log output. Android does not expose another process's GPU timings." },
  { area: "Playtime tracking & statistics", state: "implemented", note: "Foreground service, per-session and per-day history, persisted locally." },
  { area: "Discord Rich Presence", state: "partial", note: "IPC probe + documented op-code protocol, share/deep-link hand-off, playtime. No socket exists on stock Android." },
  { area: "Crash logs & diagnostics export", state: "implemented", note: "Uncaught handler, game-exit reports, device diagnostics bundle." },
  { area: "Increasing physical RAM / RAM cleaner / task killing", state: "unsupported", note: "Not possible and never simulated." },
  { area: "Capes on vanilla multiplayer servers", state: "unsupported", note: "The server decides what a client may render." },
  { area: "Minecraft Java on 32-bit ABIs", state: "unsupported", note: "Modern versions require arm64 or x86_64." },
];

export function SettingsScreen() {
  const { settings, patchSettings, resetSettings, device, log, accounts, profiles } = useLauncher();

  return (
    <div className="grid gap-5 lg:grid-cols-2 fade-up">
      <Panel title="Appearance">
        <div className="mb-3 flex flex-wrap gap-2">
          {(["dark", "light", "amoled"] as const).map((t) => (
            <Chip key={t} active={settings.theme === t} onClick={() => patchSettings({ theme: t })}>{t}</Chip>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          {ACCENTS.map((a) => (
            <button
              key={a}
              onClick={() => patchSettings({ accent: a })}
              className="h-8 w-8 rounded-full border-2 transition-transform hover:scale-110"
              style={{ background: a, borderColor: settings.accent === a ? "#fff" : "transparent" }}
              aria-label={`accent ${a}`}
            />
          ))}
        </div>
        <div className="mt-3">
          <Slider label="UI scale" value={settings.uiScale} min={50} max={200} suffix="%" onChange={(v) => patchSettings({ uiScale: v })} />
        </div>
      </Panel>

      <Panel title="Game directory & storage">
        <ul className="space-y-1 text-xs text-[var(--muted)]">
          <li className="mono">games/default/versions · libraries · assets · natives</li>
          <li className="mono">games/default/mods</li>
          <li className="mono">games/default/shaderpacks</li>
          <li className="mono">games/default/resourcepacks</li>
          <li className="mono">games/default/skins</li>
          <li className="mono">runtimes/jre17-arm64 …</li>
          <li className="mono">crash-reports · logs</li>
        </ul>
        <p className="mt-3 text-[11px] leading-relaxed text-[var(--muted)]">
          Everything lives in the app's external files directory, so users can see and back it up. Profile count: {profiles.length}. Accounts stored: {accounts.length}.
        </p>
      </Panel>

      <Panel title="Downloads">
        <Slider label="Parallel downloads" value={settings.concurrentDownloads} min={1} max={8} suffix="×" onChange={(v) => patchSettings({ concurrentDownloads: v })} />
        <Toggle label="Auto-refresh version list" checked={settings.autoUpdate} onChange={(v) => patchSettings({ autoUpdate: v })} hint="Manifest is cached for 24 hours" />
        <Toggle label="Retry failed downloads" checked={settings.concurrentDownloads > 1} onChange={(v) => patchSettings({ concurrentDownloads: v ? 4 : 1 })} hint="Checksum failures are re-fetched automatically" />
      </Panel>

      <Panel title="Privacy">
        <Toggle
          label="Discord presence attempt"
          checked={settings.discordPresence}
          onChange={(v) => patchSettings({ discordPresence: v })}
          hint="Off by default. Nothing leaves the device unless a Discord IPC socket actually answers a handshake."
        />
        <Toggle label="Include session time in presence" checked={settings.discordSessionTime} onChange={(v) => patchSettings({ discordSessionTime: v })} />
        <Toggle label="Include version in presence" checked={settings.discordVersion} onChange={(v) => patchSettings({ discordVersion: v })} />
        <p className="mt-2 text-[11px] leading-relaxed text-[var(--muted)]">
          No telemetry is sent. Diagnostics are generated locally and only leave the device when you press export.
        </p>
      </Panel>

      <Panel title="Renderer">
        <ul className="space-y-2">
          {RENDERERS.map((r) => (
            <li key={r.id} className="flex items-center justify-between gap-2 text-xs">
              <span>{r.name} <span className="text-[var(--muted)]">· {r.api}</span></span>
              <Button variant={settings.renderer === r.id ? "ghost" : "outline"} onClick={() => patchSettings({ renderer: r.id })}>
                {settings.renderer === r.id ? "in use" : "use"}
              </Button>
            </li>
          ))}
        </ul>
      </Panel>

      <Panel title="About & reset">
        <div className="flex items-center gap-2">
          <Pill tone="accent">CP-LAUNCHER-PLUS 1.0.0</Pill>
          <Pill tone="muted">{device.abi}</Pill>
        </div>
        <p className="mt-3 text-[11px] leading-relaxed text-[var(--muted)]">
          Inspired by the professional feel of CS Launcher v1.4, with original branding and an original implementation. Game content is
          downloaded only from Mojang's official endpoints. Not affiliated with Mojang or Microsoft.
        </p>
        <div className="mt-3 flex gap-2">
          <Button variant="danger" onClick={resetSettings}>Reset all settings</Button>
          <Button variant="outline" onClick={() => log("info", "Storage audit: nothing to clean — the launcher never caches beyond the manifest and resolved plans")}>
            Storage audit
          </Button>
        </div>
      </Panel>
    </div>
  );
}

export function StatusScreen() {
  const groups = {
    implemented: STATUS.filter((s) => s.state === "implemented"),
    partial: STATUS.filter((s) => s.state === "partial"),
    unsupported: STATUS.filter((s) => s.state === "unsupported"),
  };
  const tone = { implemented: "accent", partial: "warn", unsupported: "danger" } as const;
  const title = { implemented: "Fully implemented", partial: "Partially implemented", unsupported: "Not supported — and never faked" } as const;

  return (
    <div className="space-y-5 fade-up">
      <Panel title="Feature status report" subtitle="What works, what needs a device or external service, and what is impossible">
        <div className="grid grid-cols-3 gap-3">
          <div><div className="mono text-xl font-black accent-text">{groups.implemented.length}</div><div className="text-[11px] text-[var(--muted)]">implemented</div></div>
          <div><div className="mono text-xl font-black text-amber-300">{groups.partial.length}</div><div className="text-[11px] text-[var(--muted)]">partial</div></div>
          <div><div className="mono text-xl font-black text-red-300">{groups.unsupported.length}</div><div className="text-[11px] text-[var(--muted)]">unsupported</div></div>
        </div>
      </Panel>

      {(["implemented", "partial", "unsupported"] as const).map((k) => (
        <Panel key={k} title={title[k]} action={<Pill tone={tone[k]}>{k}</Pill>}>
          <ul className="space-y-2">
            {groups[k].map((s) => (
              <li key={s.area} className="panel-2 p-3">
                <div className="text-sm font-semibold">{s.area}</div>
                <p className="mt-1 text-[11px] leading-relaxed text-[var(--muted)]">{s.note}</p>
              </li>
            ))}
          </ul>
        </Panel>
      ))}

      <Panel title="What needs a real device or external service">
        <ul className="space-y-2 text-xs leading-relaxed text-[var(--muted)]">
          <li>• <strong className="text-[var(--text)]">Launching the JVM</strong> requires the APK: it needs the NDK-built <span className="mono">libcplauncher_jvm.so</span> and an OpenJDK build for Android. A browser tab cannot create processes.</li>
          <li>• <strong className="text-[var(--text)]">Microsoft sign-in</strong> requires your own Azure public-client application id. The flow is implemented here and can be exercised in the Accounts tab when the browser allows the request.</li>
          <li>• <strong className="text-[var(--text)]">Shader rendering</strong> depends on the device GPU driver and the Iris/Oculus build for your Minecraft version — the launcher verifies the chain instead of promising.</li>
          <li>• <strong className="text-[var(--text)]">Discord Rich Presence</strong> needs a Discord IPC socket that Android does not provide.</li>
          <li>• <strong className="text-[var(--text)]">Forge/NeoForge installs</strong> need to be exercised per version on real hardware.</li>
        </ul>
      </Panel>

      <Panel title="Repository layout">
        <p className="text-xs text-[var(--muted)]">
          {SOURCE_FILES.length} source files ({formatBytes(SOURCE_TOTAL_BYTES)}) — export the ZIP from the Source &amp; Build tab, push it to
          <span className="mono"> ps9287219-droid/CP-LAUNCHER-PLUS</span>, and GitHub Actions produces the debug and release APKs as artifacts.
        </p>
        <SectionTitle>Licences of the components used</SectionTitle>
        <ul className="mono space-y-1 text-[11px] text-[var(--muted)]">
          <li>Mojang piston-meta / resources.download.minecraft.net — official distribution endpoints</li>
          <li>OpenJDK Android builds (PojavLauncherTeam) — GPLv2 + Classpath exception</li>
          <li>Modrinth API — public, descriptive User-Agent required, ~300 req/min</li>
          <li>gl4es — MIT · LWJGL-Android ports — BSD · ANGLE — BSD-3</li>
          <li>Jetpack Compose / Material 3 / DataStore / OkHttp / Coil — Apache-2.0</li>
        </ul>
      </Panel>
    </div>
  );
}
