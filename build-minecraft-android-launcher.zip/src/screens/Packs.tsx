import { useState } from "react";
import { formatBytes } from "@/lib/api";
import { RENDERERS } from "@/lib/store";
import { useLauncher } from "@/lib/useLauncher";
import { Button, Chip, Empty, Panel, Pill, Progress, SectionTitle, Slider, Toggle } from "@/components/ui";
import type { PackEntry } from "@/lib/types";

type Kind = PackEntry["kind"];

export function PacksScreen() {
  const { settings, patchSettings, activeProfile, cart, addToCart, log } = useLauncher();
  const [kind, setKind] = useState<Kind>("shader");
  const [query, setQuery] = useState(kind === "shader" ? "complementary" : "faithful");
  const [hits, setHits] = useState<PackEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState<{ label: string; loaded: number; total: number } | null>(null);
  void setProgress;

  const renderer = RENDERERS.find((r) => r.id === settings.renderer) ?? RENDERERS[0];
  const shaderCapable = renderer.shaders;
  const mcVersion = activeProfile?.mcVersion ?? "1.21.4";

  async function search() {
    setLoading(true);
    setHits([]);
    try {
      const { modrinthSearch, modrinthVersions } = await import("@/lib/api");
      const results = await modrinthSearch(query, kind, mcVersion, []);
      const mapped: PackEntry[] = await Promise.all(
        results.slice(0, 12).map(async (h) => {
          let size = 0;
          try {
            const v = await modrinthVersions(h.slug, kind === "resourcepack" ? mcVersion : null, []);
            size = v[0]?.size ?? 0;
          } catch {
            /* size unknown */
          }
          return {
            name: h.title,
            fileName: h.slug,
            kind,
            sizeBytes: size,
            compatible: kind === "resourcepack" ? true : shaderCapable,
            requiresRenderer: kind === "shader" ? "zink_vulkan" : undefined,
            description: h.description,
          };
        }),
      );
      setHits(mapped);
      log("net", `Modrinth ${kind} search → ${mapped.length} results for ${mcVersion}`);
    } catch (e) {
      log("error", `Pack search failed: ${(e as Error).message}`);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid gap-5 lg:grid-cols-[1.4fr_1fr] fade-up">
      <Panel title="Shader packs & resource packs" subtitle="Installed into games/<profile>/shaderpacks and /resourcepacks">
        <div className="mb-3 flex gap-2">
          <Chip active={kind === "shader"} onClick={() => { setKind("shader"); setQuery("complementary"); }}>Shaders</Chip>
          <Chip active={kind === "resourcepack"} onClick={() => { setKind("resourcepack"); setQuery("faithful"); }}>Resource packs</Chip>
        </div>

        {kind === "shader" && (
          <div className={`mb-3 rounded-xl border p-3 ${shaderCapable ? "border-[var(--accent-line)] bg-[var(--accent-soft)]" : "border-amber-400/40 bg-amber-400/5"}`}>
            <div className="flex items-center gap-2">
              <Pill tone={shaderCapable ? "accent" : "warn"}>{shaderCapable ? "shader capable" : "not shader capable"}</Pill>
              <span className="text-xs">{renderer.name}</span>
            </div>
            <p className="mt-1.5 text-[11px] leading-relaxed text-[var(--muted)]">
              {shaderCapable
                ? "This renderer exposes desktop-GL features, so a shader pack can render — provided a shader mod (Iris on Fabric, Oculus on Forge) is installed."
                : `${renderer.name} translates desktop GL to GLES and drops the features shaders rely on. Switch to Zink (Vulkan) to run shaders, or accept vanilla visuals.`}
            </p>
          </div>
        )}

        <div className="flex gap-2">
          <div className="flex-1">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={`Search ${kind === "shader" ? "shader" : "resource"} packs…`}
              className="w-full rounded-xl border hairline bg-black/30 px-3 py-2 text-sm outline-none focus:border-[var(--accent-line)]"
            />
          </div>
          <Button onClick={() => void search()} disabled={loading}>{loading ? "…" : "Find"}</Button>
        </div>

        {progress && (
          <div className="mt-3">
            <Progress value={progress.total ? progress.loaded / progress.total : undefined} indeterminate={!progress.total} label={progress.label} right={`${formatBytes(progress.loaded)}`} />
          </div>
        )}

        <div className="scroll-thin mt-3 max-h-[520px] space-y-2 overflow-auto pr-1">
          {hits.length === 0 && !loading && <Empty>Search to list packs that match {mcVersion}.</Empty>}
          {hits.map((h) => (
            <div key={h.fileName} className="panel-2 flex items-start justify-between gap-3 p-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">{h.name}</span>
                  <Pill tone={h.compatible ? "accent" : "warn"}>{h.compatible ? "compatible" : "needs renderer"}</Pill>
                </div>
                <p className="mt-0.5 line-clamp-2 text-[11px] leading-relaxed text-[var(--muted)]">{h.description}</p>
                {h.sizeBytes > 0 && <div className="mono mt-1 text-[10px] text-[var(--muted)]">{formatBytes(h.sizeBytes)}</div>}
              </div>
              <Button
                variant="outline"
                onClick={() => {
                  addToCart({ slug: h.fileName, title: h.name, file: {
                    versionId: h.fileName,
                    versionNumber: "latest",
                    filename: `${h.fileName}.zip`,
                    url: "",
                    size: h.sizeBytes,
                    sha1: "",
                    gameVersions: [mcVersion],
                    loaders: [],
                    dependencies: [],
                  }, kind });
                  log("ok", `${h.name} queued for the ${kind === "shader" ? "shaderpacks" : "resourcepacks"} folder`);
                }}
              >
                Queue
              </Button>
            </div>
          ))}
        </div>
      </Panel>

      <div className="space-y-5">
        <Panel title="Graphics presets" subtitle="Real vanilla options — no invented FPS figures">
          <div className="mb-3 flex flex-wrap gap-2">
            {(["low", "balanced", "high", "custom"] as const).map((p) => (
              <Chip
                key={p}
                active={settings.performanceProfile === p}
                onClick={() => {
                  const preset = {
                    low: { fpsLimit: 40, renderDistance: 4, simulationDistance: 4, particles: "minimal", entityDistance: 50, vsync: false, maxMemoryMb: 1536 },
                    balanced: { fpsLimit: 60, renderDistance: 8, simulationDistance: 6, particles: "decreased", entityDistance: 100, vsync: true, maxMemoryMb: 2048 },
                    high: { fpsLimit: 90, renderDistance: 12, simulationDistance: 10, particles: "all", entityDistance: 150, vsync: false, maxMemoryMb: 4096 },
                    custom: {},
                  }[p];
                  patchSettings({ ...preset, performanceProfile: p });
                  log("info", `Applied ${p} graphics preset`);
                }}
              >
                {p[0].toUpperCase() + p.slice(1)}
              </Chip>
            ))}
          </div>
          <Slider label="Render distance" value={settings.renderDistance} min={2} max={32} suffix=" chunks" onChange={(v) => patchSettings({ renderDistance: v })} />
          <Slider label="Simulation distance" value={settings.simulationDistance} min={2} max={32} suffix=" chunks" onChange={(v) => patchSettings({ simulationDistance: v })} />
          <div className="mt-1 flex flex-wrap gap-2">
            {["minimal", "decreased", "all"].map((p) => (
              <Chip key={p} active={settings.particles === p} onClick={() => patchSettings({ particles: p })}>particles: {p}</Chip>
            ))}
          </div>
        </Panel>

        <Panel title="Renderer selection">
          <ul className="space-y-2">
            {RENDERERS.map((r) => (
              <li key={r.id} className={`panel-2 p-3 ${settings.renderer === r.id ? "border-[var(--accent-line)]" : ""}`}>
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2 text-sm">
                      {r.name}
                      {r.shaders && <Pill tone="accent">shaders</Pill>}
                    </div>
                    <div className="text-[11px] text-[var(--muted)]">{r.api} · {r.note}</div>
                  </div>
                  <Button variant={settings.renderer === r.id ? "ghost" : "outline"} onClick={() => patchSettings({ renderer: r.id })}>
                    {settings.renderer === r.id ? "in use" : "Use"}
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </Panel>

        <Panel title="In-game options written by the launcher">
          <SectionTitle>options.txt</SectionTitle>
          <pre className="scroll-thin mono overflow-auto rounded-xl border hairline bg-black/40 p-3 text-[11px] leading-relaxed">
{`renderDistance:${settings.renderDistance}
simulationDistance:${settings.simulationDistance}
graphicsMode:${settings.performanceProfile === "low" ? 0 : settings.performanceProfile === "high" ? 2 : 1}
maxFps:${settings.fpsLimit}
enableVsync:${settings.vsync}
particles:${settings.particles}
entityDistanceScaling:${(settings.entityDistance / 100).toFixed(2)}
fullscreen:${settings.fullscreen}
shaderPack:${cart.some((c) => c.kind === "shader") ? cart.find((c) => c.kind === "shader")!.file.filename : ""}`}
          </pre>
          <div className="mt-2">
            <Toggle label="Fullscreen" checked={settings.fullscreen} onChange={(v) => patchSettings({ fullscreen: v })} />
            <Toggle label="VSync" checked={settings.vsync} onChange={(v) => patchSettings({ vsync: v })} hint="Caps frames to the display refresh — saves battery, adds input latency" />
          </div>
        </Panel>
      </div>
    </div>
  );
}
