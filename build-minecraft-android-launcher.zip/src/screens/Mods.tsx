import { useCallback, useEffect, useState } from "react";
import { downloadFile, formatBytes, modrinthSearch, modrinthVersions } from "@/lib/api";
import { buildMrpack, downloadMrpack } from "@/lib/mrpack";
import { loaderSlug, PERFORMANCE_PROFILES } from "@/lib/store";
import { useLauncher } from "@/lib/useLauncher";
import { Button, Chip, Code, Empty, Panel, Pill, Progress, SectionTitle, TextField } from "@/components/ui";
import type { CartItem, ModSearchHit, ModVersionFile } from "@/lib/types";

const KINDS = [
  { id: "mod", label: "Mods" },
  { id: "shader", label: "Shaders" },
  { id: "resourcepack", label: "Resource packs" },
] as const;

export function ModsScreen({ defaultKind = "mod" }: { defaultKind?: "mod" | "shader" | "resourcepack" }) {
  const { activeProfile, cart, addToCart, removeFromCart, clearCart, log, settings, device } = useLauncher();
  const [kind, setKind] = useState<"mod" | "shader" | "resourcepack">(defaultKind);
  const [query, setQuery] = useState(kind === "mod" ? "sodium" : kind === "shader" ? "complementary" : "faithful");
  const [hits, setHits] = useState<ModSearchHit[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [detail, setDetail] = useState<{ hit: ModSearchHit; files: ModVersionFile[] } | null>(null);
  const [progress, setProgress] = useState<{ label: string; loaded: number; total: number } | null>(null);
  const [packStatus, setPackStatus] = useState<string | null>(null);

  const loaders = loaderSlug(activeProfile?.loader ?? "fabric");
  const mcVersion = activeProfile?.mcVersion ?? "1.21.4";

  const search = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const results = await modrinthSearch(query, kind, mcVersion, loaders);
      setHits(results);
      log("net", `Modrinth search "${query}" (${kind}, ${mcVersion}, ${loaders.join("/")}) → ${results.length} results`);
    } catch (e) {
      setError((e as Error).message);
      log("error", `Modrinth search failed: ${(e as Error).message}`);
    } finally {
      setLoading(false);
    }
  }, [kind, loaders, log, mcVersion, query]);

  useEffect(() => {
    void search();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind]);

  async function openDetail(hit: ModSearchHit) {
    setLoading(true);
    setDetail(null);
    try {
      const files = await modrinthVersions(hit.slug, mcVersion, loaders);
      setDetail({ hit, files });
      log("net", `Resolved ${files.length} builds of ${hit.title} for ${mcVersion}`);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }

  async function grab(file: ModVersionFile, title: string, itemKind: CartItem["kind"]) {
    setProgress({ label: `Downloading ${file.filename}`, loaded: 0, total: file.size });
    try {
      await downloadFile(file.url, file.filename, (loaded, total) => setProgress({ label: file.filename, loaded, total }));
      addToCart({ slug: title.toLowerCase().replace(/\s+/g, "-"), title, file, kind: itemKind });
      setProgress(null);
      log("ok", `Downloaded ${file.filename} (${formatBytes(file.size)}) — SHA-1 ${file.sha1.slice(0, 12)}…`);
    } catch (e) {
      setProgress(null);
      log("error", `Download failed: ${(e as Error).message}`);
    }
  }

  const recommended = PERFORMANCE_PROFILES[settings.performanceProfile as "low" | "balanced" | "high" | "custom"].mods;

  return (
    <div className="grid gap-5 lg:grid-cols-[1.4fr_1fr] fade-up">
      <Panel
        title="Modrinth"
        subtitle={`Real API · ${kind === "mod" ? "mods" : kind === "shader" ? "shader packs" : "resource packs"} for ${mcVersion} (${loaders.join(", ")})`}
        action={<Pill tone="accent">live</Pill>}
      >
        <div className="mb-3 flex flex-wrap gap-2">
          {KINDS.map((k) => (
            <Chip key={k.id} active={kind === k.id} onClick={() => setKind(k.id)}>{k.label}</Chip>
          ))}
        </div>
        <div className="flex gap-2">
          <div className="flex-1">
            <TextField value={query} onChange={setQuery} placeholder="Search Modrinth…" />
          </div>
          <Button onClick={() => void search()} disabled={loading}>{loading ? "…" : "Search"}</Button>
        </div>

        {progress && (
          <div className="mt-3">
            <Progress value={progress.total ? progress.loaded / progress.total : undefined} indeterminate={!progress.total} label={progress.label} right={`${formatBytes(progress.loaded)} / ${formatBytes(progress.total)}`} />
          </div>
        )}
        {error && <p className="mt-2 text-xs text-red-300">{error}</p>}

        <div className="scroll-thin mt-3 max-h-[560px] space-y-2 overflow-auto pr-1">
          {hits.length === 0 && !loading && <Empty>No results — try a different search or check the network.</Empty>}
          {hits.map((h) => {
            const inCart = cart.some((c) => c.slug === h.slug);
            return (
              <div key={h.slug} className="panel-2 p-3">
                <div className="flex items-start gap-3">
                  {h.icon && <img src={h.icon} alt="" className="h-10 w-10 rounded-lg object-cover" loading="lazy" />}
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-semibold">{h.title}</span>
                      {h.loaders.slice(0, 2).map((l) => (
                        <Pill key={l} tone="muted">{l}</Pill>
                      ))}
                    </div>
                    <p className="mt-0.5 line-clamp-2 text-[11px] leading-relaxed text-[var(--muted)]">{h.description}</p>
                    <div className="mono mt-1 text-[10px] text-[var(--muted)]">{h.downloads.toLocaleString()} downloads</div>
                  </div>
                  <div className="flex shrink-0 flex-col gap-1">
                    <Button variant="outline" onClick={() => void openDetail(h)}>Details</Button>
                    <Button
                      variant={inCart ? "ghost" : "primary"}
                      disabled={inCart}
                      onClick={async () => {
                        try {
                          const files = await modrinthVersions(h.slug, mcVersion, loaders);
                          const file = files[0];
                          if (!file) throw new Error(`No build for ${mcVersion}`);
                          addToCart({ slug: h.slug, title: h.title, file, kind });
                          log("ok", `Added ${h.title} ${file.versionNumber} to the install plan`);
                        } catch (e) {
                          log("error", `${h.title}: ${(e as Error).message}`);
                        }
                      }}
                    >
                      {inCart ? "Added" : "Add"}
                    </Button>
                  </div>
                </div>

                {detail?.hit.slug === h.slug && (
                  <div className="mt-3 space-y-2 border-t hairline pt-3">
                    <SectionTitle>Compatible builds</SectionTitle>
                    {detail.files.length === 0 && <Empty>No build matches {mcVersion} / {loaders.join(", ")}</Empty>}
                    {detail.files.slice(0, 4).map((f) => (
                      <div key={f.versionId} className="flex items-center justify-between gap-2 rounded-lg bg-black/25 px-3 py-2">
                        <div className="min-w-0">
                          <div className="mono truncate text-xs">{f.versionNumber}</div>
                          <div className="text-[10px] text-[var(--muted)]">
                            {formatBytes(f.size)} · {f.dependencies.filter((d) => d.required).length} required deps
                          </div>
                        </div>
                        <Button variant="outline" onClick={() => void grab(f, h.title, kind)}>Download</Button>
                      </div>
                    ))}
                    {detail.files[0]?.changelog && (
                      <Code className="max-h-32">{(detail.files[0].changelog ?? "").slice(0, 700)}</Code>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </Panel>

      <div className="space-y-5">
        <Panel
          title={`Install plan (${cart.length})`}
          subtitle="Files are SHA-1 verified and written into the real game directories by the Android app"
          action={<Button variant="ghost" onClick={clearCart}>Clear</Button>}
        >
          {cart.length === 0 ? (
            <Empty>Nothing queued. Add mods from the list on the left.</Empty>
          ) : (
            <ul className="space-y-2">
              {cart.map((c) => (
                <li key={c.slug} className="panel-2 flex items-center justify-between gap-2 px-3 py-2">
                  <div className="min-w-0">
                    <div className="truncate text-sm">{c.title}</div>
                    <div className="mono truncate text-[10px] text-[var(--muted)]">
                      {c.file.filename} · {formatBytes(c.file.size)} · {c.kind}
                    </div>
                  </div>
                  <Button variant="danger" onClick={() => removeFromCart(c.slug)}>✕</Button>
                </li>
              ))}
            </ul>
          )}

          <div className="mt-3 space-y-2">
            <Button
              className="w-full"
              disabled={cart.length === 0}
              onClick={async () => {
                setPackStatus("Building modrinth.index.json…");
                try {
                  const pack = await buildMrpack({
                    name: `${activeProfile?.name ?? "profile"} pack`,
                    mcVersion,
                    loader: activeProfile?.loader ?? "fabric",
                    items: cart,
                  });
                  downloadMrpack(pack);
                  setPackStatus(`Exported ${pack.filename} — a valid Modrinth-format pack.`);
                  log("ok", `Exported ${pack.filename} with ${cart.length} file(s)`);
                } catch (e) {
                  setPackStatus(`Failed: ${(e as Error).message}`);
                }
              }}
            >
              Export .mrpack modpack
            </Button>
            {packStatus && <p className="text-[11px] text-[var(--muted)]">{packStatus}</p>}
          </div>
        </Panel>

        <Panel title="Compatibility audit" subtitle="Checked against your profile, renderer and device">
          <ul className="space-y-2 text-xs leading-relaxed">
            <li className="panel-2 p-3">
              <strong className="accent-text">Renderer</strong> · {settings.renderer}
              <p className="mt-1 text-[var(--muted)]">
                Shader packs need a desktop-GL capable renderer (Zink/Vulkan) plus Iris or Oculus. With gl4es they will not render — the launcher says so instead of guessing.
              </p>
            </li>
            <li className="panel-2 p-3">
              <strong className="accent-text">Memory</strong> · {settings.maxMemoryMb} MB requested
              <p className="mt-1 text-[var(--muted)]">
                This device caps an app's Java heap around {device.heapLimitMb} MB. Values above that are clamped, because a JVM that cannot get its heap dies instantly.
              </p>
            </li>
            <li className="panel-2 p-3">
              <strong className="accent-text">Duplicates & dependencies</strong>
              <p className="mt-1 text-[var(--muted)]">
                The Android app reads <span className="mono">fabric.mod.json</span> / <span className="mono">mods.toml</span> from every jar in the mods folder and reports duplicate mod ids and missing required dependencies before launching.
              </p>
            </li>
            <li className="panel-2 p-3">
              <strong className="accent-text">Recommended for the {settings.performanceProfile} profile</strong>
              <p className="mono mt-1 text-[11px] text-[var(--muted)]">{recommended.join(", ") || "none"}</p>
            </li>
          </ul>
        </Panel>
      </div>
    </div>
  );
}
