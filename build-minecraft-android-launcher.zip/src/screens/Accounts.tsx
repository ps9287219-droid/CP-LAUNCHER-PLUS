import { useState } from "react";
import { offlineUuid } from "@/lib/store";
import { useLauncher } from "@/lib/useLauncher";
import { Button, Code, Panel, Pill, TextField } from "@/components/ui";
import { SkinRender, skinUrlFor } from "@/components/SkinRender";

/**
 * Microsoft device-code sign-in.
 *
 * The flow itself is the documented one:
 *   POST /{tenant}/oauth2/v2.0/devicecode  -> user_code + verification_uri
 *   POST /{tenant}/oauth2/v2.0/token        (poll) -> access/refresh token
 *   XBL -> XSTS -> login_with_xbox -> /minecraft/profile -> /entitlements/mcstore
 *
 * It only runs when you supply your own Azure *public client* application id, because
 * shipping someone else's client id in a public bundle would be misuse of their app
 * registration. If the browser blocks the request (CORS), the error is shown as-is
 * instead of pretending the sign-in succeeded.
 */
export function AccountsScreen() {
  const { accounts, activeAccount, addAccount, removeAccount, setActiveAccount, settings, patchSettings, log } = useLauncher();
  const [clientId, setClientId] = useState(settings.msClientId);
  const [code, setCode] = useState<string | null>(null);
  const [verifyUri, setVerifyUri] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [localName, setLocalName] = useState("");

  async function deviceCodeFlow() {
    setBusy(true);
    setStatus(null);
    setCode(null);
    try {
      patchSettings({ msClientId: clientId });
      const start = await fetch("https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ client_id: clientId, scope: "XboxLive.signin offline_access" }),
      });
      if (!start.ok) throw new Error(`HTTP ${start.status} from the identity endpoint`);
      const startJson = (await start.json()) as { device_code: string; user_code: string; verification_uri: string };
      setCode(startJson.user_code);
      setVerifyUri(startJson.verification_uri);
      log("net", "Device code issued — waiting for the user to authorise in a browser");

      // Poll the token endpoint exactly like the Android app does.
      const deadline = Date.now() + 15 * 60 * 1000;
      let tokenJson: Record<string, string> | null = null;
      while (Date.now() < deadline) {
        await new Promise((r) => setTimeout(r, 5000));
        const res = await fetch("https://login.microsoftonline.com/consumers/oauth2/v2.0/token", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({
            client_id: clientId,
            grant_type: "urn:ietf:params:oauth:grant-type:device_code",
            device_code: startJson.device_code,
          }),
        });
        const json = (await res.json()) as Record<string, string>;
        if (json.access_token) {
          tokenJson = json;
          break;
        }
        if (json.error && json.error !== "authorization_pending" && json.error !== "slow_down") {
          throw new Error(`Microsoft rejected the sign-in: ${json.error}`);
        }
      }
      if (!tokenJson) throw new Error("Timed out waiting for authorisation");

      const chain = await completeChain(tokenJson.access_token, tokenJson.refresh_token ?? "");
      addAccount({
        id: chain.uuid,
        name: chain.name,
        uuid: chain.uuid,
        kind: "microsoft",
        ownsGame: chain.owns,
        skin: chain.skin,
        cape: chain.cape,
        verified: "verified",
      });
      setStatus(`Signed in as ${chain.name}${chain.owns ? "" : " (no Java entitlement found — the launcher will warn before launching)"}`);
      log("ok", `Microsoft sign-in complete for ${chain.name} · entitlement ${chain.owns ? "verified" : "missing"}`);
    } catch (e) {
      const msg = (e as Error).message;
      setStatus(
        msg.includes("Failed to fetch")
          ? "The browser blocked the request (CORS). The Android app performs the identical flow natively without that restriction — enter your own Azure public-client id there."
          : msg,
      );
      log("error", `Microsoft sign-in: ${msg}`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-5 lg:grid-cols-[1.3fr_1fr] fade-up">
      <div className="space-y-5">
        <Panel title="Microsoft account" subtitle="Official device-code flow — the launcher never sees your password">
          <ol className="mb-3 space-y-1 text-xs leading-relaxed text-[var(--muted)]">
            <li>1. Create an Azure <strong>public client/native</strong> application and enable "Allow public client flows".</li>
            <li>2. Paste its application (client) id below.</li>
            <li>3. A short code is shown; open microsoft.com/link on any device and enter it.</li>
            <li>4. The launcher exchanges the code for Xbox Live → XSTS → Minecraft Services tokens and checks your Java entitlement.</li>
          </ol>
          <TextField label="Azure application (client) id" value={clientId} onChange={setClientId} placeholder="00000000-0000-0000-0000-000000000000" mono />
          <div className="mt-3 flex gap-2">
            <Button onClick={() => void deviceCodeFlow()} disabled={busy || clientId.trim().length < 8}>
              {busy ? "Waiting for authorisation…" : "Sign in with Microsoft"}
            </Button>
          </div>
          {code && (
            <div className="mt-3 rounded-xl border border-[var(--accent-line)] bg-[var(--accent-soft)] p-3">
              <div className="mono text-2xl font-black tracking-[0.3em] accent-text">{code}</div>
              <p className="mt-1 text-[11px] text-[var(--muted)]">Open <span className="mono">{verifyUri}</span> and enter the code above.</p>
            </div>
          )}
          {status && <p className="mt-2 text-xs text-[var(--muted)]">{status}</p>}
          <p className="mt-3 text-[11px] leading-relaxed text-[var(--muted)]">
            Tokens are stored encrypted (Android Keystore / EncryptedSharedPreferences in the APK). No password is ever requested, transmitted,
            or stored, and there is no code path that could accept one.
          </p>
        </Panel>

        <Panel title={`Saved accounts (${accounts.length})`}>
          {accounts.length === 0 ? (
            <p className="text-xs text-[var(--muted)]">No accounts yet. Add a Microsoft account or an offline profile.</p>
          ) : (
            <ul className="space-y-2">
              {accounts.map((a) => (
                <li key={a.id} className="panel-2 flex items-center gap-3 p-3">
                  {a.skin ? <img src={a.skin} alt="" className="h-10 w-10 rounded-lg bg-black/40 object-contain" /> : <div className="h-10 w-10 rounded-lg bg-white/5" />}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="truncate text-sm font-semibold">{a.name}</span>
                      <Pill tone={a.kind === "microsoft" ? "accent" : "muted"}>{a.kind === "microsoft" ? "MSA" : "LOCAL"}</Pill>
                      {a.active && <Pill>active</Pill>}
                    </div>
                    <div className="mono truncate text-[10px] text-[var(--muted)]">{a.uuid}</div>
                    <div className="text-[10px] text-[var(--muted)]">
                      {a.kind === "microsoft" ? (a.ownsGame ? "Java Edition entitlement verified" : "No Java entitlement found") : "Offline profile — singleplayer and offline-allowed servers only"}
                    </div>
                  </div>
                  <div className="flex shrink-0 gap-1">
                    {!a.active && <Button variant="outline" onClick={() => setActiveAccount(a.id)}>Use</Button>}
                    <Button variant="danger" onClick={() => removeAccount(a.id)}>✕</Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel title="Local (offline) profile" subtitle="Clearly not a Minecraft account">
          <TextField label="Player name" value={localName} onChange={(v) => setLocalName(v.slice(0, 16))} placeholder="Steve" />
          <div className="mt-2 flex gap-2">
            <Button
              variant="outline"
              disabled={localName.trim().length < 3}
              onClick={() => {
                const uuid = offlineUuid(localName.trim());
                addAccount({ id: uuid, name: localName.trim(), uuid, kind: "offline", verified: "unverified" });
                log("info", `Offline profile created for ${localName} (${uuid})`);
              }}
            >
              Create local profile
            </Button>
          </div>
          <p className="mt-2 text-[11px] leading-relaxed text-[var(--muted)]">
            The UUID is derived from the name exactly like vanilla offline mode. This works for singleplayer and for servers that accept offline
            names; it cannot authenticate against Mojang-secured servers, and the launcher will not pretend otherwise.
          </p>
        </Panel>
      </div>

      <div className="space-y-5">
        <Panel title="Current identity">
          {activeAccount ? (
            <div className="flex flex-col items-center">
              <SkinRender skinUrl={skinUrlFor(activeAccount.uuid)} size={190} />
              <div className="mt-3 text-center">
                <div className="text-lg font-semibold">{activeAccount.name}</div>
                <div className="mono break-all text-[10px] text-[var(--muted)]">{activeAccount.uuid}</div>
                <div className="mt-2 flex justify-center gap-2">
                  <Pill tone={activeAccount.kind === "microsoft" ? "accent" : "muted"}>{activeAccount.kind}</Pill>
                  {activeAccount.verified && <Pill tone={activeAccount.verified === "verified" ? "accent" : "warn"}>{activeAccount.verified}</Pill>}
                </div>
              </div>
            </div>
          ) : (
            <p className="text-xs text-[var(--muted)]">No active account. Add one on the left.</p>
          )}
        </Panel>

        <Panel title="Auth chain reference">
          <Code className="max-h-80">{`POST https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode
  client_id=<azure public client id>
  scope=XboxLive.signin offline_access
-> { user_code, verification_uri, device_code, interval }

POST /oauth2/v2.0/token        (poll every interval)
-> { access_token, refresh_token }

POST https://user.auth.xboxlive.com/user/authenticate
  { Properties: { AuthMethod: "RPS", SiteName: "user.auth.xboxlive.com",
                  RpsTicket: "d=<ms access_token>" },
    RelyingParty: "http://auth.xboxlive.com", TokenType: "JWT" }
-> { Token, DisplayClaims.xui[0].uhs }

POST https://xsts.auth.xboxlive.com/xsts/authorize
  { Properties: { SandboxId: "RETAIL", UserTokens: [ <xbl token> ] },
    RelyingParty: "rp://api.minecraftservices.com/", TokenType: "JWT" }
-> { Token, uhs }

POST https://api.minecraftservices.com/authentication/login_with_xbox
  { identityToken: "XBL3.0 x=<uhs>;<xsts token>" }
-> { access_token }

GET  /minecraft/profile        -> name, uuid, skins, capes
GET  /entitlements/mcstore     -> product_minecraft | game_minecraft

POST /minecraft/profile/skins  (multipart: model, file) -> upload a skin`}</Code>
        </Panel>
      </div>
    </div>
  );
}

interface ProfileResponse {
  id: string;
  name: string;
  skins: { url: string; state: string }[];
  capes: { url: string }[];
}

async function completeChain(msAccessToken: string, msRefreshToken: string) {
  const post = async (url: string, body: unknown) => {
    const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    if (!res.ok) throw new Error(`HTTP ${res.status} from ${new URL(url).host}`);
    return (await res.json()) as Record<string, never>;
  };
  const xbl = await post("https://user.auth.xboxlive.com/user/authenticate", {
    Properties: { AuthMethod: "RPS", SiteName: "user.auth.xboxlive.com", RpsTicket: `d=${msAccessToken}` },
    RelyingParty: "http://auth.xboxlive.com",
    TokenType: "JWT",
  }) as unknown as { Token: string; DisplayClaims: { xui: { uhs: string }[] } };

  const xsts = (await post("https://xsts.auth.xboxlive.com/xsts/authorize", {
    Properties: { SandboxId: "RETAIL", UserTokens: [xbl.Token] },
    RelyingParty: "rp://api.minecraftservices.com/",
    TokenType: "JWT",
  })) as unknown as { Token: string; DisplayClaims: { xui: { uhs: string }[] } };

  const uhs = xsts.DisplayClaims.xui[0].uhs;
  const mc = (await post("https://api.minecraftservices.com/authentication/login_with_xbox", {
    identityToken: `XBL3.0 x=${uhs};${xsts.Token}`,
  })) as unknown as { access_token: string };

  const profile = await fetch("https://api.minecraftservices.com/minecraft/profile", {
    headers: { Authorization: `Bearer ${mc.access_token}` },
  }).then((r) => (r.ok ? (r.json() as Promise<ProfileResponse>) : Promise.resolve(null)));

  const ent = await fetch("https://api.minecraftservices.com/entitlements/mcstore", {
    headers: { Authorization: `Bearer ${mc.access_token}` },
  })
    .then((r) => (r.ok ? (r.json() as Promise<{ items: { name: string }[] }>) : Promise.resolve(null)))
    .catch(() => null);

  const owns = !!ent?.items?.some((i) => i.name === "product_minecraft" || i.name === "game_minecraft");
  const activeSkin = profile?.skins?.find((s) => s.state === "ACTIVE")?.url ?? null;

  return {
    uuid: profile?.id ?? "",
    name: profile?.name ?? "Unknown",
    skin: activeSkin,
    cape: profile?.capes?.[0]?.url ?? null,
    owns,
    refresh: msRefreshToken,
  };
}
