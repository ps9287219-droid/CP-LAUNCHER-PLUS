import { useMemo, useState } from "react";
import { formatBytes, formatDuration } from "@/lib/api";
import { useLauncher } from "@/lib/useLauncher";
import { Button, Chip, Code, Empty, Panel, Pill, SectionTitle, TextField } from "@/components/ui";
import { cn } from "@/utils/cn";

const TYPES = [
  { id: "release", label: "Releases" },
  { id: "snapshot", label: "Snapshots" },
  { id: "old_beta", label: "Beta" },
  { id: "old_alpha", label: "Alpha" },
] as const;

const LOADERS = [
  { id: "vanilla", label: "Vanilla" },
  { id: "fabric", label: "Fabric" },
  { id: "quilt", label: "Quilt" },
  { id: "forge", label: "Forge" },
  { id: "neoforge", label: "NeoForge" },
] as const;

export function LibraryScreen() {
  const { versions, manifestLive, loadingManifest, reloadManifest, profiles, addProfile, deleteProfile, setActiveProfile, settings, activeProfile, ensurePlan, planCache, installedRuntimes, installRuntime, log } = useLauncher();
  const [type, setType] = useState<(typeof TYPES)[number]["id"]>("release");
  const [query, setQuery] = useState("");
  const [loader, setLoader] = useState<(typeof LOADERS)[number]["id"]>("vanilla");
  const [resolving, setResolving] = useState<string | null>(null);

  const filtered = useMemo(
    () =>
      versions
        .filter((v) => v.type === type)
        .filter((v) => (query ? v.id.toLowerCase().includes(query.toLowerCase()) : true))
        .slice(0, 60),
    [versions, type, query],
  );

  async function install(id: string) {
    const version = versions.find((v) => v.id === id);
    if (!version) return;
    setResolving(id);
    const plan = await ensurePlan(version);
    setResolving(null);
    if (!plan) return;
    addProfile({
      name: `${loader === "vanilla" ? "Vanilla" : loader[0].toUpperCase() + loader.slice(1)} ${id}`,
      mcVersion: id,
      loader,
      plannedBytes: plan.totalBytes,
      libraries: plan.libraries.length,
      assets: plan.assetCount,
      javaMajor: plan.javaMajor,
    });
    const runtimeId = `jre${plan.javaMajor}-arm64`;
    if (!installedRuntimes.includes(runtimeId)) {
      log("warn", `${runtimeId} is required for ${id} — open the Runtimes panel to install it`);
    }
  }

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_1.25fr] fade-up">
      <div className="space-y-5">
        <Panel
          title="Installations"
          subtitle={`${profiles.length} profile${profiles.length === 1 ? "" : "s"} · active: ${activeProfile?.name ?? "none"}`}
          action={
            <Button variant="ghost" onClick={reloadManifest}>
              {loadingManifest ? "Loading…" : "Refresh manifest"}
            </Button>
          }
        >
          <ul className="space-y-2">
            {profiles.map((p) => (
              <li key={p.id} className={cn("panel-2 p-3", p.id === settings.activeProfileId && "border-[var(--accent-line)]")}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="truncate text-sm font-semibold">{p.name}</span>
                      {p.id === settings.activeProfileId && <Pill>active</Pill>}
                    </div>
                    <div className="mt-0.5 text-[11px] text-[var(--muted)]">
                      {p.loader} · {p.mcVersion} · Java {p.javaMajor ?? "?"} · played {formatDuration(p.totalPlaySeconds)}
                    </div>
                    {p.plannedBytes ? (
                      <div className="mono mt-0.5 text-[10px] text-[var(--muted)]">
                        {p.libraries} libraries · {p.assets} assets · {formatBytes(p.plannedBytes)} download
                      </div>
                    ) : null}
                  </div>
                  <div className="flex shrink-0 gap-1">
                    {p.id !== settings.activeProfileId && (
                      <Button variant="outline" onClick={() => setActiveProfile(p.id)}>Use</Button>
                    )}
                    <Button variant="danger" onClick={() => deleteProfile(p.id)}>✕</Button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </Panel>

        <Panel title="Java runtimes" subtitle="OpenJDK builds for Android (arm64-v8a / x86_64, GPLv2 + Classpath exception)">
          <ul className="space-y-2">
            {[
              { id: "jre21-arm64", label: "OpenJDK 21", note: "Minecraft 1.20.5+", size: 70 },
              { id: "jre17-arm64", label: "OpenJDK 17", note: "Minecraft 1.17 – 1.20.4", size: 55 },
              { id: "jre11-arm64", label: "OpenJDK 11", note: "Minecraft 1.13 – 1.16.5", size: 45 },
              { id: "jre8-arm64", label: "OpenJDK 8", note: "Minecraft 1.7.10 – 1.12.2", size: 35 },
            ].map((r) => {
              const installed = installedRuntimes.includes(r.id);
              return (
                <li key={r.id} className="panel-2 flex items-center justify-between px-3 py-2">
                  <div>
                    <div className="flex items-center gap-2 text-sm">
                      {r.label}
                      {installed && <Pill>installed</Pill>}
                    </div>
                    <div className="text-[11px] text-[var(--muted)]">{r.note} · ~{r.size} MB tar.xz</div>
                  </div>
                  <Button variant={installed ? "outline" : "primary"} onClick={() => void installRuntime(r.id)}>
                    {installed ? "Re-download" : "Install"}
                  </Button>
                </li>
              );
            })}
          </ul>
        </Panel>
      </div>

      <Panel
        title="Create installation"
        subtitle="Version list and metadata come straight from Mojang's piston-meta manifest"
        action={<Pill tone={manifestLive ? "accent" : "warn"}>{manifestLive ? "live" : "fallback"}</Pill>}
      >
        <div className="mb-3 flex flex-wrap gap-2">
          {TYPES.map((t) => (
            <Chip key={t.id} active={type === t.id} onClick={() => setType(t.id)}>{t.label}</Chip>
          ))}
        </div>
        <div className="mb-3 flex flex-wrap gap-2">
          {LOADERS.map((l) => (
            <Chip key={l.id} active={loader === l.id} onClick={() => setLoader(l.id)}>{l.label}</Chip>
          ))}
        </div>
        <TextField label="Search" value={query} onChange={setQuery} placeholder="1.21" />

        <div className="scroll-thin mt-3 max-h-[460px] space-y-1.5 overflow-auto pr-1">
          {filtered.length === 0 && <Empty>{loadingManifest ? "Loading manifest…" : "No versions match."}</Empty>}
          {filtered.map((v) => {
            const plan = planCache[v.id];
            return (
              <div key={v.id} className="panel-2 flex items-center justify-between gap-3 px-3 py-2">
                <div className="min-w-0">
                  <div className="mono truncate text-sm">{v.id}</div>
                  <div className="text-[10px] text-[var(--muted)]">
                    {v.releaseTime?.slice(0, 10) || "no date"}
                    {plan ? ` · Java ${plan.javaMajor} · ${formatBytes(plan.totalBytes)} · ${plan.libraries.length} libs` : ""}
                  </div>
                </div>
                <Button
                  variant={plan ? "outline" : "primary"}
                  disabled={resolving === v.id}
                  onClick={() => void install(v.id)}
                >
                  {resolving === v.id ? "Resolving…" : plan ? "Install" : "Resolve & install"}
                </Button>
              </div>
            );
          })}
        </div>

        {Object.keys(planCache).length > 0 && (
          <div className="mt-4">
            <SectionTitle>Resolved download plans</SectionTitle>
            {Object.values(planCache).map((p) => (
              <Code key={p.id} className="mb-2 max-h-40">{`${p.id}
mainClass   ${p.mainClass}
java        ${p.javaMajor}
assets      ${p.assetsIndexId} (${p.assetCount} objects)
client      ${formatBytes(p.clientSize)}
libraries   ${p.libraries.length} total · ${p.libraries.filter((l) => l.androidApplicable).length} apply to Android · ${p.libraries.filter((l) => l.desktopOnly).length} desktop-only (LWJGL/GLFW substituted)
download    ${formatBytes(p.totalBytes)}`}</Code>
            ))}
          </div>
        )}
      </Panel>
    </div>
  );
}
