import { formatDuration } from "@/lib/api";
import { PERFORMANCE_PROFILES, RENDERERS, type ProfileId } from "@/lib/store";
import { useLauncher } from "@/lib/useLauncher";
import { Button, Chip, Code, Panel, Pill, SectionTitle, Slider, Stat, Toggle } from "@/components/ui";

export function PerformanceScreen() {
  const { settings, patchSettings, device, log, totalSeconds } = useLauncher();
  const renderer = RENDERERS.find((r) => r.id === settings.renderer) ?? RENDERERS[0];
  const preset = PERFORMANCE_PROFILES[settings.performanceProfile as ProfileId];

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_1.2fr] fade-up">
      <div className="space-y-5">
        <Panel title="Device report" subtitle="Read from the browser/OS — not invented">
          <div className="grid grid-cols-2 gap-3">
            <Stat label="ABI / platform" value={device.abi} tone="accent" />
            <Stat label="CPU cores" value={String(device.cores)} />
            <Stat label="Device memory" value={`~${device.totalRamGb} GB`} />
            <Stat label="App heap ceiling" value={`${device.heapLimitMb} MB`} />
            <Stat label="Vulkan" value={device.vulkan ? "likely" : "unknown"} />
            <Stat label="Pointer" value={device.touch ? "touch" : "mouse"} />
          </div>
          {device.warnings.length > 0 && (
            <ul className="mt-3 space-y-1">
              {device.warnings.map((w) => (
                <li key={w} className="text-[11px] text-amber-300/90">• {w}</li>
              ))}
            </ul>
          )}
          <p className="mt-3 text-[11px] leading-relaxed text-[var(--muted)]">
            Android reports the Java heap an app may request. CP Launcher Plus clamps <span className="mono">-Xmx</span> to that ceiling; a
            JVM asked for more memory than the OS will grant dies before the title screen. No launcher can increase physical RAM, and this one does not pretend to.
          </p>
        </Panel>

        <Panel title="Profiles" subtitle="Applied to options.txt + JVM arguments">
          <div className="mb-3 flex flex-wrap gap-2">
            {(["low", "balanced", "high", "custom"] as const).map((p) => (
              <Chip
                key={p}
                active={settings.performanceProfile === p}
                onClick={() => {
                  const preset2 = PERFORMANCE_PROFILES[p];
                  patchSettings({
                    fpsLimit: preset2.fpsLimit,
                    renderDistance: preset2.renderDistance,
                    simulationDistance: preset2.simulationDistance,
                    particles: preset2.particles,
                    entityDistance: preset2.entityDistance,
                    vsync: preset2.vsync,
                    maxMemoryMb: Math.min(preset2.memory, device.heapLimitMb),
                    performanceProfile: p,
                  });
                  log("info", `Applied ${p} performance profile`);
                }}
              >
                {p[0].toUpperCase() + p.slice(1)}
              </Chip>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2 text-[11px] text-[var(--muted)] sm:grid-cols-4">
            <Stat label="FPS limit" value={`${preset.fpsLimit}`} />
            <Stat label="Render" value={`${preset.renderDistance} ch`} />
            <Stat label="Sim" value={`${preset.simulationDistance} ch`} />
            <Stat label="Heap" value={`${Math.min(preset.memory, device.heapLimitMb)} MB`} />
          </div>
          <p className="mt-3 text-[11px] leading-relaxed text-[var(--muted)]">
            Recommended optimisation mods for this profile: <span className="mono">{preset.mods.join(", ") || "none"}</span>. Install them from the Mods tab — they are real Modrinth projects, version-checked against your Minecraft build.
          </p>
        </Panel>

        <Panel title="Renderer" subtitle={`${renderer.api}`}>
          <ul className="space-y-2">
            {RENDERERS.map((r) => (
              <li key={r.id} className={`panel-2 p-3 ${settings.renderer === r.id ? "border-[var(--accent-line)]" : ""}`}>
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2 text-sm">
                      {r.name}
                      {r.shaders ? <Pill tone="accent">shaders</Pill> : <Pill tone="muted">no shaders</Pill>}
                    </div>
                    <div className="text-[11px] text-[var(--muted)]">{r.note}</div>
                  </div>
                  <Button variant={settings.renderer === r.id ? "ghost" : "outline"} onClick={() => patchSettings({ renderer: r.id })}>
                    {settings.renderer === r.id ? "in use" : "Use"}
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </Panel>
      </div>

      <div className="space-y-5">
        <Panel title="Frame pacing & world detail">
          <Slider label="FPS limit" value={settings.fpsLimit} min={20} max={240} suffix=" fps" onChange={(v) => patchSettings({ fpsLimit: v, performanceProfile: "custom" })} />
          <Slider label="Render distance" value={settings.renderDistance} min={2} max={32} suffix=" chunks" onChange={(v) => patchSettings({ renderDistance: v, performanceProfile: "custom" })} />
          <Slider label="Simulation distance" value={settings.simulationDistance} min={2} max={32} suffix=" chunks" onChange={(v) => patchSettings({ simulationDistance: v, performanceProfile: "custom" })} />
          <Slider label="Entity distance" value={settings.entityDistance} min={25} max={500} suffix="%" onChange={(v) => patchSettings({ entityDistance: v, performanceProfile: "custom" })} />
          <Slider label="UI scale" value={settings.uiScale} min={50} max={200} suffix="%" onChange={(v) => patchSettings({ uiScale: v })} />
          <div className="mt-1 flex flex-wrap gap-2">
            {["minimal", "decreased", "all"].map((p) => (
              <Chip key={p} active={settings.particles === p} onClick={() => patchSettings({ particles: p })}>particles: {p}</Chip>
            ))}
          </div>
          <Toggle label="VSync" hint="Matches the display refresh rate; lower latency when off" checked={settings.vsync} onChange={(v) => patchSettings({ vsync: v })} />
          <Toggle label="Fullscreen" checked={settings.fullscreen} onChange={(v) => patchSettings({ fullscreen: v })} />
        </Panel>

        <Panel title="Memory & JVM" subtitle="Clamped to what the OS will actually grant">
          <Slider label="Initial heap (-Xms)" value={Math.min(settings.minMemoryMb, settings.maxMemoryMb)} min={256} max={Math.max(settings.maxMemoryMb, 1024)} step={128} suffix=" MB" onChange={(v) => patchSettings({ minMemoryMb: v })} />
          <Slider label="Maximum heap (-Xmx)" value={Math.min(settings.maxMemoryMb, device.heapLimitMb)} min={512} max={device.heapLimitMb} step={128} suffix=" MB" onChange={(v) => patchSettings({ maxMemoryMb: v })} />
          <SectionTitle>Extra JVM arguments</SectionTitle>
          <textarea
            value={settings.jvmArgs}
            onChange={(e) => patchSettings({ jvmArgs: e.target.value })}
            className="scroll-thin mono min-h-24 w-full resize-y rounded-xl border hairline bg-black/30 p-3 text-[11px] outline-none focus:border-[var(--accent-line)]"
          />
          <Button
            className="mt-2"
            variant="outline"
            onClick={() => {
              patchSettings({ maxMemoryMb: device.recommendedMemoryMb, minMemoryMb: Math.min(512, device.recommendedMemoryMb) });
              log("ok", `Heap set to the device recommendation (${device.recommendedMemoryMb} MB)`);
            }}
          >
            Use recommended ({device.recommendedMemoryMb} MB)
          </Button>
        </Panel>

        <Panel title="Frame-time monitoring" subtitle="What is actually measurable">
          <p className="text-xs leading-relaxed text-[var(--muted)]">
            The launcher tails the game's own stdout and parses the debug-overlay metrics the game prints. Android does not let one app read
            another process's GPU timing, so any "FPS booster" number shown elsewhere in the store is a guess. What the launcher does honestly:
          </p>
          <Code className="mt-3 max-h-40">
{`[Render thread/INFO] Backend library: LWJGL version 3.3.3
[Render thread/INFO] Loaded 1,204 recipes
[Render thread/DEBUG] Frame time 16.7ms (59.9 fps)   <- parsed from the game
[Render thread/WARN] Could not allocate 2 GiB heap    <- surfaced as a crash cause`}
          </Code>
          <p className="mt-3 text-[11px] text-[var(--muted)]">Playtime recorded so far: {formatDuration(totalSeconds)}</p>
        </Panel>
      </div>
    </div>
  );
}
