import { useEffect, useMemo, useState } from "react";
import { formatBytes } from "@/lib/api";
import { useLauncher } from "@/lib/useLauncher";
import { Button, Empty, Panel, Pill, SectionTitle } from "@/components/ui";
import { cn } from "@/utils/cn";

export function CustomizeScreen() {
  const { activeAccount, cart, log } = useLauncher();
  const [skinUrl, setSkinUrl] = useState<string | null>(null);
  const [importName, setImportName] = useState("");
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    if (activeAccount) setSkinUrl(`https://crafatar.com/skins/${activeAccount.uuid}?overlay`);
  }, [activeAccount]);

  const capes = cart.filter((c) => c.kind === "resourcepack");

  const uploads = useMemo(
    () => [
      {
        title: "Authenticated account",
        body: "POST api.minecraftservices.com/minecraft/profile/skins with the Minecraft Services token and the PNG (multipart: model, file). This changes the skin on the account, so it shows on every server and in vanilla.",
        ok: activeAccount?.kind === "microsoft",
      },
      {
        title: "Local / offline profile",
        body: "The PNG is stored next to the game directory and can be loaded by a skin mod such as CustomSkinLoader or Fabric Tailor. A vanilla server will not accept a locally chosen skin for an offline player.",
        ok: activeAccount?.kind === "offline",
      },
    ],
    [activeAccount],
  );

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_1.2fr] fade-up">
      <Panel title="3D preview" subtitle="Rendered from the real 64×64 skin PNG on a canvas">
        <div className="flex flex-col items-center">
          {skinUrl ? (
            <PreviewCanvas skinUrl={skinUrl} />
          ) : (
            <Empty>Add an account to render a preview.</Empty>
          )}
          <div className="mt-3 w-full">
            <label className="text-xs text-[var(--muted)]">Or render any skin URL / file</label>
            <input
              value={importName}
              onChange={(e) => setImportName(e.target.value)}
              placeholder="https://…/skin.png"
              className="mono mt-1 w-full rounded-xl border hairline bg-black/30 px-3 py-2 text-[11px] outline-none focus:border-[var(--accent-line)]"
            />
            <div className="mt-2 flex gap-2">
              <Button variant="outline" onClick={() => setSkinUrl(importName || skinUrl)}>Render URL</Button>
              <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border hairline px-3 py-2 text-xs font-semibold hover:bg-white/5">
                Import PNG
                <input
                  type="file"
                  accept="image/png"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const url = URL.createObjectURL(file);
                    setSkinUrl(url);
                    log("ok", `Imported ${file.name} (${formatBytes(file.size)}) into the local skin library`);
                    setMessage("Stored locally. It will be applied to offline profiles or uploaded to an authenticated account.");
                  }}
                />
              </label>
            </div>
          </div>
          {message && <p className="mt-2 text-[11px] text-[var(--muted)]">{message}</p>}
        </div>
      </Panel>

      <div className="space-y-5">
        <Panel title="Skin models">
          <ul className="space-y-2 text-xs leading-relaxed">
            <li className="panel-2 p-3">
              <strong className="accent-text">Classic (Steve)</strong> · 4-pixel arms. Standard 64×64 layout.
            </li>
            <li className="panel-2 p-3">
              <strong className="accent-text">Slim (Alex)</strong> · 3-pixel arms, detected from the alpha channel of the arm layer.
            </li>
          </ul>
          <SectionTitle>Applying a skin</SectionTitle>
          <ul className="space-y-2">
            {uploads.map((u) => (
              <li key={u.title} className="panel-2 p-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">{u.title}</span>
                  <Pill tone={u.ok ? "accent" : "muted"}>{u.ok ? "available" : "needs sign-in"}</Pill>
                </div>
                <p className="mt-1 text-[11px] leading-relaxed text-[var(--muted)]">{u.body}</p>
              </li>
            ))}
          </ul>
        </Panel>

        <Panel title="Cape">
          {activeAccount?.cape ? (
            <div className="space-y-2">
              <img src={activeAccount.cape} alt="cape" className="h-24 rounded-lg bg-black/30 p-2" />
              <p className="text-[11px] text-[var(--muted)]">This is the cape attached to your authenticated Minecraft profile.</p>
            </div>
          ) : (
            <p className="text-xs text-[var(--muted)]">No cape on this account.</p>
          )}
          <p className="mt-3 text-[11px] leading-relaxed text-[var(--muted)]">
            A locally imported cape cannot appear on vanilla multiplayer servers — the server decides what a client may draw. Custom capes are
            possible through the cosmetic mod ecosystem (OptiFine-style capes, or mods like Cape), and the launcher will tell you which path a
            given cape needs instead of promising server-side rendering.
          </p>
          {capes.length > 0 && (
            <div className="mt-2">
              <SectionTitle>Cosmetic packs queued</SectionTitle>
              {capes.map((c) => (
                <div key={c.slug} className="panel-2 mb-1 px-3 py-2 text-xs">{c.title}</div>
              ))}
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}

/** Head + body preview drawn from a live skin image. */
function PreviewCanvas({ skinUrl }: { skinUrl: string }) {
  const [dataUrl, setDataUrl] = useState<string | null>(null);
  const [model, setModel] = useState<"classic" | "slim">("classic");

  useEffect(() => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const c = document.createElement("canvas");
      c.width = 64;
      c.height = 64;
      const ctx = c.getContext("2d");
      if (!ctx) return;
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(img, 0, 0);
      let slim = false;
      try {
        const d = ctx.getImageData(54, 20, 2, 12).data;
        let transparent = 0;
        for (let i = 3; i < d.length; i += 4) if (d[i] === 0) transparent++;
        slim = transparent > 6;
      } catch {
        /* tainted canvas — keep classic */
      }
      setModel(slim ? "slim" : "classic");
      setDataUrl(c.toDataURL());
    };
    img.onerror = () => setDataUrl(null);
    img.src = skinUrl;
  }, [skinUrl]);

  if (!dataUrl) {
    return (
      <div className="flex h-64 w-full items-center justify-center rounded-xl border border-dashed hairline text-xs text-[var(--muted)]">
        Skin image unavailable (offline or CORS-blocked)
      </div>
    );
  }

  const layer = (x: number, y: number, _w: number, _h: number, dx: number, dy: number, dw: number, dh: number, dim = 0) => (
    <div
      style={{
        position: "absolute",
        backgroundImage: `url(${dataUrl})`,
        backgroundSize: "640% 640%",
        backgroundPosition: `-${(x / 64) * 640}% -${(y / 64) * 640}%`,
        left: dx,
        top: dy,
        width: dw,
        height: dh,
        imageRendering: "pixelated",
        filter: dim ? `brightness(${1 - dim})` : undefined,
      }}
    />
  );

  const u = 1; // unit scale
  const armW = model === "slim" ? 3 * u * 4 : 4 * u * 4;
  const W = 260;
  const cx = W / 2 - 8 * u * 4 / 2;

  return (
    <div className="floaty relative" style={{ width: W, height: 300 }}>
      {layer(8, 8, 8, 8, cx, 10, 64, 64)}
      {layer(0, 8, 8, 8, cx - 64, 12, 64, 64, 0.25)}
      {layer(16, 8, 8, 8, cx + 64, 12, 64, 64, 0.35)}
      {layer(20, 20, 8, 12, cx, 78, 64, 96)}
      {layer(44, 20, model === "slim" ? 3 : 4, 12, cx + 64, 78, armW, 96, 0.1)}
      {layer(36, 20, model === "slim" ? 3 : 4, 12, cx - armW, 78, armW, 96, 0.18)}
      {layer(4, 20, 4, 12, cx, 178, 64, 96, 0.12)}
      {layer(12, 20, 4, 12, cx + 64, 178, 64, 96, 0.2)}
      <div className={cn("mono absolute -bottom-1 left-0 right-0 text-center text-[10px] uppercase tracking-widest text-[var(--muted)]")}>{model} model</div>
    </div>
  );
}
