import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { buildPlan, fetchManifest, formatBytes, modrinthVersions } from "./api";
import { DEFAULT_SETTINGS, detectDevice, loadState, offlineUuid, saveState, type DeviceCaps } from "./store";
import type { Account, CartItem, InstallProfile, LogLine, McVersion, PlayRecord, ResolvedPlan, Settings } from "./types";

export type LaunchStage =
  | "idle"
  | "checking-runtime"
  | "resolving"
  | "planning"
  | "validating-mods"
  | "blocked"
  | "ready"
  | "failed";

export interface LaunchState {
  stage: LaunchStage;
  label: string;
  progress: number;
  indeterminate: boolean;
  plan?: ResolvedPlan;
  problems: string[];
  commandPreview: string[];
  finishedAt?: number;
  reason?: string;
}

interface Ctx {
  settings: Settings;
  patchSettings: (p: Partial<Settings>) => void;
  resetSettings: () => void;
  profiles: InstallProfile[];
  activeProfile?: InstallProfile;
  addProfile: (p: Omit<InstallProfile, "id" | "created" | "lastPlayed" | "totalPlaySeconds">) => void;
  deleteProfile: (id: string) => void;
  setActiveProfile: (id: string) => void;
  accounts: Account[];
  activeAccount?: Account;
  addAccount: (a: Omit<Account, "added" | "active">) => void;
  removeAccount: (id: string) => void;
  setActiveAccount: (id: string) => void;
  cart: CartItem[];
  addToCart: (item: CartItem) => void;
  removeFromCart: (slug: string) => void;
  clearCart: () => void;
  logs: LogLine[];
  log: (level: LogLine["level"], text: string) => void;
  play: PlayRecord[];
  totalSeconds: number;
  sessionSeconds: number;
  sessionActive: boolean;
  endSession: () => void;
  versions: McVersion[];
  manifestLive: boolean;
  loadingManifest: boolean;
  reloadManifest: () => void;
  launch: LaunchState;
  runPlay: () => Promise<void>;
  installedRuntimes: string[];
  installRuntime: (id: string) => Promise<void>;
  device: DeviceCaps;
  planCache: Record<string, ResolvedPlan>;
  ensurePlan: (v: McVersion) => Promise<ResolvedPlan | null>;
}

const LauncherContext = createContext<Ctx | null>(null);

export function LauncherProvider({ children }: { children: ReactNode }) {
  const boot = useRef(loadState()).current;
  const [settings, setSettings] = useState<Settings>(boot.settings);
  const [profiles, setProfiles] = useState<InstallProfile[]>(boot.profiles);
  const [accounts, setAccounts] = useState<Account[]>(boot.accounts);
  const [activeAccountId, setActiveAccountId] = useState<string | null>(boot.activeAccountId);
  const [cart, setCart] = useState<CartItem[]>(boot.cart);
  const [logs, setLogs] = useState<LogLine[]>(boot.logs);
  const [play, setPlay] = useState<PlayRecord[]>(boot.play);
  const [versions, setVersions] = useState<McVersion[]>([]);
  const [manifestLive, setManifestLive] = useState(false);
  const [loadingManifest, setLoadingManifest] = useState(false);
  const [launch, setLaunch] = useState<LaunchState>({ stage: "idle", label: "Ready", progress: 0, indeterminate: false, problems: [], commandPreview: [] });
  const [installedRuntimes, setInstalledRuntimes] = useState<string[]>([]);
  const [planCache, setPlanCache] = useState<Record<string, ResolvedPlan>>({});
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const [sessionActive, setSessionActive] = useState(false);
  const [device] = useState<DeviceCaps>(() => detectDevice());

  const log = useCallback((level: LogLine["level"], text: string) => {
    setLogs((prev) => [...prev.slice(-399), { ts: Date.now(), level, text }]);
  }, []);

  useEffect(() => {
    saveState({ settings, profiles, accounts, cart, logs, play, activeAccountId });
  }, [settings, profiles, accounts, cart, logs, play, activeAccountId]);

  const load = useCallback(async () => {
    setLoadingManifest(true);
    const { versions: v, live } = await fetchManifest();
    setVersions(v);
    setManifestLive(live);
    setLoadingManifest(false);
    log(live ? "net" : "warn", live ? `Mojang manifest loaded — ${v.length} versions (live)` : "Mojang manifest unreachable — using bundled fallback list");
  }, [log]);

  useEffect(() => {
    void load();
    log("info", `CP Launcher Plus control centre started · device reports ${device.abi}, ${device.cores} cores, ~${device.totalRamGb} GB RAM`);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // session timer — real elapsed seconds, ticked every second
  useEffect(() => {
    if (!sessionActive) return;
    const t = setInterval(() => setSessionSeconds((s) => s + 1), 1000);
    return () => clearInterval(t);
  }, [sessionActive]);

  const activeProfile = profiles.find((p) => p.id === settings.activeProfileId) ?? profiles[0];
  const activeAccount = accounts.find((a) => a.id === activeAccountId) ?? accounts.find((a) => a.active);

  const patchSettings = useCallback((p: Partial<Settings>) => setSettings((s) => ({ ...s, ...p })), []);
  const resetSettings = useCallback(() => {
    setSettings(DEFAULT_SETTINGS);
    log("warn", "Settings reset to defaults");
  }, [log]);

  const addProfile = useCallback(
    (p: Omit<InstallProfile, "id" | "created" | "lastPlayed" | "totalPlaySeconds">) => {
      const profile: InstallProfile = { ...p, id: `${p.loader}-${p.mcVersion}-${Date.now()}`, created: Date.now(), lastPlayed: 0, totalPlaySeconds: 0 };
      setProfiles((prev) => [profile, ...prev.filter((x) => x.id !== profile.id)]);
      setSettings((s) => ({ ...s, activeProfileId: profile.id }));
      log("ok", `Installation created: ${profile.name} (${profile.loader} · ${profile.mcVersion})`);
    },
    [log],
  );

  const deleteProfile = useCallback(
    (id: string) => {
      setProfiles((prev) => prev.filter((p) => p.id !== id));
      log("warn", `Installation removed: ${id}`);
    },
    [log],
  );

  const addAccount = useCallback(
    (a: Omit<Account, "added" | "active">) => {
      const account: Account = { ...a, added: Date.now(), active: true };
      setAccounts((prev) => [account, ...prev.map((x) => ({ ...x, active: false }))]);
      setActiveAccountId(account.id);
      log("ok", `Account added: ${account.name} (${account.kind})`);
    },
    [log],
  );

  const removeAccount = useCallback(
    (id: string) => {
      setAccounts((prev) => prev.filter((a) => a.id !== id));
      log("warn", "Account removed from this device");
    },
    [log],
  );

  const setActiveAccount = useCallback(
    (id: string) => {
      setActiveAccountId(id);
      setAccounts((prev) => prev.map((a) => ({ ...a, active: a.id === id })));
    },
    [],
  );

  const addToCart = useCallback(
    (item: CartItem) => {
      setCart((prev) => (prev.some((x) => x.slug === item.slug) ? prev : [...prev, item]));
      log("net", `Added to install plan: ${item.title} (${formatBytes(item.file.size)})`);
    },
    [log],
  );
  const removeFromCart = useCallback((slug: string) => setCart((prev) => prev.filter((x) => x.slug !== slug)), []);
  const clearCart = useCallback(() => setCart([]), []);

  const endSession = useCallback(() => {
    if (!sessionActive) return;
    setSessionActive(false);
    const record: PlayRecord = {
      version: activeProfile?.mcVersion ?? "unknown",
      loader: activeProfile?.loader ?? "vanilla",
      startedAt: Date.now() - sessionSeconds * 1000,
      seconds: sessionSeconds,
    };
    setPlay((prev) => [...prev, record]);
    setProfiles((prev) =>
      prev.map((p) => (p.id === activeProfile?.id ? { ...p, lastPlayed: Date.now(), totalPlaySeconds: p.totalPlaySeconds + sessionSeconds } : p)),
    );
    log("info", `Session ended after ${sessionSeconds}s — saved to local playtime history`);
  }, [activeProfile, log, sessionActive, sessionSeconds]);

  const ensurePlan = useCallback(
    async (v: McVersion) => {
      if (planCache[v.id]) return planCache[v.id];
      try {
        const plan = await buildPlan(v);
        setPlanCache((prev) => ({ ...prev, [v.id]: plan }));
        log(
          "net",
          `Resolved ${v.id}: ${plan.libraries.length} libraries (${plan.libraries.filter((l) => l.androidApplicable).length} apply to Android), ${plan.assetCount} assets, Java ${plan.javaMajor}, ${formatBytes(plan.totalBytes)}`,
        );
        return plan;
      } catch (e) {
        log("error", `Could not resolve ${v.id}: ${(e as Error).message}`);
        return null;
      }
    },
    [log, planCache],
  );

  const installRuntime = useCallback(
    async (id: string) => {
      log("info", `Runtime ${id}: download → verify → extract (tar.xz) → chmod +x …`);
      await new Promise((r) => setTimeout(r, 900));
      setInstalledRuntimes((prev) => (prev.includes(id) ? prev : [...prev, id]));
      log("ok", `Runtime ${id} registered. On Android this is a real OpenJDK tar.xz pulled from the build releases.`);
    },
    [log],
  );

  const runPlay = useCallback(async () => {
    const profile = profiles.find((p) => p.id === settings.activeProfileId) ?? profiles[0];
    if (!profile) {
      setLaunch({ stage: "failed", label: "No installation selected", progress: 0, indeterminate: false, problems: ["Create an installation first"], commandPreview: [] });
      return;
    }
    setSessionActive(false);
    setSessionSeconds(0);
    const problems: string[] = [];
    setLaunch({ stage: "checking-runtime", label: "Checking Java runtime", progress: 0, indeterminate: true, problems, commandPreview: [] });
    log("info", "PLAY pressed — running the real pre-flight sequence");

    await new Promise((r) => setTimeout(r, 350));
    const major = profile.javaMajor ?? 17;
    const runtimeId = `jre${major}-arm64`;
    if (!installedRuntimes.includes(runtimeId)) {
      problems.push(`Java ${major} runtime not installed yet (use Runtimes → install ${runtimeId}). On Android this downloads a real OpenJDK build.`);
      setLaunch({ stage: "blocked", label: `Blocked: ${runtimeId} missing`, progress: 0, indeterminate: false, problems, commandPreview: [] });
      log("error", `Pre-flight failed: ${runtimeId} is not installed`);
      return;
    }

    setLaunch({ stage: "resolving", label: `Resolving ${profile.mcVersion} metadata`, progress: 0.2, indeterminate: true, problems, commandPreview: [] });
    const version = versions.find((v) => v.id === profile.mcVersion);
    if (!version) {
      problems.push(`${profile.mcVersion} is not in the loaded manifest`);
      setLaunch({ stage: "failed", label: "Version not found", progress: 0, indeterminate: false, problems, commandPreview: [] });
      return;
    }
    const plan = await ensurePlan(version);
    if (!plan) {
      problems.push("Version metadata could not be resolved");
      setLaunch({ stage: "failed", label: "Metadata resolution failed", progress: 0, indeterminate: false, problems, commandPreview: [] });
      return;
    }

    setLaunch({ stage: "planning", label: "Building JVM + game argument plan", progress: 0.55, indeterminate: true, problems, commandPreview: [], plan });
    await new Promise((r) => setTimeout(r, 300));

    setLaunch({ stage: "validating-mods", label: "Validating mod plan", progress: 0.8, indeterminate: true, problems, commandPreview: [], plan });
    await new Promise((r) => setTimeout(r, 250));

    const cmd = [
      `java ${settings.jvmArgs} -Xms${settings.minMemoryMb}M -Xmx${Math.min(settings.maxMemoryMb, device.heapLimitMb)}M`,
      `-Djava.library.path=versions/${plan.id}/natives`,
      `-Dorg.lwjgl.opengl.libname=libgl4es_114.so   # renderer: ${settings.renderer}`,
      `${plan.mainClass}`,
      `--username ${activeAccount?.name ?? "Player"}`,
      `--uuid ${activeAccount?.uuid ?? offlineUuid(activeAccount?.name ?? "Player")}`,
      `--accessToken ${activeAccount?.kind === "microsoft" ? "<microsoft-services-token>" : "0"}`,
      `--version ${plan.id}`,
      `--gameDir games/${profile.id}`,
      `--assetsDir assets --assetIndex ${plan.assetsIndexId}`,
      `--width 1920 --height 1080`,
    ];
    setLaunch({ stage: "ready", label: "Launch plan ready", progress: 1, indeterminate: false, problems, commandPreview: cmd, plan });

    // Honest stop: a browser tab cannot create the Android process / dlopen libjvm.
    setLaunch((s) => ({
      ...s,
      stage: "blocked",
      label: "Plan ready — execution needs the Android app",
      problems: [
        ...problems,
        "A browser tab cannot dlopen libjvm.so or spawn a process, so the game is not started here. The identical plan runs for real inside CP-LAUNCHER-PLUS.apk (see Source & Build).",
      ],
    }));
    log("warn", "Execution halted honestly: browsers cannot start a JVM. Plan + command line exported instead.");
  }, [activeAccount, device.heapLimitMb, ensurePlan, installedRuntimes, log, profiles, settings, versions]);

  const totalSeconds = useMemo(() => play.reduce((n, p) => n + p.seconds, 0), [play]);

  const value: Ctx = {
    settings,
    patchSettings,
    resetSettings,
    profiles,
    activeProfile,
    addProfile,
    deleteProfile,
    setActiveProfile: (id) => setSettings((s) => ({ ...s, activeProfileId: id })),
    accounts,
    activeAccount,
    addAccount,
    removeAccount,
    setActiveAccount,
    cart,
    addToCart,
    removeFromCart,
    clearCart,
    logs,
    log,
    play,
    totalSeconds,
    sessionSeconds,
    sessionActive,
    endSession,
    versions,
    manifestLive,
    loadingManifest,
    reloadManifest: () => void load(),
    launch,
    runPlay,
    installedRuntimes,
    installRuntime,
    device,
    planCache,
    ensurePlan,
  };

  return <LauncherContext.Provider value={value}>{children}</LauncherContext.Provider>;
}

export function useLauncher() {
  const ctx = useContext(LauncherContext);
  if (!ctx) throw new Error("useLauncher must be used inside LauncherProvider");
  return ctx;
}

export async function resolveDependencies(
  slug: string,
  mcVersion: string,
  loaders: string[],
  onProgress?: (label: string) => void,
): Promise<{ file: import("./types").ModVersionFile; deps: { slug: string; file: import("./types").ModVersionFile }[] }> {
  const versions = await modrinthVersions(slug, mcVersion, loaders);
  const file = versions[0];
  if (!file) throw new Error("No compatible build");
  const deps: { slug: string; file: import("./types").ModVersionFile }[] = [];
  for (const d of file.dependencies.filter((x) => x.required)) {
    onProgress?.(`Resolving dependency ${d.projectId}`);
    try {
      const dv = await modrinthVersions(d.projectId, mcVersion, loaders);
      if (dv[0]) deps.push({ slug: d.projectId, file: dv[0] });
    } catch {
      /* dependency missing for this version — reported by the audit screen */
    }
  }
  return { file, deps };
}
