/** Shared types for the CP Launcher Plus control centre. */

export type Loader = "vanilla" | "fabric" | "forge" | "neoforge" | "quilt";

export interface McVersion {
  id: string;
  type: "release" | "snapshot" | "old_beta" | "old_alpha";
  url: string;
  releaseTime: string;
  sha1?: string;
}

export interface InstallProfile {
  id: string;
  name: string;
  mcVersion: string;
  loader: Loader;
  loaderVersion?: string;
  lastPlayed: number;
  totalPlaySeconds: number;
  created: number;
  plannedBytes?: number;
  libraries?: number;
  assets?: number;
  javaMajor?: number;
}

export interface LibraryEntry {
  name: string;
  path: string;
  url: string;
  size: number;
  sha1: string;
  androidApplicable: boolean;
  desktopOnly: boolean;
}

export interface ResolvedPlan {
  id: string;
  mainClass: string;
  assetsIndexId: string;
  javaMajor: number;
  clientSize: number;
  totalBytes: number;
  libraries: LibraryEntry[];
  assetCount: number;
  rulesJson: string;
}

export interface ModSearchHit {
  slug: string;
  title: string;
  description: string;
  downloads: number;
  icon: string | null;
  loaders: string[];
  categories: string[];
  projectType: string;
  follows: number;
  dateModified: string;
}

export interface ModVersionFile {
  versionId: string;
  versionNumber: string;
  filename: string;
  url: string;
  size: number;
  sha1: string;
  gameVersions: string[];
  loaders: string[];
  dependencies: { projectId: string; required: boolean }[];
  changelog?: string;
}

export interface CartItem {
  slug: string;
  title: string;
  file: ModVersionFile;
  kind: "mod" | "shader" | "resourcepack";
}

export interface PackEntry {
  name: string;
  fileName: string;
  kind: "shader" | "resourcepack";
  sizeBytes: number;
  compatible: boolean;
  requiresRenderer?: string;
  description: string;
}

export interface Account {
  id: string;
  name: string;
  uuid: string;
  kind: "microsoft" | "offline";
  ownsGame?: boolean;
  skin?: string | null;
  cape?: string | null;
  active: boolean;
  added: number;
  verified?: "verified" | "unverified" | "demo";
}

export interface Settings {
  theme: "dark" | "light" | "amoled";
  accent: string;
  activeProfileId: string;
  renderer: string;
  fpsLimit: number;
  renderDistance: number;
  simulationDistance: number;
  particles: string;
  entityDistance: number;
  uiScale: number;
  vsync: boolean;
  fullscreen: boolean;
  maxMemoryMb: number;
  minMemoryMb: number;
  jvmArgs: string;
  performanceProfile: string;
  concurrentDownloads: number;
  autoUpdate: boolean;
  discordPresence: boolean;
  discordSessionTime: boolean;
  discordVersion: boolean;
  showAdvancedLogs: boolean;
  msClientId: string;
}

export interface LogLine {
  ts: number;
  level: "info" | "ok" | "warn" | "error" | "net";
  text: string;
}

export interface PlayRecord {
  version: string;
  loader: Loader;
  startedAt: number;
  seconds: number;
}

export type FetchState = "idle" | "loading" | "ok" | "error";
