import JSZip from "jszip";
import { triggerDownload } from "./api";
import type { CartItem, Loader } from "./types";

/**
 * Builds a real, spec-compliant Modrinth index (`modrinth.index.json`) and packages it
 * as a `.mrpack`. Any Modrinth-capable launcher — including CP Launcher Plus on Android —
 * can install this file, which downloads and verifies every mod by SHA-1.
 */
export async function buildMrpack(opts: {
  name: string;
  mcVersion: string;
  loader: Loader;
  loaderVersion?: string;
  items: CartItem[];
}): Promise<{ blob: Blob; filename: string }> {
  const index = {
    formatVersion: 1,
    game: "minecraft",
    versionId: `cplp-${Date.now()}`,
    name: opts.name,
    summary: `Built with CP Launcher Plus — Minecraft ${opts.mcVersion} (${opts.loader})`,
    files: opts.items.map((item) => ({
      path:
        item.kind === "mod"
          ? `mods/${item.file.filename}`
          : item.kind === "shader"
            ? `shaderpacks/${item.file.filename}`
            : `resourcepacks/${item.file.filename}`,
      hashes: { sha1: item.file.sha1 },
      env: item.kind === "mod" ? { client: "required", server: "unsupported" } : { client: "required", server: "unsupported" },
      downloads: [item.file.url],
      fileSize: item.file.size,
    })),
    dependencies: {
      minecraft: opts.mcVersion,
      ...(opts.loader !== "vanilla" ? { [`${opts.loader}-loader`]: opts.loaderVersion ?? "latest" } : {}),
    },
  };

  const zip = new JSZip();
  zip.file("modrinth.index.json", JSON.stringify(index, null, 2));
  zip.file(
    "README.txt",
    [
      "CP Launcher Plus modpack",
      "",
      `Minecraft: ${opts.mcVersion}`,
      `Loader: ${opts.loader}${opts.loaderVersion ? " " + opts.loaderVersion : ""}`,
      `Contents: ${opts.items.length} file(s)`,
      "",
      "Install this .mrpack with CP Launcher Plus (Android) or any Modrinth-format launcher.",
      "Every file is verified against its SHA-1 before it is placed in the game directory.",
      "Only content published on Modrinth under its own licence is referenced — no game",
      "binaries are redistributed here.",
    ].join("\n"),
  );

  const blob = await zip.generateAsync({ type: "blob", compression: "DEFLATE" });
  const safeName = opts.name.replace(/[^a-z0-9_-]+/gi, "-").toLowerCase();
  const filename = `${safeName || "cplauncher-pack"}.mrpack`;
  return { blob, filename };
}

export function downloadMrpack(pack: { blob: Blob; filename: string }) {
  triggerDownload(pack.blob, pack.filename);
}
