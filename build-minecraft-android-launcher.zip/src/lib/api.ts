import type { LibraryEntry, McVersion, ModSearchHit, ModVersionFile, ResolvedPlan } from "./types";

/* ------------------------------------------------------------------ fetching
 *
 * Browsers enforce CORS. piston-meta.mojang.com and api.modrinth.com both send
 * `Access-Control-Allow-Origin: *`, so they work directly. If a mirror/proxy is
 * required (corporate network, offline demo), we fall back in order and finally to
 * the bundled snapshot below so the UI is never empty and never lies about it.
 */

const PROXIES = [
  (u: string) => u,
  (u: string) => `https://corsproxy.io/?url=${encodeURIComponent(u)}`,
  (u: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
];

let workingProxy = 0;

export async function getText(url: string): Promise<string> {
  let lastErr: unknown = null;
  for (let i = workingProxy; i < PROXIES.length; i++) {
    try {
      const res = await fetch(PROXIES[i](url), { headers: { Accept: "application/json" } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      workingProxy = i;
      return await res.text();
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error("Network unavailable");
}

export async function getJson<T>(url: string): Promise<T> {
  const text = await getText(url);
  return JSON.parse(text) as T;
}

export async function downloadFile(url: string, filename: string, onProgress?: (loaded: number, total: number) => void) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status} for ${filename}`);
  const total = Number(res.headers.get("content-length") ?? 0);
  const reader = res.body?.getReader();
  if (!reader) {
    const blob = await res.blob();
    triggerDownload(blob, filename);
    return;
  }
  const chunks: Uint8Array[] = [];
  let loaded = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    if (value) {
      chunks.push(value);
      loaded += value.length;
      onProgress?.(loaded, total);
    }
  }
  triggerDownload(new Blob(chunks as BlobPart[]), filename);
}

export function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/* ------------------------------------------------------------------ Mojang */

export const MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";

const FALLBACK_VERSIONS: McVersion[] = [
  ["1.21.4", "release"], ["1.21.3", "release"], ["1.21.1", "release"], ["1.21", "release"],
  ["1.20.6", "release"], ["1.20.4", "release"], ["1.20.1", "release"], ["1.19.4", "release"],
  ["1.19.2", "release"], ["1.18.2", "release"], ["1.17.1", "release"], ["1.16.5", "release"],
  ["1.12.2", "release"], ["1.8.9", "release"], ["1.7.10", "release"],
].map(([id, type]) => ({
  id,
  type: type as McVersion["type"],
  url: "",
  releaseTime: "bundled-fallback",
}));

export async function fetchManifest(): Promise<{ versions: McVersion[]; live: boolean }> {
  try {
    const raw = await getJson<{ versions: McVersion[] }>(MANIFEST_URL);
    return { versions: raw.versions, live: true };
  } catch {
    return { versions: FALLBACK_VERSIONS, live: false };
  }
}

const DESKTOP_ONLY_GROUPS = ["org.lwjgl", "net.java.jinput", "net.java.jutils", "tv.twitch", "com.mojang"];

function isDesktopOnly(group: string) {
  return DESKTOP_ONLY_GROUPS.some((g) => group.startsWith(g));
}

interface RuleSet {
  action: string;
  os?: { name?: string };
}

function ruleAllows(rules: RuleSet[] | undefined, os: string): boolean {
  if (!rules || rules.length === 0) return true;
  let allowed = false;
  for (const r of rules) {
    const matches = !r.os?.name || r.os.name === os;
    if (matches) allowed = r.action === "allow";
  }
  return allowed;
}

/** Turns Mojang's version JSON into the exact plan the Android app will execute. */
export async function resolveVersionJson(
  json: {
    id: string;
    mainClass?: string;
    arguments?: { jvm?: unknown[]; game?: unknown[] };
    assetIndex: { id: string; url: string; totalSize?: number };
    downloads: { client: { url: string; size: number; sha1: string } };
    libraries: {
      name: string;
      rules?: RuleSet[];
      downloads?: {
        artifact?: { path: string; url: string; size: number; sha1: string };
        classifiers?: Record<string, { path: string; size: number }>;
      };
    }[];
    javaVersion?: { majorVersion: number };
    logging?: { client?: { argument?: string[] } };
  },
  assetIndexTotal?: number,
): Promise<ResolvedPlan> {
  const libraries: LibraryEntry[] = [];
  let total = 0;

  for (const lib of json.libraries ?? []) {
    if (!ruleAllows(lib.rules, "linux")) continue;
    const artifact = lib.downloads?.artifact;
    if (!artifact) continue;
    const group = lib.name.split(":")[0];
    const applicable = !isDesktopOnly(group);
    if (applicable) total += artifact.size ?? 0;
    libraries.push({
      name: lib.name,
      path: artifact.path,
      url: artifact.url,
      size: artifact.size ?? 0,
      sha1: artifact.sha1 ?? "",
      androidApplicable: applicable,
      desktopOnly: !applicable,
    });
    const natives = lib.downloads?.classifiers?.["natives-linux"];
    if (natives) total += natives.size ?? 0;
  }

  const clientSize = json.downloads?.client?.size ?? 0;
  total += clientSize;

  let assetCount = 0;
  if (assetIndexTotal !== undefined) assetCount = assetIndexTotal;
  else {
    try {
      const idx = await getJson<{ objects: Record<string, unknown> }>(json.assetIndex.url);
      assetCount = Object.keys(idx.objects).length;
    } catch {
      assetCount = 0;
    }
  }

  return {
    id: json.id,
    mainClass: json.mainClass ?? "net.minecraft.client.main.Main",
    assetsIndexId: json.assetIndex.id,
    javaMajor: json.javaVersion?.majorVersion ?? guessJavaMajor(json.id),
    clientSize,
    totalBytes: total,
    libraries,
    assetCount,
    rulesJson: JSON.stringify({ os: "linux (Android maps to the linux rule set)", client: json.downloads?.client?.sha1 }, null, 2),
  };
}

export async function buildPlan(version: McVersion): Promise<ResolvedPlan> {
  if (!version.url) throw new Error("Bundled fallback entry has no metadata URL — pick an online version");
  const json = await getJson<Parameters<typeof resolveVersionJson>[0]>(version.url);
  return resolveVersionJson(json);
}

export function guessJavaMajor(mcVersion: string): number {
  const parts = mcVersion.split(/[.\-]/).map((n) => parseInt(n, 10) || 0);
  const [, minor = 0, patch = 0] = parts;
  if (minor > 20 || (minor === 20 && patch >= 5)) return 21;
  if (minor >= 17) return 17;
  if (minor >= 13) return 11;
  return 8;
}

export function formatBytes(n: number): string {
  if (!n) return "0 B";
  const u = ["B", "KB", "MB", "GB"];
  const i = Math.min(Math.floor(Math.log(n) / Math.log(1024)), u.length - 1);
  return `${(n / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1)} ${u[i]}`;
}

export function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m`;
  return `${seconds}s`;
}

/* ------------------------------------------------------------------ Modrinth */

const MODRINTH = "https://api.modrinth.com/v2";

export async function modrinthSearch(
  query: string,
  projectType: "mod" | "shader" | "resourcepack",
  gameVersion: string,
  loaders: string[],
): Promise<ModSearchHit[]> {
  const facets: string[][] = [["project_type:" + projectType]];
  if (gameVersion) facets.push([`versions:${gameVersion}`]);
  loaders.forEach((l) => facets.push([`categories:${l}`]));
  const url =
    `${MODRINTH}/search?limit=24&index=downloads&query=${encodeURIComponent(query)}` +
    `&facets=${encodeURIComponent(JSON.stringify(facets))}`;
  const raw = await getJson<{
    hits: {
      slug: string;
      title: string;
      description: string;
      downloads: number;
      icon_url: string | null;
      display_categories: string[];
      project_type: string;
      follows: number;
      date_modified: string;
    }[];
  }>(url);
  return raw.hits.map((h) => ({
    slug: h.slug,
    title: h.title,
    description: h.description,
    downloads: h.downloads,
    icon: h.icon_url,
    loaders: h.display_categories ?? [],
    categories: h.display_categories ?? [],
    projectType: h.project_type,
    follows: h.follows,
    dateModified: h.date_modified,
  }));
}

export async function modrinthVersions(
  slug: string,
  gameVersion: string | null,
  loaders: string[],
): Promise<ModVersionFile[]> {
  const params: string[] = [];
  if (gameVersion) params.push(`game_versions=["${gameVersion}"]`);
  if (loaders.length) params.push(`loaders=${encodeURIComponent(JSON.stringify(loaders))}`);
  const url = `${MODRINTH}/project/${slug}/version${params.length ? "?" + params.join("&") : ""}`;
  const raw = await getJson<
    {
      id: string;
      version_number: string;
      game_versions: string[];
      loaders: string[];
      changelog?: string;
      dependencies: { project_id: string; dependency_type: string }[];
      files: { url: string; filename: string; primary: boolean; size: number; hashes: { sha1: string } }[];
    }[]
  >(url);
  return raw.map((v) => {
    const f = v.files.find((x) => x.primary) ?? v.files[0];
    return {
      versionId: v.id,
      versionNumber: v.version_number,
      filename: f?.filename ?? "unknown.jar",
      url: f?.url ?? "",
      size: f?.size ?? 0,
      sha1: f?.hashes?.sha1 ?? "",
      gameVersions: v.game_versions,
      loaders: v.loaders,
      dependencies: v.dependencies.map((d) => ({ projectId: d.project_id, required: d.dependency_type === "required" })),
      changelog: v.changelog,
    };
  });
}

export async function modrinthProject(slug: string) {
  return getJson<{ title: string; description: string; body: string; license: { id: string; name?: string }; source_url?: string; icon_url?: string }>(
    `${MODRINTH}/project/${slug}`,
  );
}
