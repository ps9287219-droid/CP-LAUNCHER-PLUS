/**
 * The complete Android source tree of CP-LAUNCHER-PLUS is shipped inside this app so the
 * code can be browsed and exported as a buildable ZIP. Vite inlines each file as a raw
 * string at build time, so the export works fully offline.
 */
const modules = import.meta.glob("../../android/**/*", {
  query: "?raw",
  import: "default",
  eager: true,
}) as Record<string, string>;

export interface SourceFile {
  path: string;      // path relative to android/
  language: string;
  size: number;
  lines: number;
  content: string;
}

function languageOf(path: string): string {
  if (path.endsWith(".kt")) return "kotlin";
  if (path.endsWith(".c") || path.endsWith(".h")) return "c";
  if (path.endsWith(".kts")) return "kotlin-dsl";
  if (path.endsWith(".xml")) return "xml";
  if (path.endsWith(".yml") || path.endsWith(".yaml")) return "yaml";
  if (path.endsWith(".pro")) return "proguard";
  if (path.endsWith(".md")) return "markdown";
  if (path.endsWith(".properties")) return "properties";
  if (path.endsWith("CMakeLists.txt")) return "cmake";
  return "text";
}

export const SOURCE_FILES: SourceFile[] = Object.entries(modules)
  .map(([abs, content]) => {
    const rel = abs.replace(/^.*\/android\//, "android/");
    return {
      path: rel,
      language: languageOf(rel),
      size: new Blob([content]).size,
      lines: content.split("\n").length,
      content,
    };
  })
  .sort((a, b) => a.path.localeCompare(b.path));

export const SOURCE_TOTAL_BYTES = SOURCE_FILES.reduce((n, f) => n + f.size, 0);
export const SOURCE_TOTAL_LINES = SOURCE_FILES.reduce((n, f) => n + f.lines, 0);

export interface TreeNode {
  name: string;
  path: string;
  children: TreeNode[];
  file?: SourceFile;
}

export function buildTree(files: SourceFile[]): TreeNode {
  const root: TreeNode = { name: "android", path: "android", children: [] };
  for (const f of files) {
    const parts = f.path.split("/");
    let node = root;
    parts.forEach((part, i) => {
      const path = parts.slice(0, i + 1).join("/");
      let next = node.children.find((c) => c.name === part);
      if (!next) {
        next = { name: part, path, children: [] };
        node.children.push(next);
      }
      node = next;
    });
    node.file = f;
  }
  const sort = (n: TreeNode) => {
    n.children.sort((a, b) => {
      const aDir = a.children.length > 0;
      const bDir = b.children.length > 0;
      if (aDir !== bDir) return aDir ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
    n.children.forEach(sort);
  };
  sort(root);
  return root;
}

export const TREE = buildTree(SOURCE_FILES);

export function findFile(path: string): SourceFile | undefined {
  return SOURCE_FILES.find((f) => f.path === path);
}
