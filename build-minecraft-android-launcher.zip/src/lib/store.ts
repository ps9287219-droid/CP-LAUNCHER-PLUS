import type { Account, CartItem, InstallProfile, Loader, LogLine, PlayRecord, Settings } from "./types";

const KEY = "cp-launcher-plus:v1";

export const DEFAULT_SETTINGS: Settings = {
  theme: "dark",
  accent: "#3fd46a",
  activeProfileId: "vanilla-latest",
  renderer: "gl4es_114",
  fpsLimit: 60,
  renderDistance: 8,
  simulationDistance: 6,
  particles: "all",
  entityDistance: 100,
  uiScale: 100,
  vsync: true,
  fullscreen: true,
  maxMemoryMb: 2048,
  minMemoryMb: 512,
  jvmArgs:
    "-XX:+UseG1GC -XX:+UnlockExperimentalVMOptions -XX:G1NewSizePercent=20 -XX:G1ReservePercent=20 -XX:MaxGCPauseMillis=50 -XX:G1HeapRegionSize=32M",
  performanceProfile: "balanced",
  concurrentDownloads: 4,
  autoUpdate: true,
  discordPresence: false,
  discordSessionTime: true,
  discordVersion: true,
  showAdvancedLogs: false,
  msClientId: "",
};

export interface PersistedState {
  settings: Settings;
  profiles: InstallProfile[];
  accounts: Account[];
  cart: CartItem[];
  logs: LogLine[];
  play: PlayRecord[];
  activeAccountId: string | null;
}

const initial: PersistedState = {
  settings: DEFAULT_SETTINGS,
  profiles: [
    {
      id: "vanilla-latest",
      name: "Latest release",
      mcVersion: "1.21.4",
      loader: "vanilla",
      lastPlayed: 0,
      totalPlaySeconds: 0,
      created: Date.now(),
    },
  ],
  accounts: [],
  cart: [],
  logs: [],
  play: [],
  activeAccountId: null,
};

export function loadState(): PersistedState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return initial;
    const parsed = JSON.parse(raw) as Partial<PersistedState>;
    return {
      settings: { ...DEFAULT_SETTINGS, ...(parsed.settings ?? {}) },
      profiles: parsed.profiles?.length ? parsed.profiles : initial.profiles,
      accounts: parsed.accounts ?? [],
      cart: parsed.cart ?? [],
      logs: parsed.logs ?? [],
      play: parsed.play ?? [],
      activeAccountId: parsed.activeAccountId ?? null,
    };
  } catch {
    return initial;
  }
}

export function saveState(state: PersistedState) {
  try {
    localStorage.setItem(KEY, JSON.stringify({ ...state, logs: state.logs.slice(-400) }));
  } catch {
    /* storage full or blocked — the app still works in-memory */
  }
}

/* ------------------------------------------------------------------ device profile */

export interface DeviceCaps {
  abi: string;
  cores: number;
  totalRamGb: number;
  heapLimitMb: number;
  platform: string;
  vulkan: boolean;
  touch: boolean;
  recommendedMemoryMb: number;
  recommendedProfile: "low" | "balanced" | "high";
  warnings: string[];
}

export function detectDevice(): DeviceCaps {
  const nav = navigator as Navigator & { deviceMemory?: number };
  const gb = nav.deviceMemory ?? 4;
  const cores = navigator.hardwareConcurrency ?? 4;
  const arm64 = /aarch64|arm64/i.test(navigator.userAgent);
  const warnings: string[] = [];
  const profile: DeviceCaps["recommendedProfile"] = gb >= 8 && cores >= 6 ? "high" : gb >= 4 ? "balanced" : "low";
  if (gb <= 3) warnings.push("≤3 GB RAM — keep render distance at 4–6 chunks");
  if (cores <= 4) warnings.push("4 or fewer cores — simulation distance above 8 will stutter");
  return {
    abi: arm64 ? "arm64-v8a" : "x86_64 (assumed from desktop UA)",
    cores,
    totalRamGb: gb,
    heapLimitMb: Math.max(1024, Math.round(gb * 1024 * 0.55)),
    platform: navigator.platform,
    vulkan: /android/i.test(navigator.userAgent) ? true : false,
    touch: matchMedia("(pointer: coarse)").matches,
    recommendedMemoryMb: gb >= 12 ? 4096 : gb >= 8 ? 3072 : gb >= 6 ? 2560 : gb >= 4 ? 2048 : 1024,
    recommendedProfile: profile,
    warnings,
  };
}

/* ------------------------------------------------------------------ renderers */

export interface Renderer {
  id: string;
  name: string;
  api: string;
  shaders: boolean;
  note: string;
}

export const RENDERERS: Renderer[] = [
  { id: "gl4es_114", name: "gl4es 1.1.4", api: "OpenGL 2.1 via GLES 2", shaders: false, note: "Most compatible with Android GPUs. No shader-pack support." },
  { id: "zink_vulkan", name: "Zink", api: "OpenGL 4.6 via Vulkan", shaders: true, note: "Shader-capable (with Iris). Needs a Vulkan-capable GPU." },
  { id: "angle_vulkan", name: "ANGLE", api: "GLES 3 via Vulkan", shaders: false, note: "Fast on Adreno; limited desktop-GL feature set." },
  { id: "virgl", name: "VirGL", api: "OpenGL 3.3 proxy", shaders: true, note: "Experimental; used by some Pojav-family forks." },
];

export const PERFORMANCE_PROFILES = {
  low: { fpsLimit: 40, renderDistance: 4, simulationDistance: 4, particles: "minimal", entityDistance: 50, vsync: false, memory: 1536, mods: ["sodium", "lithium", "ferrite-core", "immediatelyfast", "lazydfu"] },
  balanced: { fpsLimit: 60, renderDistance: 8, simulationDistance: 6, particles: "decreased", entityDistance: 100, vsync: true, memory: 2048, mods: ["sodium", "lithium", "ferrite-core"] },
  high: { fpsLimit: 90, renderDistance: 12, simulationDistance: 10, particles: "all", entityDistance: 150, vsync: false, memory: 4096, mods: ["sodium", "lithium", "ferrite-core", "immediatelyfast"] },
  custom: { fpsLimit: 60, renderDistance: 8, simulationDistance: 6, particles: "all", entityDistance: 100, vsync: true, memory: 2048, mods: [] as string[] },
} as const;

export type ProfileId = keyof typeof PERFORMANCE_PROFILES;

export const JAVA_FOR: Record<string, number> = { "8": 8, "11": 11, "17": 17, "21": 21 };

export function loaderSlug(loader: Loader): string[] {
  switch (loader) {
    case "fabric":
      return ["fabric"];
    case "forge":
      return ["forge"];
    case "neoforge":
      return ["neoforge"];
    case "quilt":
      return ["quilt"];
    default:
      return ["fabric"];
  }
}

export function offlineUuid(name: string): string {
  // MD5 is unavailable in browsers' crypto.subtle; this reproduces the same
  // "OfflinePlayer:name" v3 UUID shape with a deterministic non-crypto hash for
  // display purposes. The Android app uses the real MD5 path.
  let h1 = 0x811c9dc5;
  let h2 = 0x1000193;
  const src = "OfflinePlayer:" + name;
  for (let i = 0; i < src.length; i++) {
    h1 = ((h1 ^ src.charCodeAt(i)) * 16777619) >>> 0;
    h2 = ((h2 + src.charCodeAt(i) * (i + 1)) * 2654435761) >>> 0;
  }
  const hex = (n: number, len: number) => n.toString(16).padStart(len, "0");
  const bytes = (hex(h1, 8) + hex(h2, 8) + hex(h1 ^ h2, 8) + hex(h2 ^ h1, 8)).slice(0, 32);
  const u = `${bytes.slice(0, 8)}-${bytes.slice(8, 12)}-3${bytes.slice(13, 16)}-8${bytes.slice(17, 20)}-${bytes.slice(20, 32)}`;
  return u;
}
