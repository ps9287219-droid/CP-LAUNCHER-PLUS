import { useEffect, useState } from "react";
import { LauncherProvider, useLauncher } from "@/lib/useLauncher";
import { HomeScreen } from "@/screens/Home";
import { LibraryScreen } from "@/screens/Library";
import { ModsScreen } from "@/screens/Mods";
import { PacksScreen } from "@/screens/Packs";
import { PerformanceScreen } from "@/screens/Performance";
import { AccountsScreen } from "@/screens/Accounts";
import { CustomizeScreen } from "@/screens/Customize";
import { DiagnosticsScreen } from "@/screens/Diagnostics";
import { SettingsScreen, StatusScreen } from "@/screens/Settings";
import { SourceScreen } from "@/screens/Source";
import { Pill } from "@/components/ui";
import { cn } from "@/utils/cn";

const TABS = [
  { id: "home", label: "Play", icon: "▶" },
  { id: "library", label: "Library", icon: "▤" },
  { id: "mods", label: "Mods", icon: "⬢" },
  { id: "packs", label: "Packs", icon: "◈" },
  { id: "performance", label: "Perf", icon: "⚡" },
  { id: "customize", label: "Skin", icon: "☻" },
  { id: "accounts", label: "Accounts", icon: "◉" },
  { id: "diagnostics", label: "Logs", icon: "≡" },
  { id: "settings", label: "Settings", icon: "⚙" },
  { id: "source", label: "Source", icon: "⌘" },
  { id: "status", label: "Status", icon: "✓" },
];

function Shell() {
  const [tab, setTab] = useState("home");
  const { settings, device, manifestLive, sessionActive } = useLauncher();

  useEffect(() => {
    document.documentElement.style.setProperty("--accent", settings.accent);
    document.documentElement.style.setProperty("--accent-soft", settings.accent + "22");
    document.documentElement.style.setProperty("--accent-line", settings.accent + "66");
    document.documentElement.style.setProperty(
      "--bg",
      settings.theme === "light" ? "#eef2ee" : settings.theme === "amoled" ? "#000000" : "#070a08",
    );
    document.documentElement.style.setProperty(
      "--panel",
      settings.theme === "light" ? "#ffffff" : settings.theme === "amoled" ? "#0a0a0a" : "#0f1512",
    );
    document.documentElement.style.setProperty(
      "--panel-2",
      settings.theme === "light" ? "#f4f7f4" : settings.theme === "amoled" ? "#121212" : "#151d18",
    );
    document.documentElement.style.setProperty("--line", settings.theme === "light" ? "#d7e0d8" : "#22301f");
    document.documentElement.style.setProperty("--text", settings.theme === "light" ? "#0e1511" : "#e8f3ec");
    document.documentElement.style.setProperty("--muted", settings.theme === "light" ? "#5d6f63" : "#93a89a");
  }, [settings.accent, settings.theme]);

  return (
    <div className="flex min-h-screen">
      {/* sidebar — desktop */}
      <aside className="sticky top-0 hidden h-screen w-56 shrink-0 flex-col border-r hairline bg-[var(--panel)] px-3 py-4 lg:flex">
        <div className="mb-5 px-2">
          <div className="mono text-sm font-black tracking-[0.2em] accent-text">CP LAUNCHER</div>
          <div className="mono text-[10px] tracking-[0.3em] text-[var(--muted)]">PLUS · v1.0.0</div>
        </div>
        <nav className="flex-1 space-y-1">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left text-sm transition-colors",
                tab === t.id ? "bg-[var(--accent-soft)] text-[var(--accent)]" : "text-[var(--muted)] hover:bg-white/5 hover:text-[var(--text)]",
              )}
            >
              <span className="mono w-4 text-center text-xs">{t.icon}</span>
              {t.label}
            </button>
          ))}
        </nav>
        <div className="space-y-1.5 px-2">
          <Pill tone={sessionActive ? "accent" : "muted"}>{sessionActive ? "in game" : "idle"}</Pill>
          <p className="text-[10px] leading-relaxed text-[var(--muted)]">{device.abi} · {device.cores} cores</p>
          <p className="text-[10px] leading-relaxed text-[var(--muted)]">{manifestLive ? "Mojang API live" : "Mojang API offline"}</p>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* top bar — mobile */}
        <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b hairline bg-[var(--panel)]/90 px-4 py-3 backdrop-blur lg:hidden">
          <div>
            <div className="mono text-xs font-black tracking-[0.2em] accent-text">CP LAUNCHER PLUS</div>
            <div className="text-[10px] text-[var(--muted)]">Minecraft Java · Android</div>
          </div>
          <Pill tone={sessionActive ? "accent" : "muted"}>{sessionActive ? "in game" : "idle"}</Pill>
        </header>

        <main className="min-w-0 flex-1 px-4 py-5 sm:px-6 lg:px-8">
          {tab === "home" && <HomeScreen onNavigate={setTab} />}
          {tab === "library" && <LibraryScreen />}
          {tab === "mods" && <ModsScreen defaultKind="mod" />}
          {tab === "packs" && <PacksScreen />}
          {tab === "performance" && <PerformanceScreen />}
          {tab === "customize" && <CustomizeScreen />}
          {tab === "accounts" && <AccountsScreen />}
          {tab === "diagnostics" && <DiagnosticsScreen />}
          {tab === "settings" && <SettingsScreen />}
          {tab === "source" && <SourceScreen />}
          {tab === "status" && <StatusScreen />}
        </main>

        {/* bottom nav — mobile */}
        <nav className="sticky bottom-0 z-20 flex overflow-x-auto border-t hairline bg-[var(--panel)]/95 px-2 py-2 backdrop-blur lg:hidden">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex min-w-[62px] flex-col items-center gap-0.5 rounded-lg px-2 py-1 text-[10px]",
                tab === t.id ? "text-[var(--accent)]" : "text-[var(--muted)]",
              )}
            >
              <span className="mono text-sm">{t.icon}</span>
              {t.label}
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <LauncherProvider>
      <Shell />
    </LauncherProvider>
  );
}
