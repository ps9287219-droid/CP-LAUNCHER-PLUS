# Keep Kotlin metadata & coroutines internals used reflectively
-keepattributes *Annotation*,InnerClasses,Signature,Exceptions
-dontwarn org.slf4j.**
-dontwarn org.conscrypt.**
# OkHttp
-dontwarn okhttp3.internal.platform.**
-keepclassmembers class * extends com.google.android.gms.** { *; }
# Coil
-keep class coil.** { *; }
