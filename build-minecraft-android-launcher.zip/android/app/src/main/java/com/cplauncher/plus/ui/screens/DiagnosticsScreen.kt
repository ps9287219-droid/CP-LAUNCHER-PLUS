package com.cplauncher.plus.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cplauncher.plus.CPLauncherApp
import com.cplauncher.plus.LauncherViewModel
import com.cplauncher.plus.core.diag.CrashReporter
import com.cplauncher.plus.core.launch.CrashReporter
import com.cplauncher.plus.ui.common.CpCard
import com.cplauncher.plus.ui.common.SectionTitle
import java.io.File

@Composable
fun DiagnosticsScreen(vm: LauncherViewModel) {
    val state by vm.launchState.collectAsState()
    var selected by remember { mutableStateOf<File?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        SectionTitle("Diagnostics & crash logs")

        CpCard {
            Text("Last launch", style = MaterialTheme.typography.titleMedium)
            Text("Stage: ${state.stage}", style = MaterialTheme.typography.bodySmall)
            Text("Summary: ${state.label}", style = MaterialTheme.typography.bodySmall)
            state.lastError?.let { Text("Report: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
            Spacer(Modifier.height(8.dp))
            Row {
                Button(onClick = {
                    selected = CrashReporter.exportBundle(
                        CPLauncherApp.instance,
                        vm.settings.value.toString(),
                        "accounts stored locally (tokens omitted)",
                    )
                }) { Text("Export diagnostics") }
                Spacer(Modifier.height(0.dp))
                OutlinedButton(onClick = { CrashReporter.clear(CPLauncherApp.instance); selected = null }) { Text("Clear logs") }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("Live log")
        CpCard {
            LazyColumn(Modifier.fillMaxWidth().height(220.dp)) {
                items(state.logs) { line -> Text(line, style = MaterialTheme.typography.bodySmall) }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("Reports on disk")
        val reports = CrashReporter.list(CPLauncherApp.instance)
        if (reports.isEmpty()) Text("No crash reports yet — that is good news.", style = MaterialTheme.typography.bodySmall)
        LazyColumn(Modifier.height(200.dp)) {
            items(reports) { f ->
                CpCard(Modifier.padding(vertical = 4.dp)) {
                    Column {
                        Text(f.name, style = MaterialTheme.typography.titleMedium)
                        Text("${f.length() / 1024} KB", style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { selected = f }) { Text("Open") }
                    }
                }
            }
        }

        selected?.let { f ->
            Spacer(Modifier.height(12.dp))
            SectionTitle("Contents")
            CpCard {
                LazyColumn(Modifier.fillMaxWidth().height(260.dp)) {
                    items(f.readLines()) { line -> Text(line, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
}

/** Small shim so the screen can call the writer without leaking internals. */
object CrashReporterWriter {
    fun write(context: android.content.Context, version: String, logs: List<String>): File =
        CrashReporter.writeCrashReport(context, version, null, logs)
}
