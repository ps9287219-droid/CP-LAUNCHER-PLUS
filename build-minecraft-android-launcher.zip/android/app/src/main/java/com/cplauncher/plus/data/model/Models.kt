package com.cplauncher.plus.data.model

/** A Minecraft Java Edition version as published in Mojang's piston-meta manifest. */
data class McVersion(
    val id: String,
    val type: String,          // release | snapshot | old_beta | old_alpha
    val url: String,
    val releaseTime: String,
    val sha1: String? = null,
)

/** One installed profile inside the launcher (game directory + version + loader). */
data class InstallProfile(
    val id: String,
    val name: String,
    val mcVersion: String,
    val loader: Loader = Loader.VANILLA,
    val loaderVersion: String? = null,
    val gameDirName: String = "default",
    val iconKey: String = "grass",
    val lastPlayed: Long = 0L,
    val totalPlaySeconds: Long = 0L,
    val created: Long = System.currentTimeMillis(),
)

enum class Loader(val displayName: String, val apiSlug: String) {
    VANILLA("Vanilla", "vanilla"),
    FABRIC("Fabric", "fabric"),
    FORGE("Forge", "forge"),
    NEOFORGE("NeoForge", "neoforge"),
    QUILT("Quilt", "quilt"),
}

data class ModEntry(
    val slug: String,
    val title: String,
    val fileName: String,
    val versionId: String,
    val mcVersions: List<String>,
    val loaders: List<String>,
    val enabled: Boolean = true,
    val sizeBytes: Long = 0L,
    val source: String = "modrinth",
    val requiredDependencies: List<String> = emptyList(),
)

data class PackEntry(
    val name: String,
    val fileName: String,
    val kind: Kind,
    val sizeBytes: Long,
    val compatible: Boolean = true,
    val requiresRenderer: String? = null,
    val description: String = "",
) {
    enum class Kind { SHADER, RESOURCE_PACK }
}

sealed class Account(open val id: String, open val name: String) {
    /** Fully authenticated Microsoft / Minecraft Services account. */
    data class Microsoft(
        override val id: String,
        override val name: String,
        val uuid: String,
        val skinUrl: String?,
        val capeUrl: String?,
        val ownsGame: Boolean,
        val lastRefresh: Long,
        val active: Boolean = true,
    ) : Account(id, name)

    /** Local/offline profile, clearly separated from authenticated accounts. */
    data class Offline(
        override val id: String,
        override val name: String,
        val derivedUuid: String,
        val active: Boolean = true,
    ) : Account(id, name)
}

data class Progress(
    val label: String,
    val current: Long = 0,
    val total: Long = 0,
    val indeterminate: Boolean = total <= 0,
) {
    val fraction: Float get() = if (indeterminate) 0f else (current.toDouble() / total.toDouble()).toFloat().coerceIn(0f, 1f)
}

enum class LaunchStage {
    IDLE, PREPARING, DOWNLOADING_RUNTIME, DOWNLOADING_VERSION, DOWNLOADING_ASSETS,
    EXTRACTING_NATIVES, STARTING_JVM, RUNNING, EXITED, CRASHED, FAILED
}

data class SessionLog(
    val ts: Long = System.currentTimeMillis(),
    val level: String,
    val line: String,
)
