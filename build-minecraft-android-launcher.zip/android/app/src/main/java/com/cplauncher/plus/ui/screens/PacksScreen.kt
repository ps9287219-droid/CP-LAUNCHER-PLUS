package com.cplauncher.plus.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cplauncher.plus.LauncherViewModel
import com.cplauncher.plus.core.mods.ModrinthApi
import com.cplauncher.plus.core.packs.PackageManager
import com.cplauncher.plus.data.model.PackEntry
import com.cplauncher.plus.ui.common.CpCard
import com.cplauncher.plus.ui.common.ProgressBar
import com.cplauncher.plus.ui.common.SectionTitle
import com.cplauncher.plus.ui.common.StatusPill
import kotlinx.coroutines.launch

@Composable
fun PacksScreen(vm: LauncherViewModel) {
    val settings by vm.settings.collectAsState()
    val scope = rememberCoroutineScope()
    var kind by remember { mutableStateOf(PackEntry.Kind.SHADER) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<ModrinthApi.SearchResult>>(emptyList()) }
    var progress by remember { mutableStateOf<com.cplauncher.plus.data.model.Progress?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    val manager = PackageManager(com.cplauncher.plus.CPLauncherApp.instance)
    val profile = vm.allProfiles().firstOrNull { it.id == settings.activeProfileId }

    val shaderState = manager.shaderSupportState(settings, setOf("iris"))

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        SectionTitle("Shader packs & resource packs")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = kind == PackEntry.Kind.SHADER, onClick = { kind = PackEntry.Kind.SHADER }, label = { Text("Shaders") })
            FilterChip(selected = kind == PackEntry.Kind.RESOURCE_PACK, onClick = { kind = PackEntry.Kind.RESOURCE_PACK }, label = { Text("Resource packs") })
        }
        Spacer(Modifier.height(8.dp))

        if (kind == PackEntry.Kind.SHADER) {
            CpCard {
                Text("Shader compatibility check", style = MaterialTheme.typography.titleMedium)
                Text(shaderState.message, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
                StatusPill(settings.renderer)
            }
            Spacer(Modifier.height(8.dp))
        }

        SectionTitle("Installed locally")
        val installed = manager.list(kind)
        if (installed.isEmpty()) Text("Nothing installed yet.", style = MaterialTheme.typography.bodySmall)
        installed.forEach { pack ->
            CpCard(Modifier.padding(vertical = 4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(pack.name, style = MaterialTheme.typography.titleMedium)
                        Text(pack.description, style = MaterialTheme.typography.bodySmall)
                    }
                    Text("${pack.sizeBytes / 1024} KB", style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { manager.delete(pack) }) { Text("Delete") }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("Browse")
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search") }, modifier = Modifier.weight(1f))
            Spacer(Modifier.height(0.dp))
            Button(onClick = {
                scope.launch {
                    val type = if (kind == PackEntry.Kind.SHADER) "shader" else "resourcepack"
                    results = runCatching { ModrinthApi().search(query, emptyList(), profile?.mcVersion ?: "", type, 25) }.getOrDefault(emptyList())
                }
            }) { Text("Find") }
        }
        progress?.let { Spacer(Modifier.height(8.dp)); ProgressBar(it.label, it.current, it.total, it.indeterminate) }
        status?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

        LazyColumn(Modifier.fillMaxWidth().height(320.dp)) {
            items(results) { r ->
                CpCard(Modifier.padding(vertical = 4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.title, style = MaterialTheme.typography.titleMedium)
                            Text(r.description, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                        }
                        Button(onClick = {
                            scope.launch {
                                runCatching {
                                    manager.installFromModrinth(r.slug, kind, profile?.mcVersion ?: "") { c, t ->
                                        progress = com.cplauncher.plus.data.model.Progress(r.title, c, t)
                                    }
                                    status = "Installed ${r.title} into the ${if (kind == PackEntry.Kind.SHADER) "shaderpacks" else "resourcepacks"} folder"
                                }.onFailure { status = "Failed: ${it.message}" }
                            }
                        }) { Text("Install") }
                    }
                }
            }
        }
    }
}
