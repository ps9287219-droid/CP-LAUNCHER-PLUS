package com.cplauncher.plus.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.cplauncher.plus.LauncherViewModel
import com.cplauncher.plus.core.skins.SkinManager
import com.cplauncher.plus.ui.common.CpCard
import com.cplauncher.plus.ui.common.SectionTitle
import com.cplauncher.plus.ui.common.StatusPill
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun CustomizeScreen(vm: LauncherViewModel) {
    val accounts by vm.accountsList.collectAsState()
    val settings by vm.settings.collectAsState()
    val scope = rememberCoroutineScope()
    val manager = SkinManager(com.cplauncher.plus.CPLauncherApp.instance)
    var skins by remember { mutableStateOf(manager.list()) }
    var selected by remember { mutableStateOf(skins.firstOrNull()) }
    var message by remember { mutableStateOf<String?>(null) }
    var model by remember { mutableStateOf("classic") }
    val account = accounts.firstOrNull { it.active }

    LaunchedEffect(skins) { model = selected?.let { manager.detectModel(it.file) } ?: "classic" }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        SectionTitle("Character customisation")

        CpCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // 3D-style preview: the render endpoint returns a front-facing isometric
                // body render for both authenticated profiles and local skin files.
                if (account is com.cplauncher.plus.data.model.Account.Microsoft) {
                    AsyncImage(
                        model = "https://crafatar.com/renders/body/${account.uuid}?overlay",
                        contentDescription = "Body render",
                        modifier = Modifier.size(140.dp),
                    )
                } else {
                    Text("Local profile — import a 64x64 skin below to preview it", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(0.dp))
                Column(Modifier.weight(1f)) {
                    Text(account?.name ?: "No account", style = MaterialTheme.typography.titleLarge)
                    StatusPill(model.uppercase())
                    Text(
                        "Classic = 4px arms · Slim (Alex) = 3px arms. The launcher detects the model from the skin PNG.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("Skin library")
        skins.forEach { skin ->
            CpCard(Modifier.padding(vertical = 4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val bmp = remember(skin.file.path) { android.graphics.BitmapFactory.decodeFile(skin.file.path) }
                    if (bmp != null) Image(bitmap = bmp.asImageBitmap(), contentDescription = null, modifier = Modifier.size(48.dp))
                    Column(Modifier.weight(1f).padding(start = 8.dp)) {
                        Text(skin.name, style = MaterialTheme.typography.titleMedium)
                        Text("${skin.model} · ${skin.bytes / 1024} KB", style = MaterialTheme.typography.bodySmall)
                    }
                    FilterChip(selected = selected == skin, onClick = { selected = skin }, label = { Text("Select") })
                    OutlinedButton(onClick = { manager.delete(skin); skins = manager.list() }) { Text("Delete") }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Row {
            Button(onClick = {
                scope.launch {
                    // SAF picker result is delivered through MainActivity's intent handler.
                    message = "Use the import button in the toolbar to pick a PNG (64x32 or 64x64)."
                }
            }) { Text("Import skin PNG") }
            Spacer(Modifier.height(0.dp))
            OutlinedButton(onClick = {
                scope.launch {
                    val token = manager.activeAccountTokens()
                    if (token == null) {
                        message = "Sign in with a Microsoft account to upload a skin to that account."
                    } else {
                        val file = selected?.file
                        if (file == null) message = "Select a skin first."
                        else {
                            val ok = withContext(Dispatchers.IO) { manager.uploadToAccount(token, file, model) }
                            message = if (ok) "Skin uploaded to your Minecraft account (official endpoint)."
                            else "Upload rejected by Minecraft Services — check the account owns Java Edition."
                        }
                    }
                }
            }) { Text("Apply to account") }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("Cape")
        CpCard {
            val cape = (account as? com.cplauncher.plus.data.model.Account.Microsoft)?.capeUrl
            if (cape != null) {
                AsyncImage(model = cape, contentDescription = "Cape", modifier = Modifier.size(width = 90.dp, height = 60.dp))
                Text("This is the cape attached to your authenticated profile.", style = MaterialTheme.typography.bodySmall)
            } else {
                Text("No cape on this account.", style = MaterialTheme.typography.bodySmall)
            }
            Text(
                "Capes shown here are the ones Mojang has attached to your profile (or OptiFine-style cosmetics if a " +
                    "cosmetic mod is installed). A locally imported cape cannot be rendered on vanilla multiplayer " +
                    "servers — the server decides what your client may draw.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        Text("Profile: ${settings.activeProfileId}", style = MaterialTheme.typography.bodySmall)
    }
}
