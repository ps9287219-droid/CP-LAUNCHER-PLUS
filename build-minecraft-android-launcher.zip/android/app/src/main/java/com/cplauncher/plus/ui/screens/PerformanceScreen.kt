package com.cplauncher.plus.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cplauncher.plus.LauncherViewModel
import com.cplauncher.plus.core.perf.PerformanceProfiles
import com.cplauncher.plus.core.perf.RendererMatrix
import com.cplauncher.plus.ui.common.CpCard
import com.cplauncher.plus.ui.common.SectionTitle
import com.cplauncher.plus.ui.common.SettingRow
import com.cplauncher.plus.ui.common.SliderRow
import com.cplauncher.plus.ui.common.StatusPill
import com.cplauncher.plus.ui.common.SwitchRow

@Composable
fun PerformanceScreen(vm: LauncherViewModel) {
    val settings by vm.settings.collectAsState()
    val caps by vm.capabilities.collectAsState()
    val accent = MaterialTheme.colorScheme.primary

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        SectionTitle("Performance centre")
        CpCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Device", style = MaterialTheme.typography.titleMedium)
                    Text("${caps?.abi} · ${caps?.cores} cores · API ${caps?.apiLevel}", style = MaterialTheme.typography.bodySmall)
                    Text("RAM total ${caps?.totalRamMb ?: 0} MB · free ${caps?.availableRamMb ?: 0} MB", style = MaterialTheme.typography.bodySmall)
                    Text("Java heap available to an app: ${caps?.javaHeapMb ?: 0} MB (large heap ${caps?.largeHeapMb ?: 0} MB)", style = MaterialTheme.typography.bodySmall)
                }
                StatusPill(caps?.thermalStatus ?: "UNKNOWN", accent)
            }
            caps?.warnings?.forEach {
                Text("• $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("Profiles")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PerformanceProfiles.ALL.forEach { p ->
                FilterChip(selected = settings.performanceProfile == p.id, onClick = { vm.applyPerformanceProfile(p.id) }, label = { Text(p.name) })
            }
        }
        Text(PerformanceProfiles.byId(settings.performanceProfile).description, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))

        CpCard {
            SliderRow("FPS limit", settings.fpsLimit.toFloat(), 20f..240f, format = { "${it.toInt()} fps" }) {
                vm.setSettings { s -> s.copy(fpsLimit = it.toInt(), performanceProfile = "custom") }
            }
            SliderRow("Render distance", settings.renderDistance.toFloat(), 2f..32f, format = { "${it.toInt()} chunks" }) {
                vm.setSettings { s -> s.copy(renderDistance = it.toInt(), performanceProfile = "custom") }
            }
            SliderRow("Simulation distance", settings.simulationDistance.toFloat(), 2f..32f, format = { "${it.toInt()} chunks" }) {
                vm.setSettings { s -> s.copy(simulationDistance = it.toInt(), performanceProfile = "custom") }
            }
            SliderRow("Entity distance", settings.entityDistance.toFloat(), 25f..500f, format = { "${it.toInt()}%" }) {
                vm.setSettings { s -> s.copy(entityDistance = it.toInt(), performanceProfile = "custom") }
            }
            SliderRow("UI scale", settings.uiScale.toFloat(), 50f..200f, format = { "${it.toInt()}%" }) {
                vm.setSettings { s -> s.copy(uiScale = it.toInt()) }
            }
            SwitchRow("VSync", "Caps the frame rate to the display refresh", settings.vsync) {
                vm.setSettings { s -> s.copy(vsync = it) }
            }
            SwitchRow("Fullscreen", "Render edge to edge", settings.fullscreen) {
                vm.setSettings { s -> s.copy(fullscreen = it) }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("Memory")
        CpCard {
            val recommended = caps?.recommendedMemoryMb ?: 2048
            SliderRow(
                "Java heap (-Xmx)",
                settings.maxMemoryMb.toFloat(),
                512f..(caps?.largeHeapMb?.toFloat() ?: 4096f),
                format = { "${it.toInt()} MB" },
            ) {
                vm.setSettings { s -> s.copy(maxMemoryMb = it.toInt()) }
            }
            SettingRow(
                "Recommended for this device",
                "Android gives this app about ${caps?.largeHeapMb ?: 0} MB at most. Requesting more than that would kill the JVM instantly, so the launcher clamps it.",
            ) {
                Button(onClick = { vm.setSettings { s -> s.copy(maxMemoryMb = recommended) } }) { Text("${recommended} MB") }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("Renderer")
        CpCard {
            RendererMatrix.ALL.forEach { r ->
                SettingRow(
                    r.name,
                    "${r.api} · " + if (r.shaders) "shader-capable" else "no shader support",
                ) {
                    FilterChip(selected = settings.renderer == r.id, onClick = { vm.setSettings { s -> s.copy(renderer = r.id) } }, label = { Text("Use") })
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("Recommended optimisation mods")
        CpCard {
            val recs = PerformanceProfiles.byId(settings.performanceProfile).recommendedMods
            if (recs.isEmpty()) Text("No extra mods needed for the custom profile.", style = MaterialTheme.typography.bodySmall)
            recs.forEach { slug ->
                SettingRow(slug.replaceFirstChar { it.uppercase() }, "Available on Modrinth for your version — install from the Mods tab") {
                    StatusPill("MODRINTH", accent)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("Frame-time monitoring")
        CpCard {
            Text(
                "The game process writes its own log; the launcher tails it and reports FPS the game itself prints " +
                    "(F3 debug overlay / Quartz-style metrics). Android does not expose another app's render timing, " +
                    "so anything more would be a guess.",
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = { /* open live log */ }) { Text("Open live log") }
        }
    }
}
