package com.cplauncher.plus.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cplauncher.plus.LauncherViewModel
import com.cplauncher.plus.core.discord.DiscordPresence
import com.cplauncher.plus.ui.common.CpCard
import com.cplauncher.plus.ui.common.SectionTitle
import com.cplauncher.plus.ui.common.StatusPill
import com.cplauncher.plus.ui.common.SwitchRow
import com.cplauncher.plus.ui.common.formatDuration

@Composable
fun DiscordScreen(vm: LauncherViewModel) {
    val settings by vm.settings.collectAsState()
    val state by vm.launchState.collectAsState()
    val history by vm.playtime7.collectAsState()
    var result by remember { mutableStateOf<DiscordPresence.ConnectionResult?>(null) }
    val discord = vm.discordPresence()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        SectionTitle("Discord Rich Presence")

        CpCard {
            Text("What actually works on Android", style = MaterialTheme.typography.titleMedium)
            Text(
                "Discord's desktop Rich Presence talks to a local Unix socket inside your desktop session. Android " +
                    "sandboxes every app, the socket does not exist here, and Discord publishes no Android SDK that " +
                    "sets a user's game activity. CP Launcher Plus therefore does three honest things:",
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.padding(4.dp))
            Text("1. Session + playtime tracking, fully local and always accurate.", style = MaterialTheme.typography.bodyMedium)
            Text("2. A documented IPC probe: if a Discord IPC socket is reachable (rooted/bridged setups), the launcher speaks the official op-code protocol.", style = MaterialTheme.typography.bodyMedium)
            Text("3. A deep-link/share hand-off so you can post the session to Discord in one tap.", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.padding(6.dp))
            Row {
                StatusPill(if (discord.isSupportedHere) "IPC SOCKET FOUND" else "IPC UNAVAILABLE ON ANDROID", MaterialTheme.colorScheme.primary)
            }
        }

        Spacer(Modifier.padding(12.dp))
        CpCard {
            SwitchRow("Enable presence attempt", "Nothing is sent anywhere unless a socket handshake succeeds", settings.discordPresence) {
                vm.setSettings { s -> s.copy(discordPresence = it) }
                if (!it) discord.disconnect()
            }
            SwitchRow("Show elapsed session time", "Timestamps only reach Discord when a socket is live", settings.discordShowSessionTime) {
                vm.setSettings { s -> s.copy(discordShowSessionTime = it) }
            }
            SwitchRow("Show Minecraft version", null, settings.discordShowVersion) {
                vm.setSettings { s -> s.copy(discordShowVersion = it) }
            }
            Spacer(Modifier.padding(8.dp))
            Row {
                Button(onClick = {
                    result = discord.connect(
                        DiscordPresence.PresenceState(
                            details = if (settings.discordShowVersion) "Minecraft ${state.label}" else "Playing Minecraft",
                            stateText = "CP Launcher Plus",
                            startTimestampMs = if (settings.discordShowSessionTime) state.startedAt else null,
                        ),
                    )
                }) { Text("Test connection") }
                Button(onClick = { discord.shareSession("1.21", "Fabric", formatDuration(history.sumOf { it.second })) }) {
                    Text("Share session")
                }
            }
            result?.let {
                val text = when (it) {
                    is DiscordPresence.ConnectionResult.Connected -> "Connected to a Discord IPC socket."
                    is DiscordPresence.ConnectionResult.Error -> "Error: ${it.message}"
                    is DiscordPresence.ConnectionResult.Unsupported -> "Unsupported: ${it.reason}"
                }
                Text(text, style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(Modifier.padding(12.dp))
        CpCard {
            Text("Playtime", style = MaterialTheme.typography.titleMedium)
            Text("Total: ${formatDuration(history.sumOf { it.second })}", style = MaterialTheme.typography.bodyMedium)
            history.forEach { (day, seconds) -> Text("$day — ${formatDuration(seconds)}", style = MaterialTheme.typography.bodySmall) }
            Text(
                "Stored locally in games/../playtime-history.json. Never uploaded, cleared by 'Reset' in Diagnostics.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}
