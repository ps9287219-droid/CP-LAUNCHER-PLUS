package com.cplauncher.plus.core.packs

import android.content.Context
import com.cplauncher.plus.core.mods.ModrinthApi
import com.cplauncher.plus.core.perf.RendererMatrix
import com.cplauncher.plus.core.settings.LauncherSettings
import com.cplauncher.plus.core.util.Fs
import com.cplauncher.plus.data.model.PackEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipFile

/**
 * Shader packs + resource packs.
 *
 * Locations (real, used by the game):
 *   games/<profile>/shaderpacks/<name>.zip
 *   games/<profile>/resourcepacks/<name>.zip
 *
 * A shader pack is only reported as WORKING when the selected renderer supports
 * desktop GL features (see [RendererMatrix]); otherwise the UI says so explicitly.
 */
class PackageManager(private val context: Context, private val profileDir: String = "default") {

    private val api = ModrinthApi()

    fun shaderDir(): File = Fs.dir(context, Fs.SHADERS, profileDir)
    fun resourceDir(): File = Fs.dir(context, Fs.RESOURCE_PACKS, profileDir)

    fun list(kind: PackEntry.Kind): List<PackEntry> {
        val dir = if (kind == PackEntry.Kind.SHADER) shaderDir() else resourceDir()
        return dir.listFiles()?.filter { it.extension == "zip" }?.map {
            PackEntry(
                name = it.nameWithoutExtension,
                fileName = it.name,
                kind = kind,
                sizeBytes = it.length(),
                compatible = true,
                requiresRenderer = if (kind == PackEntry.Kind.SHADER) "zink_vulkan" else null,
                description = describe(it),
            )
        } ?: emptyList()
    }

    private fun describe(zip: File): String = runCatching {
        ZipFile(zip).use { zf ->
            val shadersProps = zf.getEntry("shaders/shaders.properties")
            val packMcmeta = zf.getEntry("pack.mcmeta")
            when {
                shadersProps != null -> "OptiFine/Iris-format shader pack"
                packMcmeta != null -> "Vanilla resource pack"
                else -> "Archive (unrecognised layout)"
            }
        }
    }.getOrDefault("Archive")

    fun isShaderPack(zip: File): Boolean = runCatching {
        ZipFile(zip).use { it.getEntry("shaders") != null || it.getEntry("shaders.properties") != null }
    }.getOrDefault(false)

    fun isResourcePack(zip: File): Boolean = runCatching {
        ZipFile(zip).use { it.getEntry("pack.mcmeta") != null }
    }.getOrDefault(false)

    /** True only when the whole chain supports shaders. */
    fun shaderSupportState(settings: LauncherSettings, modIds: Set<String>): ShaderSupport {
        val renderer = RendererMatrix.byId(settings.renderer)
        val hasIris = modIds.any { it.startsWith("iris") || it.startsWith("oculus") }
        val hasOptifine = modIds.any { it.startsWith("optifine") }
        return when {
            renderer.shaders && (hasIris || hasOptifine) -> ShaderSupport.FULL
            renderer.shaders && !hasIris -> ShaderSupport.NEEDS_RENDERER_MOD
            !renderer.shaders && (hasIris || hasOptifine) -> ShaderSupport.NEEDS_RENDERER
            else -> ShaderSupport.UNSUPPORTED
        }
    }

    enum class ShaderSupport(val message: String) {
        FULL("Shaders will render: renderer supports desktop GL features and Iris/OptiFine is installed."),
        NEEDS_RENDERER_MOD("This renderer can run shaders, but install Iris (Fabric) or Oculus (Forge) first."),
        NEEDS_RENDERER("Your renderer cannot run shaders. Switch to Zink (Vulkan) in Settings → Renderer."),
        UNSUPPORTED("Shaders are unavailable with the current renderer and no shader mod is installed."),
    }

    suspend fun installFromModrinth(slug: String, kind: PackEntry.Kind, gameVersion: String, onProgress: (Long, Long) -> Unit): File =
        withContext(Dispatchers.IO) {
            val type = if (kind == PackEntry.Kind.SHADER) "shader" else "resourcepack"
            val versions = api.versions(slug, if (type == "resourcepack") gameVersion else null, emptyList())
            val ref = versions.firstOrNull()
                ?: api.search(slug, emptyList(), gameVersion, type, 1).firstOrNull()?.let { api.versions(it.slug, null, emptyList()).firstOrNull() }
                ?: throw IllegalStateException("No downloadable file found for $slug")
            val targetDir = if (kind == PackEntry.Kind.SHADER) shaderDir() else resourceDir()
            api.download(ref, targetDir, onProgress)
        }

    fun importZip(file: File, kind: PackEntry.Kind): File {
        val dir = if (kind == PackEntry.Kind.SHADER) shaderDir() else resourceDir()
        val target = File(dir, file.name)
        file.copyTo(target, overwrite = true)
        return target
    }

    fun delete(entry: PackEntry) {
        val dir = if (entry.kind == PackEntry.Kind.SHADER) shaderDir() else resourceDir()
        File(dir, entry.fileName).delete()
    }

    /** Writes the selected packs into options.txt so Minecraft actually uses them. */
    fun applyToOptions(activeShaders: String?, activeResourcePacks: List<String>, settings: LauncherSettings): String {
        val options = File(Fs.gameRoot(context, profileDir), "options.txt")
        val current = if (options.exists()) options.readLines() else emptyList()
        val others = current.filterNot { it.startsWith("shaderPack:") || it.startsWith("resourcePacks:") }
        val newLines = others +
            "shaderPack:${activeShaders ?: ""}" +
            "resourcePacks:[${activeResourcePacks.joinToString(",") { "\"${it}\"" }}]"
        options.writeText(newLines.joinToString("\n"))
        return options.absolutePath
    }

    fun graphicsPresetDescription(id: String): String = when (id) {
        "low" -> "Fast graphics, 4 chunks, minimal particles, vsync off"
        "balanced" -> "Fancy graphics, 8 chunks, decreased particles"
        "high" -> "Fancy graphics, 12 chunks, all particles, no vsync cap"
        else -> "Custom values from the Performance sliders"
    }
}
