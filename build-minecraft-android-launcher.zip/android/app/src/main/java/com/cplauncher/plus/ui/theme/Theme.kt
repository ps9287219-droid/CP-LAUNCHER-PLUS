package com.cplauncher.plus.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object CpPalette {
    val Background = Color(0xFF0A0E0B)
    val Surface = Color(0xFF111713)
    val SurfaceHigh = Color(0xFF182019)
    val Outline = Color(0xFF243026)
    val TextPrimary = Color(0xFFE8F3EC)
    val TextSecondary = Color(0xFF9FB3A6)

    val Emerald = Color(0xFF3FD46A)
    val Lime = Color(0xFFB7F34A)
    val Teal = Color(0xFF3FE0C8)
    val Violet = Color(0xFF9C7BFF)
    val Amber = Color(0xFFFFB340)

    fun accent(name: String): Color = when (name) {
        "lime" -> Lime
        "teal" -> Teal
        "violet" -> Violet
        "amber" -> Amber
        else -> Emerald
    }
}

val CpTypography = Typography(
    displayLarge = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 44.sp, fontWeight = FontWeight.Black),
    headlineMedium = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 26.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontFamily = FontFamily.Default, fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontFamily = FontFamily.Default, fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyMedium = TextStyle(fontFamily = FontFamily.Default, fontSize = 14.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.Default, fontSize = 12.sp, color = CpPalette.TextSecondary),
    labelLarge = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.Bold),
)

@Composable
fun CPLauncherTheme(
    themeMode: String = "dark",
    accent: String = "emerald",
    content: @Composable () -> Unit,
) {
    val dark = when (themeMode) {
        "light" -> false
        "system" -> isSystemInDarkTheme()
        else -> true
    }
    val a = CpPalette.accent(accent)

    val darkScheme = darkColorScheme(
        primary = a,
        onPrimary = Color(0xFF04170B),
        secondary = CpPalette.TextSecondary,
        background = CpPalette.Background,
        onBackground = CpPalette.TextPrimary,
        surface = CpPalette.Surface,
        onSurface = CpPalette.TextPrimary,
        surfaceVariant = CpPalette.SurfaceHigh,
        onSurfaceVariant = CpPalette.TextSecondary,
        outline = CpPalette.Outline,
        error = Color(0xFFFF5A5A),
    )
    val lightScheme = lightColorScheme(
        primary = a,
        background = Color(0xFFF5F8F5),
        surface = Color(0xFFFFFFFF),
        onBackground = Color(0xFF0E1511),
        onSurface = Color(0xFF0E1511),
    )

    MaterialTheme(
        colorScheme = if (dark) darkScheme else lightScheme,
        typography = CpTypography,
        content = content,
    )
}
