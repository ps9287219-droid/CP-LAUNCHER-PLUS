package com.cplauncher.plus.core.launch

import android.content.Context
import android.os.Build
import com.cplauncher.plus.core.accounts.AccountStore
import com.cplauncher.plus.core.runtime.JreManager
import com.cplauncher.plus.core.settings.LauncherSettings
import com.cplauncher.plus.core.versions.NativeSubstitution
import com.cplauncher.plus.core.versions.ResolvedVersion
import com.cplauncher.plus.data.model.Account
import com.cplauncher.plus.data.model.Loader
import java.io.File

/**
 * Builds the exact JVM + game command line for a version, then hands it to the
 * Java bridge. Nothing here fakes success: [LaunchHandle] reports what really happened.
 */
class LaunchConfigurator(
    private val context: Context,
    private val settings: LauncherSettings,
    private val jre: JreManager,
) {

    data class LaunchPlan(
        val jvmArgs: List<String>,
        val mainClass: String,
        val gameArgs: List<String>,
        val classpath: List<File>,
        val nativesDir: File,
        val gameDir: File,
        val env: Map<String, String>,
        val jvmHome: File,
        val javaMajor: Int,
    )

    fun buildPlan(
        resolved: ResolvedVersion,
        loader: Loader,
        loaderVersion: String?,
        account: Account,
        offlineUuid: String?,
        assetsIndexId: String,
    ): LaunchPlan {
        val profileDir = "default"
        val root = com.cplauncher.plus.core.util.Fs.gameRoot(context, profileDir)
        val versionDir = File(root, "versions/${resolved.id}")
        val clientJar = File(versionDir, "${resolved.id}.jar")
        val nativesDir = File(versionDir, "natives")
        val assetsDir = File(root, "assets")

        val spec = jre.runtimeFor(resolved.javaMajor)
        val jvmHome = jre.jvmHome(spec)

        // ---- classpath ------------------------------------------------------
        val cp = mutableListOf<File>()
        resolved.libraries.filter { it.appliesToAndroid }.forEach { cp.add(File(root, "libraries/${it.path}")) }
        // Loader (Fabric/Forge/NeoForge/Quilt) jars live beside the vanilla ones
        loaderLibraries(loader, loaderVersion, root).forEach { if (it.exists()) cp.add(it) }
        // Android LWJGL / GL shims from the runtime pack must win over desktop jars
        File(root, "libraries/android").listFiles()?.forEach { if (it.extension == "jar") cp.add(it) }
        cp.add(clientJar)

        val memory = safeMemory()

        // ---- JVM args -------------------------------------------------------
        val jvm = mutableListOf<String>()
        jvm += "-Xms${settings.minMemoryMb}M"
        jvm += "-Xmx${memory}M"
        jvm += "-Djava.library.path=${nativesDir.absolutePath}"
        jvm += "-Dorg.lwjgl.opengl.libname=libgl4es_114.so"
        jvm += "-Dorg.lwjgl.glfw.libname=liblwjgl_glfw.so"
        jvm += "-Dorg.lwjgl.openal.libname=libopenal.so"
        jvm += "-Dorg.lwjgl.opengl.libname.gl=/system/lib64/libGL.so"
        jvm += "-Dglfwstub.windowWidth=${settings.fullscreen.takeIf { true }?.let { 1920 } ?: 1280}"
        jvm += "-Dglfwstub.windowHeight=1080"
        jvm += "-Dglfwstub.initTime=1500"
        jvm += "-Dversion.entity.culling=false"
        jvm += settings.jvmArgs.split(' ').filter { it.isNotBlank() }
        if (resolved.loggingArg != null) {
            jvm += resolved.loggingArg.replace(
                "\${path}",
                File(versionDir, "log-config.xml").absolutePath,
            )
        }

        // ---- game args ------------------------------------------------------
        val username = account.name
        val uuid = when (account) {
            is Account.Microsoft -> account.uuid
            is Account.Offline -> offlineUuid ?: account.derivedUuid
        }
        val accessToken = if (account is Account.Microsoft) (account as Account.Microsoft).let { it.uuid; accessTokenFor(it.uuid) } else "0"

        val substitutions = mapOf(
            "auth_player_name" to username,
            "version_name" to resolved.id,
            "game_directory" to root.absolutePath,
            "assets_root" to assetsDir.absolutePath,
            "game_assets" to File(assetsDir, "virtual/legacy").absolutePath,
            "assets_index_name" to assetsIndexId,
            "auth_uuid" to uuid,
            "auth_access_token" to accessToken,
            "auth_xuid" to "0",
            "clientid" to "cp-launcher-plus",
            "auth_session" to accessToken,
            "user_type" to if (account is Account.Microsoft) "msa" else "legacy",
            "version_type" to "CP-Launcher-Plus",
            "resolution_width" to "1920",
            "resolution_height" to "1080",
            "launcher_name" to "CP-Launcher-Plus",
            "launcher_version" to "1.0.0",
            "natives_directory" to nativesDir.absolutePath,
            "launcher_profiles" to File(root, "launcher_profiles.json").absolutePath,
            "classpath" to cp.joinToString(":") { it.absolutePath },
            "library_directory" to File(root, "libraries").absolutePath,
            "classpath_separator" to ":",
        )

        val game = mutableListOf<String>()
        if (resolved.gameArgs.isNotEmpty()) {
            resolved.gameArgs.forEach { raw ->
                val stripped = raw.removePrefix("${'$'}{").removeSuffix("}")
                when (stripped) {
                    "width", "height" -> Unit // handled by glfwstub; keep vanilla defaults
                    else -> game += substitute(raw, substitutions)
                }
            }
        }
        resolved.minecraftArguments?.let { legacy ->
            game += legacy.split(' ').map { substitute(it, substitutions) }
        }
        game += "--width 1920 --height 1080".split(' ')
        game += listOf("--fullscreen", settings.fullscreen.toString())
        game += listOf("--fpsLimit", settings.fpsLimit.toString())

        // Performance / user settings translated into vanilla options
        val options = optionsFile(root)
        options.writeText(
            """
            |version:4133
            |renderDistance:${settings.renderDistance}
            |simulationDistance:${settings.simulationDistance}
            |graphicsMode:${graphicsMode(settings.graphicsPreset)}
            |maxFps:${settings.fpsLimit}
            |enableVsync:${settings.vsync}
            |particles:${settings.particles}
            |entityDistanceScaling:${(settings.entityDistance / 100.0).coerceIn(0.25, 5.0)}
            |guiScale:0
            |fullscreen:${settings.fullscreen}
            |overrideWidth:0
            |overrideHeight:0
            |soundCategory_master:0.8
            """.trimMargin(),
        )

        val env = mapOf(
            "HOME" to root.absolutePath,
            "JAVA_HOME" to jvmHome.absolutePath,
            "LD_LIBRARY_PATH" to listOf(nativesDir.absolutePath, File(jvmHome, "lib").absolutePath, File(jvmHome, "lib/server").absolutePath).joinToString(":"),
            "PATH" to "${File(jvmHome, "bin").absolutePath}:/system/bin",
            "LIBGL_ES" to "2",
            "LIBGL_GL" to "21",
            "LIBGL_NORMALIZE" to "1",
            "MESA_LOADER_DRIVER_OVERRIDE" to if (settings.renderer == "zink_vulkan") "zink" else "",
            "DEVICE_ARCH" to (Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"),
        )

        return LaunchPlan(
            jvmArgs = jvm,
            mainClass = resolved.mainClass,
            gameArgs = game.filter { it.isNotBlank() },
            classpath = cp,
            nativesDir = nativesDir,
            gameDir = root,
            env = env,
            jvmHome = jvmHome,
            javaMajor = resolved.javaMajor,
        )
    }

    private fun loaderLibraries(loader: Loader, loaderVersion: String?, root: File): List<File> {
        if (loader == Loader.VANILLA || loaderVersion == null) return emptyList()
        val dir = File(root, "libraries/${loader.name.lowercase()}/$loaderVersion")
        return dir.listFiles()?.toList() ?: emptyList()
    }

    private fun accessTokenFor(uuid: String): String {
        val store = AccountStore(context)
        val id = store.activeAccountId() ?: return "0"
        return store.tokensFor(id)?.accessToken ?: "0"
    }

    /**
     * Android hard-caps the Java heap per app. Asking for more than the device can
     * deliver kills the JVM instantly, so we clamp instead of pretending.
     */
    fun safeMemory(): Int {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val memClass = activityManager.memoryClass               // Java heap available to a normal app (MB)
        val largeHeap = (activityManager.largeMemoryClass * 0.72).toInt()  // leave room for our own UI heap
        val requested = settings.maxMemoryMb
        val cap = maxOf(512, largeHeap)
        val floor = minOf(requested, memClass * 4)
        return requested.coerceIn(minOf(512, floor), cap)
    }

    private fun graphicsMode(preset: String): Int = when (preset) {
        "low" -> 0
        "high" -> 2
        else -> 1
    }

    private fun substitute(arg: String, map: Map<String, String>): String {
        var out = arg
        map.forEach { (k, v) -> out = out.replace("\${$k}", v) }
        return out
    }

    private fun optionsFile(root: File): File {
        val f = File(root, "options.txt")
        f.parentFile?.mkdirs()
        return f
    }

    /** Natives that must exist for the selected renderer, used for pre-flight checks. */
    fun preFlight(plan: LaunchPlan): List<String> {
        val problems = mutableListOf<String>()
        if (!plan.jvmHome.resolve("lib/libjvm.so").exists() && !plan.jvmHome.resolve("bin/java").exists()) {
            problems += "Java runtime not installed at ${plan.jvmHome.path}"
        }
        NativeSubstitution.androidNatives.forEach { name ->
            if (!File(plan.nativesDir, name).exists()) problems += "Missing native: $name"
        }
        if (plan.classpath.none { it.name.endsWith(".jar") }) problems += "Classpath is empty"
        return problems
    }
}
