package com.cplauncher.plus.core.skins

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.cplauncher.plus.core.accounts.AccountStore
import com.cplauncher.plus.core.util.Fs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Skin + cape handling.
 *
 * What is legitimately possible without Mojang's private endpoints:
 *  • READ the authenticated profile's skin/cape (api.minecraftservices.com/minecraft/profile).
 *  • UPLOAD a new skin for an authenticated account through the official endpoint
 *    api.minecraftservices.com/minecraft/profile/skins (multipart, model=classic|slim).
 *    This changes the skin on the account itself, so it shows everywhere.
 *  • For OFFLINE/local profiles: store the PNG next to the game dir so a skin mod
 *    (CustomSkinLoader / Fabric Tailor) can load it — the launcher must say this
 *    clearly, it cannot change a server's view of an offline player.
 */
class SkinManager(private val context: Context) {

    private val skinsDir: File get() = Fs.dir(context, Fs.SKINS)

    data class Skin(val name: String, val file: File, val model: String, val bytes: Long)

    fun list(): List<Skin> = skinsDir.listFiles()?.filter { it.extension == "png" }?.map {
        Skin(it.nameWithoutExtension, it, detectModel(it), it.length())
    } ?: emptyList()

    /** 64x64 skins with 54px-wide arms region are "slim" (Alex); classic is 64px. */
    fun detectModel(file: File): String = runCatching {
        val bmp = BitmapFactory.decodeFile(file.absolutePath) ?: return "classic"
        if (bmp.width != 64) return "classic"
        // sample the arm second-layer region
        val px = bmp.getPixel(50, 16)
        val alpha = (px ushr 24) and 0xFF
        if (alpha == 0) "slim" else "classic"
    }.getOrDefault("classic")

    fun importPng(source: File, name: String): File {
        val target = File(skinsDir, "$name.png")
        source.copyTo(target, overwrite = true)
        return target
    }

    fun importPngBytes(bytes: ByteArray, name: String): File {
        val target = File(skinsDir, "$name.png")
        target.writeBytes(bytes)
        return target
    }

    suspend fun downloadFromUrl(url: String, name: String): File = withContext(Dispatchers.IO) {
        val target = File(skinsDir, "$name.png")
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.inputStream.use { input -> target.outputStream().use { input.copyTo(it) } }
        target
    }

    /**
     * Official skin upload for an authenticated account. Requires a Minecraft Services
     * access token obtained via the Microsoft chain — never a password.
     */
    suspend fun uploadToAccount(mcAccessToken: String, png: File, model: String): Boolean =
        withContext(Dispatchers.IO) {
            val boundary = "----CPLauncherPlus${System.currentTimeMillis()}"
            val url = URL("https://api.minecraftservices.com/minecraft/profile/skins")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer $mcAccessToken")
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")

            conn.outputStream.use { out ->
                fun field(name: String, value: String) {
                    out.write("--$boundary\r\n".toByteArray())
                    out.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray())
                    out.write("$value\r\n".toByteArray())
                }
                fun fileField(name: String, fileName: String, mime: String, data: ByteArray) {
                    out.write("--$boundary\r\n".toByteArray())
                    out.write("Content-Disposition: form-data; name=\"$name\"; filename=\"$fileName\"\r\n".toByteArray())
                    out.write("Content-Type: $mime\r\n\r\n".toByteArray())
                    out.write(data)
                    out.write("\r\n".toByteArray())
                }
                field("model", if (model == "slim") "slim" else "classic")
                fileField("file", png.name, "image/png", png.readBytes())
                out.write("--$boundary--\r\n".toByteArray())
            }

            val code = conn.responseCode
            conn.disconnect()
            code in 200..299
        }

    /** Cached profile fetch used by the customization screen. */
    suspend fun fetchProfileSkinUrl(mcAccessToken: String): Pair<String?, String?> = withContext(Dispatchers.IO) {
        val conn = URL("https://api.minecraftservices.com/minecraft/profile").openConnection() as HttpURLConnection
        conn.setRequestProperty("Authorization", "Bearer $mcAccessToken")
        val body = conn.inputStream.bufferedReader().readText()
        val json = JSONObject(body)
        var skin: String? = null
        var cape: String? = null
        json.optJSONArray("skins")?.let { arr ->
            (0 until arr.length()).forEach { i ->
                val s = arr.getJSONObject(i)
                if (s.optString("state") == "ACTIVE") skin = s.optString("url")
            }
        }
        json.optJSONArray("capes")?.let { arr -> if (arr.length() > 0) cape = arr.getJSONObject(0).optString("url") }
        skin to cape
    }

    fun localSkinForOffline(name: String): File? = File(skinsDir, "$name.png").takeIf { it.exists() }

    fun delete(skin: Skin) = skin.file.delete()

    fun activeAccountTokens(): String? {
        val store = AccountStore(context)
        val id = store.activeAccountId() ?: return null
        return store.tokensFor(id)?.accessToken
    }

    /** Renderer used by the 3D preview: returns the 8x8 head texture crops. */
    fun headTexture(file: File): Bitmap? = BitmapFactory.decodeFile(file.absolutePath)
}
