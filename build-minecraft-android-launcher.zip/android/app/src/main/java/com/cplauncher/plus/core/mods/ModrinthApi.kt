package com.cplauncher.plus.core.mods

import com.cplauncher.plus.core.util.Net
import org.json.JSONArray
import org.json.JSONObject

/**
 * Modrinth v2 public API client.
 * Terms: https://docs.modrinth.com/ — free, requires a descriptive User-Agent,
 * rate limit ~300 req/min. No API key is required for search/download.
 * Only content published under permissive licences on Modrinth is used.
 */
class ModrinthApi(private val baseUrl: String = "https://api.modrinth.com/v2") {

    private val ua = "CP-Launcher-Plus/1.0.0 (android; github.com/ps9287219-droid/CP-LAUNCHER-PLUS)"

    data class SearchResult(
        val slug: String,
        val title: String,
        val description: String,
        val categories: List<String>,
        val loaders: List<String>,
        val versions: List<String>,
        val downloads: Long,
        val iconUrl: String?,
        val projectType: String,
    )

    data class FileRef(
        val url: String,
        val filename: String,
        val sha1: String,
        val size: Long,
        val versionId: String,
        val versionNumber: String,
        val gameVersions: List<String>,
        val loaders: List<String>,
        val required: List<Dependency>,
    ) {
        data class Dependency(val projectId: String, val required: Boolean)
    }

    suspend fun search(query: String, loaders: List<String>, gameVersion: String, facetType: String = "mod", limit: Int = 30, offset: Int = 0): List<SearchResult> {
        val facets = JSONArray()
            .put(JSONArray().put("project_type:$facetType"))
        if (gameVersion.isNotBlank()) facets.put(JSONArray().put("versions:$gameVersion"))
        loaders.forEach { facets.put(JSONArray().put("categories:$it")) }
        val url = "$baseUrl/search?limit=$limit&offset=$offset" +
            "&index=downloads&query=" + android.net.Uri.encode(query) +
            "&facets=" + android.net.Uri.encode(facets.toString())
        val raw = Net.json(url)
        val hits = raw.optJSONArray("hits") ?: return emptyList()
        return (0 until hits.length()).map { i ->
            val h = hits.getJSONObject(i)
            SearchResult(
                slug = h.getString("slug"),
                title = h.getString("title"),
                description = h.optString("description"),
                categories = stringArr(h.optJSONArray("categories")),
                loaders = stringArr(h.optJSONArray("display_categories")),
                versions = stringArr(h.optJSONArray("versions")),
                downloads = h.optLong("downloads"),
                iconUrl = h.optString("icon_url").ifEmpty { null },
                projectType = h.optString("project_type", "mod"),
            )
        }
    }

    suspend fun versions(slug: String, gameVersion: String?, loaders: List<String>): List<FileRef> {
        val qs = buildList {
            gameVersion?.let { add("game_versions=%5B%22$it%22%5D") }
            if (loaders.isNotEmpty()) {
                add("loaders=" + java.net.URLEncoder.encode(loaders.joinToString(",", "[", "]", "\"", "\"", "\"", "\"") { it }, "UTF-8"))
            }
        }
        val url = "$baseUrl/project/$slug/version" + if (qs.isEmpty()) "" else "?" + qs.joinToString("&")
        val arr = JSONArray(Net.text(url))
        return (0 until arr.length()).mapNotNull { i ->
            val v = arr.optJSONObject(i) ?: return@mapNotNull null
            val primary = v.optJSONArray("files")?.let { files ->
                (0 until files.length()).mapNotNull { files.optJSONObject(it) }.firstOrNull { it.optBoolean("primary") }
                    ?: (0 until files.length()).mapNotNull { files.optJSONObject(it) }.firstOrNull()
            } ?: return@mapNotNull null
            FileRef(
                url = primary.getString("url"),
                filename = primary.getString("filename"),
                sha1 = primary.optString("sha1"),
                size = primary.optLong("size"),
                versionId = v.getString("id"),
                versionNumber = v.optString("version_number"),
                gameVersions = stringArr(v.optJSONArray("game_versions")),
                loaders = stringArr(v.optJSONArray("loaders")),
                required = v.optJSONArray("dependencies")?.let { deps ->
                    (0 until deps.length()).mapNotNull { j ->
                        val d = deps.optJSONObject(j) ?: return@mapNotNull null
                        FileRef.Dependency(d.optString("project_id"), d.optString("dependency_type") == "required")
                    }
                } ?: emptyList(),
            )
        }
    }

    suspend fun project(slug: String): JSONObject = Net.json("$baseUrl/project/$slug")

    suspend fun download(ref: FileRef, targetDir: java.io.File, onProgress: (Long, Long) -> Unit): java.io.File {
        val f = java.io.File(targetDir, ref.filename)
        Net.downloadToFile(ref.url, f) { r, t -> onProgress(r, t) }
        return f
    }

    private fun stringArr(arr: JSONArray?): List<String> {
        arr ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optString(it).ifEmpty { null } }
    }
}
