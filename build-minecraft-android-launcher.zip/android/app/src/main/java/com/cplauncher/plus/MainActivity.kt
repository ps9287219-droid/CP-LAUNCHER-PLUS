package com.cplauncher.plus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.cplauncher.plus.ui.screens.AccountsScreen
import com.cplauncher.plus.ui.screens.CustomizeScreen
import com.cplauncher.plus.ui.screens.DiagnosticsScreen
import com.cplauncher.plus.ui.screens.DiscordScreen
import com.cplauncher.plus.ui.screens.HomeScreen
import com.cplauncher.plus.ui.screens.LibraryScreen
import com.cplauncher.plus.ui.screens.ModsScreen
import com.cplauncher.plus.ui.screens.PacksScreen
import com.cplauncher.plus.ui.screens.PerformanceScreen
import com.cplauncher.plus.ui.screens.RuntimesScreen
import com.cplauncher.plus.ui.screens.SettingsScreen
import com.cplauncher.plus.ui.theme.CPLauncherTheme

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: LauncherViewModel = viewModel(factory = LauncherViewModelFactory(application as CPLauncherApp))
            val settings by vm.settings.collectAsState()
            CPLauncherTheme(themeMode = settings.themeMode, accent = settings.accent) {
                CpApp(vm)
            }
        }
    }
}

data class CpDestination(val route: String, val label: String)

val PRIMARY = listOf(
    CpDestination("home", "Play"),
    CpDestination("library", "Library"),
    CpDestination("mods", "Mods"),
    CpDestination("packs", "Packs"),
    CpDestination("performance", "Perf"),
    CpDestination("customize", "Skin"),
)

val SECONDARY = listOf(
    CpDestination("accounts", "Accounts"),
    CpDestination("runtimes", "Runtimes"),
    CpDestination("discord", "Discord"),
    CpDestination("diagnostics", "Logs"),
    CpDestination("settings", "Settings"),
)

@Composable
fun CpApp(vm: LauncherViewModel) {
    val nav = rememberNavController()
    val width = androidx.compose.material3.windowsizeclass.calculateWindowSizeClass(androidx.compose.ui.platform.LocalContext.current as android.app.Activity)
    val expanded = width.widthSizeClass != WindowWidthSizeClass.Compact
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route ?: "home"

    Row(Modifier.fillMaxSize()) {
        if (expanded) {
            NavigationRail(containerColor = MaterialTheme.colorScheme.surface) {
                (PRIMARY + SECONDARY).forEach { dest ->
                    NavigationRailItem(
                        selected = current == dest.route,
                        onClick = { nav.navigate(dest.route) },
                        icon = {},
                        label = { Text(dest.label) },
                    )
                }
            }
        }
        Scaffold(
            bottomBar = {
                if (!expanded) {
                    NavigationBar {
                        PRIMARY.forEach { dest ->
                            NavigationBarItem(
                                selected = current == dest.route,
                                onClick = { nav.navigate(dest.route) },
                                icon = {},
                                label = { Text(dest.label, style = MaterialTheme.typography.bodySmall) },
                            )
                        }
                        NavigationBarItem(
                            selected = current in SECONDARY.map { it.route },
                            onClick = { nav.navigate("settings") },
                            icon = {},
                            label = { Text("More", style = MaterialTheme.typography.bodySmall) },
                        )
                    }
                }
            },
        ) { padding ->
            Column(Modifier.padding(padding)) {
                NavHost(navController = nav, startDestination = "home", modifier = Modifier.fillMaxWidth()) {
                    composable("home") { HomeScreen(vm, nav) }
                    composable("library") { LibraryScreen(vm) }
                    composable("mods") { ModsScreen(vm) }
                    composable("packs") { PacksScreen(vm) }
                    composable("performance") { PerformanceScreen(vm) }
                    composable("customize") { CustomizeScreen(vm) }
                    composable("accounts") { AccountsScreen(vm) }
                    composable("runtimes") { RuntimesScreen(vm) }
                    composable("discord") { DiscordScreen(vm) }
                    composable("diagnostics") { DiagnosticsScreen(vm) }
                    composable("settings") { SettingsScreen(vm, nav) }
                }
            }
        }
    }
}
