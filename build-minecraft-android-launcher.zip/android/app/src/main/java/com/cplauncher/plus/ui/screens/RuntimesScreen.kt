package com.cplauncher.plus.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cplauncher.plus.LauncherViewModel
import com.cplauncher.plus.ui.common.CpCard
import com.cplauncher.plus.ui.common.ProgressBar
import com.cplauncher.plus.ui.common.SectionTitle
import com.cplauncher.plus.ui.common.StatusPill

@Composable
fun RuntimesScreen(vm: LauncherViewModel) {
    var progressLabel by remember { mutableStateOf<String?>(null) }
    var installed by remember { mutableStateOf(vm.installedRuntimes()) }
    val caps by vm.capabilities.collectAsState()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        SectionTitle("Java runtimes")
        CpCard {
            Text(
                "Minecraft Java needs a real JVM. CP Launcher Plus downloads OpenJDK builds compiled for Android " +
                    "(arm64-v8a / x86_64, GPLv2 + Classpath exception). Your device reports: ${caps?.abi}.",
                style = MaterialTheme.typography.bodySmall,
            )
            if (caps?.abi?.let { it != "arm64-v8a" && it != "x86_64" } == true) {
                Text("This ABI cannot run modern Minecraft Java editions.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(Modifier.height(12.dp))

        vm.runtimes().forEach { spec ->
            CpCard(Modifier.padding(vertical = 4.dp)) {
                Column {
                    Row(Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text(spec.id, style = MaterialTheme.typography.titleMedium)
                            Text(spec.description, style = MaterialTheme.typography.bodySmall)
                            Text("Java ${spec.javaMajor} · ${spec.sizeBytes / (1024 * 1024)} MB download", style = MaterialTheme.typography.bodySmall)
                        }
                        if (spec.id in installed) StatusPill("INSTALLED")
                    }
                    Spacer(Modifier.height(6.dp))
                    Row {
                        Button(onClick = {
                            vm.installRuntime(spec.id) { label, c, t ->
                                progressLabel = label
                            }
                            installed = vm.installedRuntimes()
                        }) { Text(if (spec.id in installed) "Re-download" else "Download & install") }
                        Spacer(Modifier.height(0.dp))
                        OutlinedButton(onClick = {
                            com.cplauncher.plus.core.runtime.JreManager(com.cplauncher.plus.CPLauncherApp.instance).deleteRuntime(spec.id)
                            installed = vm.installedRuntimes()
                        }) { Text("Delete") }
                    }
                }
            }
        }

        progressLabel?.let {
            Spacer(Modifier.height(12.dp))
            CpCard { ProgressBar(it, 0, 0, true) }
        }
    }
}
