package com.cplauncher.plus

import android.app.Application
import android.content.Context
import com.cplauncher.plus.core.accounts.AccountStore
import com.cplauncher.plus.core.diag.CrashReporter
import com.cplauncher.plus.core.launch.GameLauncher
import com.cplauncher.plus.core.runtime.JreManager
import com.cplauncher.plus.core.settings.SettingsRepository

class CPLauncherApp : Application() {

    lateinit var settingsRepo: SettingsRepository
        private set
    lateinit var accountStore: AccountStore
        private set
    lateinit var jreManager: JreManager
        private set
    lateinit var launcher: GameLauncher
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        CrashReporter.installDefaultHandler(this)
        settingsRepo = SettingsRepository(this)
        accountStore = AccountStore(this)
        jreManager = JreManager(this)
        // GameLauncher needs the current settings; the ViewModel re-creates it on change.
        launcher = GameLauncher(this, com.cplauncher.plus.core.settings.LauncherSettings())
    }

    companion object {
        lateinit var instance: CPLauncherApp
            private set

        fun settings(context: Context): SettingsRepository = (context.applicationContext as CPLauncherApp).settingsRepo
    }
}
