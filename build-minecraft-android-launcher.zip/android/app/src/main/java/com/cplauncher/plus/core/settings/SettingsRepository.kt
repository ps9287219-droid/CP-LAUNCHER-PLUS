package com.cplauncher.plus.core.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "cp_launcher_settings")

data class LauncherSettings(
    // Appearance
    val themeMode: String = "dark",           // dark | light | amoled | system
    val accent: String = "emerald",           // emerald | lime | teal | violet | amber
    val animations: Boolean = true,
    val language: String = "system",
    // Launch
    val activeProfileId: String = "vanilla-latest",
    val runtimeId: String = "jre17-arm64",
    val renderer: String = "gl4es_114",       // gl4es_114 | angle_vulkan | zink_vulkan | ltw
    val jvmArgs: String = "-XX:+UseG1GC -XX:+UnlockExperimentalVMOptions -XX:G1NewSizePercent=20 -XX:G1ReservePercent=20 -XX:MaxGCPauseMillis=50 -XX:G1HeapRegionSize=32M",
    val maxMemoryMb: Int = 2048,
    val minMemoryMb: Int = 512,
    val useLinkedOfflineAccount: Boolean = false,
    // Performance
    val fpsLimit: Int = 60,
    val renderDistance: Int = 8,
    val simulationDistance: Int = 6,
    val graphicsPreset: String = "balanced",  // low | balanced | high | custom
    val vsync: Boolean = true,
    val fullscreen: Boolean = true,
    val uiScale: Int = 100,
    val particles: String = "all",
    val entityDistance: Int = 100,
    val performanceProfile: String = "balanced",
    // Downloads
    val autoUpdateVersions: Boolean = true,
    val concurrentDownloads: Int = 4,
    val retryFailedDownloads: Boolean = true,
    // Integrations
    val discordPresence: Boolean = false,
    val discordShowSessionTime: Boolean = true,
    val discordShowVersion: Boolean = true,
    val telemetry: Boolean = false,           // off by default; only local diagnostics when false
    val notifications: Boolean = true,
    val showAdvancedLogs: Boolean = false,
)

class SettingsRepository(private val context: Context) {

    private object K {
        val themeMode = stringPreferencesKey("theme_mode")
        val accent = stringPreferencesKey("accent")
        val animations = booleanPreferencesKey("animations")
        val language = stringPreferencesKey("language")
        val activeProfileId = stringPreferencesKey("active_profile_id")
        val runtimeId = stringPreferencesKey("runtime_id")
        val renderer = stringPreferencesKey("renderer")
        val jvmArgs = stringPreferencesKey("jvm_args")
        val maxMemoryMb = intPreferencesKey("max_memory_mb")
        val minMemoryMb = intPreferencesKey("min_memory_mb")
        val fpsLimit = intPreferencesKey("fps_limit")
        val renderDistance = intPreferencesKey("render_distance")
        val simulationDistance = intPreferencesKey("simulation_distance")
        val graphicsPreset = stringPreferencesKey("graphics_preset")
        val vsync = booleanPreferencesKey("vsync")
        val fullscreen = booleanPreferencesKey("fullscreen")
        val uiScale = intPreferencesKey("ui_scale")
        val particles = stringPreferencesKey("particles")
        val entityDistance = intPreferencesKey("entity_distance")
        val performanceProfile = stringPreferencesKey("performance_profile")
        val autoUpdate = booleanPreferencesKey("auto_update_versions")
        val concurrentDownloads = intPreferencesKey("concurrent_downloads")
        val retryFailed = booleanPreferencesKey("retry_failed_downloads")
        val discordPresence = booleanPreferencesKey("discord_presence")
        val discordSessionTime = booleanPreferencesKey("discord_session_time")
        val discordVersion = booleanPreferencesKey("discord_version")
        val telemetry = booleanPreferencesKey("telemetry")
        val notifications = booleanPreferencesKey("notifications")
        val advancedLogs = booleanPreferencesKey("advanced_logs")
        val playSecondsTotal = longPreferencesKey("play_seconds_total")
        val sessionsCount = longPreferencesKey("sessions_count")
    }

    val settings: Flow<LauncherSettings> = context.dataStore.data.map { p ->
        LauncherSettings(
            themeMode = p[K.themeMode] ?: "dark",
            accent = p[K.accent] ?: "emerald",
            animations = p[K.animations] ?: true,
            language = p[K.language] ?: "system",
            activeProfileId = p[K.activeProfileId] ?: "vanilla-latest",
            runtimeId = p[K.runtimeId] ?: "jre17-arm64",
            renderer = p[K.renderer] ?: "gl4es_114",
            jvmArgs = p[K.jvmArgs] ?: "-XX:+UseG1GC -XX:+UnlockExperimentalVMOptions -XX:G1NewSizePercent=20 -XX:G1ReservePercent=20 -XX:MaxGCPauseMillis=50 -XX:G1HeapRegionSize=32M",
            maxMemoryMb = p[K.maxMemoryMb] ?: 2048,
            minMemoryMb = p[K.minMemoryMb] ?: 512,
            fpsLimit = p[K.fpsLimit] ?: 60,
            renderDistance = p[K.renderDistance] ?: 8,
            simulationDistance = p[K.simulationDistance] ?: 6,
            graphicsPreset = p[K.graphicsPreset] ?: "balanced",
            vsync = p[K.vsync] ?: true,
            fullscreen = p[K.fullscreen] ?: true,
            uiScale = p[K.uiScale] ?: 100,
            particles = p[K.particles] ?: "all",
            entityDistance = p[K.entityDistance] ?: 100,
            performanceProfile = p[K.performanceProfile] ?: "balanced",
            autoUpdateVersions = p[K.autoUpdate] ?: true,
            concurrentDownloads = p[K.concurrentDownloads] ?: 4,
            retryFailedDownloads = p[K.retryFailed] ?: true,
            discordPresence = p[K.discordPresence] ?: false,
            discordShowSessionTime = p[K.discordSessionTime] ?: true,
            discordShowVersion = p[K.discordVersion] ?: true,
            telemetry = p[K.telemetry] ?: false,
            notifications = p[K.notifications] ?: true,
            showAdvancedLogs = p[K.advancedLogs] ?: false,
        )
    }

    val totalPlaySeconds: Flow<Long> = context.dataStore.data.map { it[K.playSecondsTotal] ?: 0L }
    val sessionsCount: Flow<Long> = context.dataStore.data.map { it[K.sessionsCount] ?: 0L }

    suspend fun update(transform: (LauncherSettings) -> LauncherSettings) {
        context.dataStore.edit { prefs ->
            val current = settingsSnapshot(prefs)
            val next = transform(current)
            prefs[K.themeMode] = next.themeMode
            prefs[K.accent] = next.accent
            prefs[K.animations] = next.animations
            prefs[K.language] = next.language
            prefs[K.activeProfileId] = next.activeProfileId
            prefs[K.runtimeId] = next.runtimeId
            prefs[K.renderer] = next.renderer
            prefs[K.jvmArgs] = next.jvmArgs
            prefs[K.maxMemoryMb] = next.maxMemoryMb
            prefs[K.minMemoryMb] = next.minMemoryMb
            prefs[K.fpsLimit] = next.fpsLimit
            prefs[K.renderDistance] = next.renderDistance
            prefs[K.simulationDistance] = next.simulationDistance
            prefs[K.graphicsPreset] = next.graphicsPreset
            prefs[K.vsync] = next.vsync
            prefs[K.fullscreen] = next.fullscreen
            prefs[K.uiScale] = next.uiScale
            prefs[K.particles] = next.particles
            prefs[K.entityDistance] = next.entityDistance
            prefs[K.performanceProfile] = next.performanceProfile
            prefs[K.autoUpdate] = next.autoUpdateVersions
            prefs[K.concurrentDownloads] = next.concurrentDownloads
            prefs[K.retryFailed] = next.retryFailedDownloads
            prefs[K.discordPresence] = next.discordPresence
            prefs[K.discordSessionTime] = next.discordShowSessionTime
            prefs[K.discordVersion] = next.discordShowVersion
            prefs[K.telemetry] = next.telemetry
            prefs[K.notifications] = next.notifications
            prefs[K.advancedLogs] = next.showAdvancedLogs
        }
    }

    suspend fun addPlayTime(seconds: Long) {
        context.dataStore.edit {
            it[K.playSecondsTotal] = (it[K.playSecondsTotal] ?: 0L) + seconds
        }
    }

    suspend fun countSession() {
        context.dataStore.edit { it[K.sessionsCount] = (it[K.sessionsCount] ?: 0L) + 1 }
    }

    private fun settingsSnapshot(p: Preferences): LauncherSettings = LauncherSettings(
        themeMode = p[K.themeMode] ?: "dark",
        accent = p[K.accent] ?: "emerald",
        animations = p[K.animations] ?: true,
        language = p[K.language] ?: "system",
        activeProfileId = p[K.activeProfileId] ?: "vanilla-latest",
        runtimeId = p[K.runtimeId] ?: "jre17-arm64",
        renderer = p[K.renderer] ?: "gl4es_114",
        jvmArgs = p[K.jvmArgs] ?: "",
        maxMemoryMb = p[K.maxMemoryMb] ?: 2048,
        minMemoryMb = p[K.minMemoryMb] ?: 512,
        fpsLimit = p[K.fpsLimit] ?: 60,
        renderDistance = p[K.renderDistance] ?: 8,
        simulationDistance = p[K.simulationDistance] ?: 6,
        graphicsPreset = p[K.graphicsPreset] ?: "balanced",
        vsync = p[K.vsync] ?: true,
        fullscreen = p[K.fullscreen] ?: true,
        uiScale = p[K.uiScale] ?: 100,
        particles = p[K.particles] ?: "all",
        entityDistance = p[K.entityDistance] ?: 100,
        performanceProfile = p[K.performanceProfile] ?: "balanced",
        autoUpdateVersions = p[K.autoUpdate] ?: true,
        concurrentDownloads = p[K.concurrentDownloads] ?: 4,
        retryFailedDownloads = p[K.retryFailed] ?: true,
        discordPresence = p[K.discordPresence] ?: false,
        discordShowSessionTime = p[K.discordSessionTime] ?: true,
        discordShowVersion = p[K.discordVersion] ?: true,
        telemetry = p[K.telemetry] ?: false,
        notifications = p[K.notifications] ?: true,
        showAdvancedLogs = p[K.advancedLogs] ?: false,
    )
}
