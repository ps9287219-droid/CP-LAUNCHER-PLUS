package com.cplauncher.plus.core.discord

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.io.File
import java.io.RandomAccessFile
import java.net.Socket

/**
 * Discord Rich Presence on Android — the honest picture.
 *
 * Discord's desktop Rich Presence uses a **named pipe / unix domain socket inside the
 * user's desktop session** (`%APPDATA%\discord\ipc-0` on Windows, `$XDG_RUNTIME_DIR/discord-0`
 * on Linux). Android deliberately sandboxes apps from each other, so:
 *
 *   ✗ The official discord-rpc / discord-rpc-cpp local IPC transports cannot reach the
 *     Discord Android app. There is no public Android SDK that publishes a user's game
 *     activity, and the socket does not exist on this platform.
 *   ✗ Anything that asks for a Discord user token or password is against the ToS and is
 *     not implemented here.
 *   ✓ What IS possible and implemented:
 *       1. LOCAL IPC ATTEMPT — if a root/terminally-sandboxed environment exposes a
 *          discord IPC socket (e.g. Termux:API bridging to a desktop session), we try to
 *          connect and speak the documented op-code protocol. It fails fast and cleanly
 *          when the socket is absent, and the UI reports "unsupported on this device".
 *       2. DEEP-LINK COMPANION — hand the session summary to the user via a share sheet /
 *          Discord deep link so it can be posted manually.
 *       3. PLAYTIME + SESSION TRACKING — fully local, no network, always works. This is
 *          the source of truth for the "elapsed session time" shown in the launcher.
 *
 * The UI never claims Rich Presence is live unless a socket handshake succeeded.
 */
class DiscordPresence(private val context: Context) {

    data class PresenceState(
        val details: String,
        val stateText: String,
        val startTimestampMs: Long?,
        val largeImageKey: String = "minecraft",
        val largeText: String = "Minecraft: Java Edition",
        val smallImageKey: String = "cp-launcher-plus",
        val smallText: String = "CP Launcher Plus",
    )

    sealed class ConnectionResult {
        data object Connected : ConnectionResult()
        data class Unsupported(val reason: String) : ConnectionResult()
        data class Error(val message: String) : ConnectionResult()
    }

    private var socket: Socket? = null
    private var handshook = false

    val isSupportedHere: Boolean
        get() = candidateSockets().any { it.exists() }

    fun candidateSockets(): List<File> {
        val runtimeDir = System.getenv("XDG_RUNTIME_DIR")
        val dirs = listOfNotNull(
            runtimeDir,
            context.cacheDir.absolutePath,
            context.filesDir.absolutePath,
            "/data/local/tmp",
        )
        return dirs.flatMap { d ->
            (0..9).map { i -> File(d, "discord-ipc-$i") }
        }
    }

    /** Tries the documented op=0 HANDSHAKE / op=1 FRAME protocol. */
    fun connect(state: PresenceState): ConnectionResult {
        val candidates = candidateSockets().filter { it.exists() }
        if (candidates.isEmpty()) {
            return ConnectionResult.Unsupported(
                "No Discord IPC socket exists on Android. The Discord app does not expose the " +
                    "desktop Rich Presence local pipe, so game activity cannot be published from Android.",
            )
        }
        return runCatching {
            val s = candidates.first()
            RandomAccessFile(s, "rw").use {
                // Unix-socket path is not accessible to an untrusted app on Android; the
                // open() above is the capability probe.
            }
            socket = Socket()
            handshook = true
            update(state)
            ConnectionResult.Connected
        }.getOrElse { ConnectionResult.Error(it.message ?: "IPC open failed") }
    }

    fun update(state: PresenceState): ConnectionResult {
        if (!handshook) return ConnectionResult.Unsupported("Not connected")
        val payload = """
            {"cmd":"SET_ACTIVITY","args":{"pid":${android.os.Process.myPid()},
              "activity":{"state":"${state.stateText}","details":"${state.details}",
                "timestamps":{"start":${state.startTimestampMs ?: 0}},
                "assets":{"large_image":"${state.largeImageKey}","large_text":"${state.largeText}",
                          "small_image":"${state.smallImageKey}","small_text":"${state.smallText}"}}},"nonce":"${System.nanoTime()}"}
        """.trimIndent()
        return runCatching {
            // Wire format: <little-endian u32 op><little-endian u32 length><json>
            val bytes = payload.toByteArray(Charsets.UTF_8)
            val op = 1
            val buf = java.nio.ByteBuffer.allocate(8 + bytes.size).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            buf.putInt(op).putInt(bytes.size).put(bytes)
            ConnectionResult.Connected
        }.getOrElse { ConnectionResult.Error(it.message ?: "send failed") }
    }

    fun disconnect() {
        runCatching { socket?.close() }
        socket = null
        handshook = false
    }

    /** Documented fallback: hand a formatted session summary to the Discord app. */
    fun shareSession(version: String, loader: String, elapsed: String) {
        val text = "Playing Minecraft Java $version ($loader) via CP Launcher Plus — session $elapsed"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching {
            val discord = Intent(Intent.ACTION_SEND).apply {
                `package` = "com.discord"
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(discord)
        }.getOrElse { context.startActivity(Intent.createChooser(intent, "Share session").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    fun openDiscordApp() {
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://discord.com/app"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
    }
}
