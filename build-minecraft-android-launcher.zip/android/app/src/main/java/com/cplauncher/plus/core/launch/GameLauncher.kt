package com.cplauncher.plus.core.launch

import android.content.Context
import com.cplauncher.plus.core.accounts.AccountStore
import com.cplauncher.plus.core.runtime.JreManager
import com.cplauncher.plus.core.session.PlayTimeTracker
import com.cplauncher.plus.core.util.Net
import com.cplauncher.plus.data.model.Account
import com.cplauncher.plus.data.model.LaunchStage
import com.cplauncher.plus.data.model.Loader
import com.cplauncher.plus.core.settings.LauncherSettings
import com.cplauncher.plus.core.versions.ResolvedVersion
import com.cplauncher.plus.core.versions.VersionInstaller
import com.cplauncher.plus.core.versions.VersionManifest
import com.cplauncher.plus.core.versions.VersionResolver
import kotlinx.coroutines.Dispatchers
import org.json.JSONObject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Orchestrates a full launch: install → runtime → natives → JVM → session.
 * Every stage is reported through [state]; the UI shows exactly what is happening.
 */
class GameLauncher(
    private val context: Context,
    private val settings: LauncherSettings,
) {
    private val jre = JreManager(context)
    private val manifest = VersionManifest(context)
    private val configurator = LaunchConfigurator(context, settings, jre)
    private val tracker = PlayTimeTracker(context)

    private val _state = MutableStateFlow(LaunchUiState.idle())
    val state: StateFlow<LaunchUiState> = _state

    data class LaunchUiState(
        val stage: LaunchStage,
        val label: String,
        val progressCurrent: Long,
        val progressTotal: Long,
        val indeterminate: Boolean,
        val logs: List<String>,
        val startedAt: Long?,
        val lastError: String?,
        val preFlightProblems: List<String>,
    ) {
        val isLaunching get() = stage != LaunchStage.IDLE && stage != LaunchStage.RUNNING &&
            stage != LaunchStage.EXITED && stage != LaunchStage.CRASHED && stage != LaunchStage.FAILED
        val isRunning get() = stage == LaunchStage.RUNNING

        companion object {
            fun idle() = LaunchUiState(LaunchStage.IDLE, "Ready", 0, 0, true, emptyList(), null, null, emptyList())
        }
    }

    private fun setStage(stage: LaunchStage, label: String, indeterminate: Boolean = true) {
        _state.value = _state.value.copy(stage = stage, label = label, indeterminate = indeterminate)
    }

    private fun log(line: String) {
        _state.value = _state.value.copy(logs = (_state.value.logs + line).takeLast(400))
        SessionEventBus.publish(line)
    }

    /**
     * Full launch. Throws only on unrecoverable problems that the user must see.
     */
    suspend fun launch(
        mcVersionId: String,
        loader: Loader,
        loaderVersion: String?,
        resolvedLoaderJson: JSONObject?,
        account: Account,
        offlineUuid: String?,
    ): LaunchConfigurator.LaunchPlan? = withContext(Dispatchers.Default) {
        try {
            _state.value = LaunchUiState.idle()
            setStage(LaunchStage.PREPARING, "Resolving ${mcVersionId}…")

            // ---- resolve version (supports loader-inherited versions) ----------
            val versionJson = if (resolvedLoaderJson != null) resolvedLoaderJson else manifest.versionJson(mcVersionId)
            var resolved = VersionResolver.resolve(versionJson)
            resolved.inheritsFrom?.let { parent ->
                val parentJson = manifest.versionJson(parent)
                val parentResolved = VersionResolver.resolve(parentJson)
                resolved = merge(parentResolved, resolved)
            }

            // ---- runtime -------------------------------------------------------
            val spec = jre.runtimeFor(resolved.javaMajor)
            if (!jre.supported) {
                throw IllegalStateException(
                    "This device reports ABI '${jre.abi}'. Minecraft Java on Android needs arm64-v8a or x86_64.",
                )
            }
            if (!jre.isInstalled(spec)) {
                setStage(LaunchStage.DOWNLOADING_RUNTIME, "Installing ${spec.id} (required for MC ${resolved.id})")
                jre.downloadAndExtract(spec) { label, r, t ->
                    _state.value = _state.value.copy(
                        stage = LaunchStage.DOWNLOADING_RUNTIME,
                        label = label,
                        progressCurrent = r,
                        progressTotal = t,
                        indeterminate = t <= 0,
                    )
                }
            } else {
                log("Runtime ${spec.id} already installed (${jre.runtimeSize(spec.id) / (1024 * 1024)} MB)")
            }

            // ---- install version ------------------------------------------------
            val installer = VersionInstaller(context, "default").apply { concurrency = settings.concurrentDownloads }
            if (!File(File(com.cplauncher.plus.core.util.Fs.gameRoot(context, "default"), "versions/${resolved.id}"), "${resolved.id}.jar").exists()) {
                setStage(LaunchStage.DOWNLOADING_VERSION, "Downloading Minecraft ${resolved.id}")
                val plan = resolved
                installer.install(plan) { p ->
                    _state.value = _state.value.copy(
                        stage = LaunchStage.DOWNLOADING_VERSION,
                        label = p.label,
                        progressCurrent = p.bytes,
                        progressTotal = p.totalBytes,
                        indeterminate = false,
                    )
                }
            } else {
                log("Version ${resolved.id} already installed")
            }

            // ---- plan ------------------------------------------------------------
            setStage(LaunchStage.EXTRACTING_NATIVES, "Preparing native libraries")
            val plan = configurator.buildPlan(resolved, loader, loaderVersion, account, offlineUuid, resolved.assetsIndexId)

            val problems = configurator.preFlight(plan)
            if (problems.isNotEmpty()) {
                problems.forEach { log("PRE-FLIGHT: $it") }
                _state.value = _state.value.copy(stage = LaunchStage.FAILED, label = "Launch blocked", preFlightProblems = problems, lastError = problems.joinToString("; "))
                return@withContext null
            }

            // ---- run ------------------------------------------------------------
            setStage(LaunchStage.STARTING_JVM, "Starting Java ${resolved.javaMajor} JVM")
            tracker.beginSession(mcVersionId, loader)
            _state.value = _state.value.copy(startedAt = System.currentTimeMillis())

            val exit: JvmBridge.ExitInfo = when (mode) {
                JvmBridge.Mode.IN_PROCESS -> JvmBridge.startInProcess(
                    jvmHome = plan.jvmHome,
                    jvmArgs = plan.jvmArgs.toTypedArray(),
                    mainClass = plan.mainClass,
                    gameArgs = plan.gameArgs.toTypedArray(),
                    env = plan.env,
                    nativesDir = plan.nativesDir,
                    onLog = { log(it) },
                )

                JvmBridge.Mode.SUBPROCESS -> JvmBridge.startSubprocess(
                    javaBinary = File(plan.jvmHome, "bin/java"),
                    jvmArgs = plan.jvmArgs,
                    mainClass = plan.mainClass,
                    gameArgs = plan.gameArgs,
                    env = plan.env,
                    workDir = plan.gameDir,
                    onLog = { log(it) },
                )
            }

            val seconds = (exit.durationMs / 1000L)
            tracker.endSession(seconds)

            if (exit.crashed) {
                val crash = CrashReporter.writeCrashReport(context, resolved.id, exit, _state.value.logs)
                _state.value = _state.value.copy(
                    stage = LaunchStage.CRASHED,
                    label = exit.message,
                    lastError = crash.absolutePath,
                )
            } else {
                _state.value = _state.value.copy(stage = LaunchStage.EXITED, label = exit.message)
            }
            plan
        } catch (t: Throwable) {
            val msg = t.message ?: t.javaClass.simpleName
            log("ERROR: $msg")
            _state.value = _state.value.copy(stage = LaunchStage.FAILED, label = "Launch failed", lastError = msg)
            null
        }
    }

    var mode: JvmBridge.Mode = JvmBridge.Mode.IN_PROCESS

    /** Merge a loader (Fabric/Forge/NeoForge) version with its vanilla parent. */
    private fun merge(parent: ResolvedVersion, child: ResolvedVersion): ResolvedVersion = child.copy(
        libraries = parent.libraries + child.libraries,
        jvmArgs = child.jvmArgs.ifEmpty { parent.jvmArgs },
        gameArgs = child.gameArgs.ifEmpty { parent.gameArgs },
        minecraftArguments = child.minecraftArguments ?: parent.minecraftArguments,
        assetsIndexId = child.assetsIndexId.ifEmpty { parent.assetsIndexId },
        loggingArg = child.loggingArg ?: parent.loggingArg,
        mainClass = child.mainClass.ifEmpty { parent.mainClass },
        totalDownloadBytes = parent.totalDownloadBytes + child.totalDownloadBytes,
    )

    fun cancel() {
        Net.downloadPause = true
        log("Download paused by user")
    }

    fun resume() {
        Net.downloadPause = false
    }
}

/** Loads or creates the launcher_profiles.json Minecraft expects next to the game dir. */
object LauncherProfiles {
    fun ensure(context: Context, profileDir: String = "default"): File {
        val root = com.cplauncher.plus.core.util.Fs.gameRoot(context, profileDir)
        val f = File(root, "launcher_profiles.json")
        if (!f.exists()) {
            com.cplauncher.plus.core.util.Fs.writeText(
                f,
                """
                {
                  "profiles": {
                    "cp-launcher-plus": {
                      "name": "CP Launcher Plus",
                      "type": "custom",
                      "created": "${java.time.Instant.now()}",
                      "lastUsed": "${java.time.Instant.now()}",
                      "icon": "Grass"
                    }
                  },
                  "settings": {},
                  "version": 3
                }
                """.trimIndent(),
            )
        }
        return f
    }
}
