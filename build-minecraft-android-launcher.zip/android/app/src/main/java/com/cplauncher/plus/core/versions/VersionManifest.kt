package com.cplauncher.plus.core.versions

import android.content.Context
import com.cplauncher.plus.core.util.Net
import com.cplauncher.plus.data.model.McVersion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Reads Mojang's official piston-meta version manifest (v2) and per-version JSON.
 * Endpoint: https://piston-meta.mojang.com/mc/game/version_manifest_v2.json
 */
class VersionManifest(private val context: Context) {

    private val cacheFile get() = java.io.File(context.cacheDir, "version_manifest_v2.json")

    suspend fun refresh(force: Boolean = false): List<McVersion> = withContext(Dispatchers.IO) {
        val text = if (!force && cacheFile.exists() && cacheFile.lastModified() > System.currentTimeMillis() - HOUR) {
            cacheFile.readText()
        } else {
            Net.text(MANIFEST_URL).also { cacheFile.writeText(it) }
        }
        parse(JSONObject(text))
    }

    fun parse(root: JSONObject): List<McVersion> {
        val arr = root.getJSONObject("versions")
        val out = ArrayList<McVersion>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                McVersion(
                    id = o.getString("id"),
                    type = o.optString("type", "release"),
                    url = o.getString("url"),
                    releaseTime = o.optString("releaseTime", ""),
                    sha1 = o.optString("sha1", "").ifEmpty { null },
                ),
            )
        }
        return out
    }

    suspend fun versionJson(id: String): JSONObject {
        val versions = refresh(false)
        val entry = versions.firstOrNull { it.id == id }
            ?: throw IllegalArgumentException("Unknown Minecraft version: $id")
        return JSONObject(Net.text(entry.url))
    }

    /** Latest version of the requested type. */
    fun latestOf(versions: List<McVersion>, type: String = "release"): String? =
        versions.firstOrNull { it.type == type }?.id

    companion object {
        const val MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
        private const val HOUR = 60 * 60 * 1000L
    }
}

/** Static, immutable description of a parsed version, used by the installer/launcher. */
data class ResolvedVersion(
    val id: String,
    val mainClass: String,
    val assetsIndexId: String,
    val assetIndexUrl: String,
    val clientUrl: String,
    val clientSha1: String,
    val clientSize: Long,
    val libraries: List<LibEntry>,
    val jvmArgs: List<String>,
    val gameArgs: List<String>,
    val minecraftArguments: String?,
    val inheritsFrom: String?,
    val loggingArg: String?,
    val javaMajor: Int,
    val totalDownloadBytes: Long,
) {
    data class LibEntry(
        val name: String,
        val path: String,          // path under libraries/
        val url: String,
        val sha1: String,
        val size: Long,
        val isNative: Boolean,
        val nativeClassifier: String?,
        val appliesToAndroid: Boolean,
    )
}

object VersionResolver {

    private val ANDROID_OS_RULE = "linux"

    /** Turns Mojang's version JSON into a flat, Android-applicable download plan. */
    fun resolve(json: JSONObject): ResolvedVersion {
        val libJson = json.optJSONArray("libraries") ?: JSONArray()
        val libs = ArrayList<ResolvedVersion.LibEntry>()
        var total = 0L

        for (i in 0 until libJson.length()) {
            val l = libJson.getJSONObject(i)
            if (!ruleAllows(l.optJSONObject("rules"), ANDROID_OS_RULE)) continue

            val downloads = l.optJSONObject("downloads") ?: continue
            val artifact = downloads.optJSONObject("artifact") ?: continue

            // Some libraries ship Linux natives separately (lwjgl-glfw, openal, ...).
            val classifiers = downloads.optJSONObject("classifiers")
            val nativeObj = classifiers?.optJSONObject("natives-linux")
            val group = l.getString("name").substringBefore(':')

            // The GL/GLFW natives shipped by Mojang target desktop X11 and cannot run on
            // Android; the launcher substitutes an Android port (see NativeSubstitution).
            val applies = !NativeSubstitution.isDesktopOnly(group)

            libs.add(
                ResolvedVersion.LibEntry(
                    name = l.getString("name"),
                    path = artifact.getString("path"),
                    url = artifact.getString("url"),
                    sha1 = artifact.optString("sha1", ""),
                    size = artifact.optLong("size", 0L),
                    isNative = false,
                    nativeClassifier = nativeObj?.optString("path"),
                    appliesToAndroid = applies,
                ),
            )
            if (applies) total += artifact.optLong("size", 0L)
            nativeObj?.let { total += it.optLong("size", 0L) }
        }

        val clientDl = json.getJSONObject("downloads").getJSONObject("client")
        total += clientDl.optLong("size", 0L)

        val assetIndex = json.getJSONObject("assetIndex")
        val args = json.optJSONObject("arguments")
        val jvmArgsList = args?.optJSONArray("jvm")?.let { stringList(it) } ?: emptyList()
        val gameArgsList = args?.optJSONArray("game")?.let { stringList(it) } ?: emptyList()

        val logging = json.optJSONObject("logging")
        val loggingArg = logging?.optJSONObject("client")?.optJSONArray("argument")
            ?.let { if (it.length() > 0) it.getString(0) else null }

        return ResolvedVersion(
            id = json.getString("id"),
            mainClass = json.optString("mainClass", "net.minecraft.client.main.Main"),
            assetsIndexId = assetIndex.getString("id"),
            assetIndexUrl = assetIndex.getString("url"),
            clientUrl = clientDl.getString("url"),
            clientSha1 = clientDl.optString("sha1", ""),
            clientSize = clientDl.optLong("size", 0L),
            libraries = libs,
            jvmArgs = jvmArgsList,
            gameArgs = gameArgsList,
            minecraftArguments = json.optString("minecraftArguments", "").ifEmpty { null },
            inheritsFrom = json.optString("inheritsFrom", "").ifEmpty { null },
            loggingArg = loggingArg,
            javaMajor = majorFromVersionJson(json),
            totalDownloadBytes = total,
        )
    }

    private fun stringList(arr: JSONArray): List<String> {
        val out = ArrayList<String>(arr.length())
        for (i in 0 until arr.length()) {
            when (val v = arr.get(i)) {
                is String -> out.add(v)
                is JSONObject -> if (ruleAllows(v.optJSONObject("rules"), ANDROID_OS_RULE)) {
                    out.add(v.getString("value"))
                }
            }
        }
        return out
    }

    /** Mojang rule evaluation (os / features). Feature rules are treated as off unless enabled. */
    fun ruleAllows(rules: JSONObject?, os: String): Boolean {
        if (rules == null) return true
        val list = rules.optJSONArray("rules") ?: return true
        var allowed = false
        for (i in 0 until list.length()) {
            val r = list.getJSONObject(i)
            val osRule = r.optJSONObject("os")
            var matches = true
            if (osRule != null) {
                val name = osRule.optString("name", "")
                if (name.isNotEmpty()) matches = (name == os)
            }
            if (matches) allowed = (r.optString("action") == "allow")
        }
        return allowed
    }

    private fun majorFromVersionJson(json: JSONObject): Int {
        // Mojang publishes the required Java version in `javaVersion.majorVersion`.
        return json.optJSONObject("javaVersion")?.optInt("majorVersion", 8) ?: 8
    }
}

/**
 * Desktop natives that can never work on Android are replaced by Android ports
 * (LWJGL-for-Android / gl4es / ANGLE style shims) supplied by the runtime pack.
 */
object NativeSubstitution {
    private val desktopOnly = setOf(
        "org.lwjgl", "org.lwjgl.lwjgl", "net.java.jinput", "net.java.jutils",
        "tv.twitch", "com.mojang", // text2speech / twitch platform libs are desktop-only
    )

    fun isDesktopOnly(group: String): Boolean = desktopOnly.any { group.startsWith(it) }

    /** Android-side replacement natives copied from the runtime pack into natives dir. */
    val androidNatives = listOf(
        "liblwjgl.so", "liblwjgl_opengl.so", "liblwjgl_stb.so", "liblwjgl_glfw.so",
        "libopenal.so", "libgl4es_114.so", "libangle_android.so",
    )
}
