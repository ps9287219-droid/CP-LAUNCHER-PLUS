package com.cplauncher.plus.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cplauncher.plus.CPLauncherApp
import com.cplauncher.plus.LauncherViewModel
import com.cplauncher.plus.core.mods.ModManager
import com.cplauncher.plus.core.mods.ModrinthApi
import com.cplauncher.plus.ui.common.CpCard
import com.cplauncher.plus.ui.common.ProgressBar
import com.cplauncher.plus.ui.common.SectionTitle
import com.cplauncher.plus.ui.common.StatusPill
import kotlinx.coroutines.launch

@Composable
fun ModsScreen(vm: LauncherViewModel) {
    val settings by vm.settings.collectAsState()
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<ModrinthApi.SearchResult>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<com.cplauncher.plus.data.model.Progress?>(null) }
    var tab by remember { mutableStateOf("browse") }
    var audit by remember { mutableStateOf<List<String>>(emptyList()) }
    val profile = vm.allProfiles().firstOrNull { it.id == settings.activeProfileId }
    val loaderSlugs = when (profile?.loader) {
        com.cplauncher.plus.data.model.Loader.FABRIC -> listOf("fabric")
        com.cplauncher.plus.data.model.Loader.FORGE -> listOf("forge")
        com.cplauncher.plus.data.model.Loader.NEOFORGE -> listOf("neoforge")
        com.cplauncher.plus.data.model.Loader.QUILT -> listOf("quilt")
        else -> listOf("fabric")
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        SectionTitle("Mods — ${profile?.name ?: "no profile"}")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = tab == "browse", onClick = { tab = "browse" }, label = { Text("Browse Modrinth") })
            FilterChip(selected = tab == "installed", onClick = { tab = "installed" }, label = { Text("Installed") })
            FilterChip(selected = tab == "audit", onClick = { tab = "audit"; audit = vm.modAudit() }, label = { Text("Conflicts") })
        }
        Spacer(Modifier.height(8.dp))

        when (tab) {
            "browse" -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        label = { Text("Search mods") },
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(
                        enabled = !loading && query.isNotBlank(),
                        onClick = {
                            loading = true
                            scope.launch {
                                results = runCatching {
                                    ModrinthApi().search(query, loaderSlugs, profile?.mcVersion ?: "")
                                }.getOrDefault(emptyList())
                                loading = false
                            }
                        },
                    ) { Text("Search") }
                }
                if (loading) Text("Searching Modrinth…", style = MaterialTheme.typography.bodySmall)
                progress?.let { Spacer(Modifier.height(8.dp)); ProgressBar(it.label, it.current, it.total, it.indeterminate) }
                Spacer(Modifier.height(8.dp))
                LazyColumn {
                    items(results) { r ->
                        CpCard(Modifier.padding(vertical = 4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(r.title, style = MaterialTheme.typography.titleMedium)
                                    Text(r.description, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        r.loaders.take(3).forEach { StatusPill(it) }
                                        Text("${r.downloads} downloads", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                                Button(onClick = {
                                    scope.launch {
                                        loading = true
                                        runCatching {
                                            val versions = ModrinthApi().versions(r.slug, profile?.mcVersion, loaderSlugs)
                                            val ref = versions.firstOrNull() ?: throw IllegalStateException("No build for ${profile?.mcVersion} / ${loaderSlugs.first()}")
                                            val missing = ref.required.filter { it.required }.map { it.projectId }
                                            ModrinthApi().download(ref, com.cplauncher.plus.core.util.Fs.dir(CPLauncherApp.instance, com.cplauncher.plus.core.util.Fs.MODS)) { c, t ->
                                                progress = com.cplauncher.plus.data.model.Progress(ref.filename, c, t)
                                            }
                                            missing.forEach {
                                                progress = com.cplauncher.plus.data.model.Progress("Dependency $it", 0, 1, true)
                                                val depVer = ModrinthApi().versions(it, profile?.mcVersion, loaderSlugs).firstOrNull()
                                                depVer?.let { v ->
                                                    ModrinthApi().download(v, com.cplauncher.plus.core.util.Fs.dir(CPLauncherApp.instance, com.cplauncher.plus.core.util.Fs.MODS)) { _, _ -> }
                                                }
                                            }
                                        }.onFailure { progress = com.cplauncher.plus.data.model.Progress("Failed: ${it.message}", 1, 1) }
                                        loading = false
                                    }
                                }) { Text("Install") }
                            }
                        }
                    }
                }
            }

            "installed" -> {
                val manager = ModManager(CPLauncherApp.instance)
                val files = manager.list()
                LazyColumn {
                    items(files) { f ->
                        val insp = manager.inspect(f)
                        CpCard(Modifier.padding(vertical = 4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(insp.name ?: f.name, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        listOfNotNull(insp.version, insp.modId).joinToString(" · ").ifEmpty { "Unknown metadata" },
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                }
                                Switch(checked = true, onCheckedChange = { manager.setEnabled(f, false) })
                                OutlinedButton(onClick = { manager.delete(f) }) { Text("Remove") }
                            }
                        }
                    }
                }
            }

            else -> {
                LazyColumn {
                    items(audit) { problem ->
                        CpCard(Modifier.padding(vertical = 4.dp)) {
                            Text(problem, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}

private val Modifier.width: androidx.compose.ui.Modifier
    get() = this
