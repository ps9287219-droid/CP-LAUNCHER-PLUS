package com.cplauncher.plus.core.perf

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import com.cplauncher.plus.core.settings.LauncherSettings

/**
 * Reads what Android actually exposes and turns it into safe recommendations.
 * No fake "RAM cleaner", no claims of increasing physical memory.
 */
data class DeviceCapabilities(
    val abi: String,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val javaHeapMb: Int,
    val largeHeapMb: Int,
    val cores: Int,
    val apiLevel: Int,
    val vulkan: Boolean,
    val thermalStatus: String,
    val isLowRam: Boolean,
) {
    val recommendedMemoryMb: Int
        get() = when {
            totalRamMb >= 12_000 -> 4096
            totalRamMb >= 8_000 -> 3072
            totalRamMb >= 6_000 -> 2560
            totalRamMb >= 4_000 -> 2048
            totalRamMb >= 3_000 -> 1536
            else -> 1024
        }

    val recommendedProfile: String
        get() = when {
            totalRamMb >= 8_000 && cores >= 8 -> "high"
            totalRamMb >= 4_000 -> "balanced"
            else -> "low"
        }

    val warnings: List<String>
        get() = buildList {
            if (abi != "arm64-v8a" && abi != "x86_64") add("32-bit ABI — Minecraft 1.13+ will not run")
            if (totalRamMb < 3_000) add("Under 3 GB RAM — expect low render distance and frequent GC")
            if (isLowRam) add("Device flagged as low-RAM by Android")
            if (!vulkan) add("No Vulkan — ANGLE/Zink renderers unavailable, gl4es (GLES 2) will be used")
            if (thermalStatus != "NONE") add("Thermal throttling reported: $thermalStatus")
        }
}

object DeviceProfile {

    fun read(context: Context): DeviceCapabilities {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)

        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val thermal = runCatching {
            val pmField = pm?.let { p ->
                p.currentThermalStatus.let { s ->
                    when (s) {
                        PowerManager.THERMAL_STATUS_NONE -> "NONE"
                        PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT"
                        PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"
                        PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE"
                        PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL"
                        else -> "EMERGENCY"
                    }
                }
            }
            pmField ?: "UNKNOWN"
        }.getOrDefault("UNKNOWN")

        val hasVulkan = context.packageManager.hasSystemFeature("android.hardware.vulkan.version") ||
            runCatching { Build.SUPPORTED_ABIS.isNotEmpty() && android.os.Build.VERSION.SDK_INT >= 26 }
                .getOrDefault(false)

        return DeviceCapabilities(
            abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown",
            totalRamMb = mi.totalMem / (1024 * 1024),
            availableRamMb = mi.availMem / (1024 * 1024),
            javaHeapMb = am.memoryClass,
            largeHeapMb = am.largeMemoryClass,
            cores = Runtime.getRuntime().availableProcessors(),
            apiLevel = Build.VERSION.SDK_INT,
            vulkan = hasVulkan,
            thermalStatus = thermal,
            isLowRam = am.isLowRamDevice,
        )
    }
}

/**
 * Tuned option sets applied to options.txt + JVM args. These are real Minecraft
 * settings; nothing here invents performance that the hardware cannot deliver.
 */
object PerformanceProfiles {

    data class Profile(
        val id: String,
        val name: String,
        val description: String,
        val fpsLimit: Int,
        val renderDistance: Int,
        val simulationDistance: Int,
        val particles: String,
        val graphicsMode: String,
        val entityDistance: Int,
        val smoothLighting: Boolean,
        val vsync: Boolean,
        val recommendedMods: List<String>,
    )

    val LOW = Profile(
        "low", "Low", "Maximum FPS on 2–4 GB devices. Minimal visuals.",
        fpsLimit = 40, renderDistance = 4, simulationDistance = 4, particles = "minimal",
        graphicsMode = "fast", entityDistance = 50, smoothLighting = false, vsync = false,
        recommendedMods = listOf("sodium", "lithium", "ferrite-core", "immediatelyfast", "lazydfu"),
    )

    val BALANCED = Profile(
        "balanced", "Balanced", "Good FPS with normal visuals on mid-range phones.",
        fpsLimit = 60, renderDistance = 8, simulationDistance = 6, particles = "decreased",
        graphicsMode = "fancy", entityDistance = 100, smoothLighting = true, vsync = true,
        recommendedMods = listOf("sodium", "lithium", "ferrite-core"),
    )

    val HIGH = Profile(
        "high", "High", "Full visuals for flagships with 8 GB+ RAM.",
        fpsLimit = 90, renderDistance = 12, simulationDistance = 10, particles = "all",
        graphicsMode = "fancy", entityDistance = 150, smoothLighting = true, vsync = false,
        recommendedMods = listOf("sodium", "lithium", "ferrite-core", "immediatelyfast"),
    )

    val CUSTOM = Profile(
        "custom", "Custom", "Your own values from the sliders below.",
        fpsLimit = 60, renderDistance = 8, simulationDistance = 6, particles = "all",
        graphicsMode = "fancy", entityDistance = 100, smoothLighting = true, vsync = true,
        recommendedMods = emptyList(),
    )

    val ALL = listOf(LOW, BALANCED, HIGH, CUSTOM)

    fun byId(id: String): Profile = ALL.firstOrNull { it.id == id } ?: BALANCED

    fun applyTo(settings: LauncherSettings, p: Profile): LauncherSettings = settings.copy(
        performanceProfile = p.id,
        fpsLimit = p.fpsLimit,
        renderDistance = p.renderDistance,
        simulationDistance = p.simulationDistance,
        particles = p.particles,
        graphicsPreset = if (p.id == "custom") "custom" else p.graphicsMode,
        entityDistance = p.entityDistance,
        vsync = p.vsync,
        maxMemoryMb = p.id.takeIf { it != "custom" }?.let { id ->
            when (id) {
                "low" -> 1536
                "balanced" -> 2048
                else -> 4096
            }
        } ?: settings.maxMemoryMb,
    )
}

/**
 * Renderer matrix. A shader pack only "works" when the whole chain supports it,
 * and this object is what the UI consults before saying so.
 */
object RendererMatrix {
    data class Renderer(val id: String, val name: String, val api: String, val shaders: Boolean, val notes: String)

    val ALL = listOf(
        Renderer("gl4es_114", "gl4es 1.1.4", "OpenGL 2.1 via GLES 2", false, "Most compatible; no shader-pack support"),
        Renderer("zink_vulkan", "Zink", "OpenGL 4.6 via Vulkan", true, "Shaders possible with Iris; needs a Vulkan-capable GPU"),
        Renderer("angle_vulkan", "ANGLE", "GLES 3 via Vulkan", false, "Faster on Adreno, limited desktop GL features"),
        Renderer("virgl", "VirGL", "OpenGL 3.3 proxy", true, "Experimental; used by some Pojav forks"),
    )

    fun byId(id: String): Renderer = ALL.firstOrNull { it.id == id } ?: ALL.first()

    fun shaderCapable(id: String): Boolean = byId(id).shaders
}
