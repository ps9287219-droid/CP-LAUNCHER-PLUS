package com.cplauncher.plus.core.session

import android.content.Context
import com.cplauncher.plus.core.util.Fs
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Local, private playtime history. Never uploaded anywhere. */
class HistoryStore(private val context: Context) {

    private val file: File get() = File(Fs.baseDir(context), "playtime-history.json")

    data class Record(
        val version: String,
        val loader: String,
        val startedAt: Long,
        val seconds: Long,
    )

    fun append(session: PlayTimeTracker.Session, seconds: Long) {
        val arr = JSONArray(Fs.readText(file).ifEmpty { "[]" })
        arr.put(
            JSONObject()
                .put("version", session.version)
                .put("loader", session.loader)
                .put("startedAt", session.startedAt)
                .put("seconds", seconds),
        )
        Fs.writeText(file, arr.toString())
    }

    fun all(): List<Record> {
        val arr = runCatching { JSONArray(Fs.readText(file).ifEmpty { "[]" }) }.getOrDefault(JSONArray())
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            Record(o.optString("version"), o.optString("loader"), o.optLong("startedAt"), o.optLong("seconds"))
        }
    }

    fun totalSeconds(): Long = all().sumOf { it.seconds }

    fun last7Days(): List<Pair<String, Long>> {
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val map = linkedMapOf<String, Long>()
        for (i in 6 downTo 0) {
            val d = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, -i) }.time
            map[fmt.format(d)] = 0L
        }
        all().forEach { r ->
            val key = fmt.format(java.util.Date(r.startedAt))
            if (map.containsKey(key)) map[key] = map.getValue(key) + r.seconds
        }
        return map.toList()
    }

    fun averageSessionSeconds(): Long {
        val all = all()
        return if (all.isEmpty()) 0 else all.sumOf { it.seconds } / all.size
    }
}
