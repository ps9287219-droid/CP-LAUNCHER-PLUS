package com.cplauncher.plus.data

import android.content.Context
import com.cplauncher.plus.core.util.Fs
import com.cplauncher.plus.data.model.InstallProfile
import com.cplauncher.plus.data.model.Loader
import com.cplauncher.plus.data.model.McVersion
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Installed launcher profiles (installations), persisted next to the game data. */
class ProfileRepository(private val context: Context) {

    private val file: File get() = File(Fs.baseDir(context), "profiles.json")

    fun all(): List<InstallProfile> {
        val arr = runCatching { JSONArray(Fs.readText(file).ifEmpty { "[]" }) }.getOrDefault(JSONArray())
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            InstallProfile(
                id = o.getString("id"),
                name = o.getString("name"),
                mcVersion = o.getString("mcVersion"),
                loader = runCatching { Loader.valueOf(o.optString("loader", "VANILLA")) }.getOrDefault(Loader.VANILLA),
                loaderVersion = o.optString("loaderVersion").ifEmpty { null },
                gameDirName = o.optString("gameDirName", "default"),
                iconKey = o.optString("iconKey", "grass"),
                lastPlayed = o.optLong("lastPlayed"),
                totalPlaySeconds = o.optLong("totalPlaySeconds"),
                created = o.optLong("created"),
            )
        }
    }

    fun save(profiles: List<InstallProfile>) {
        val arr = JSONArray()
        profiles.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("mcVersion", p.mcVersion)
                    .put("loader", p.loader.name)
                    .put("loaderVersion", p.loaderVersion ?: "")
                    .put("gameDirName", p.gameDirName)
                    .put("iconKey", p.iconKey)
                    .put("lastPlayed", p.lastPlayed)
                    .put("totalPlaySeconds", p.totalPlaySeconds)
                    .put("created", p.created),
            )
        }
        Fs.writeText(file, arr.toString())
    }

    fun upsert(profile: InstallProfile) {
        val list = all().filterNot { it.id == profile.id } + profile
        save(list.sortedByDescending { it.lastPlayed })
    }

    fun delete(id: String) = save(all().filterNot { it.id == id })

    fun byId(id: String): InstallProfile? = all().firstOrNull { it.id == id }

    fun markPlayed(id: String, seconds: Long) {
        val p = byId(id) ?: return
        upsert(p.copy(lastPlayed = System.currentTimeMillis(), totalPlaySeconds = p.totalPlaySeconds + seconds))
    }

    fun defaults(): List<InstallProfile> = all().ifEmpty {
        listOf(
            InstallProfile(
                id = "vanilla-latest",
                name = "Latest release",
                mcVersion = "latest-release",
                loader = Loader.VANILLA,
            ),
        ).also { save(it) }
    }
}

/** Minecraft news feed assembled from Mojang's public patch-note pages. */
class NewsProvider {
    data class NewsItem(val title: String, val url: String, val summary: String, val date: String)

    /**
     * Patch notes are published as static JSON at piston-meta. When the network is
     * unavailable we fall back to a locally curated list so the screen is never empty.
     */
    suspend fun fetch(): List<NewsItem> = runCatching {
        val raw = com.cplauncher.plus.core.util.Net.text(PATCH_NOTES)
        val json = JSONObject(raw)
        val entries = json.optJSONArray("entries") ?: return@runCatching fallback()
        (0 until entries.length()).take(8).mapNotNull { i ->
            val e = entries.optJSONObject(i) ?: return@mapNotNull null
            NewsItem(
                title = e.optString("title"),
                url = e.optString("url"),
                summary = e.optString("shortText"),
                date = e.optString("version").ifEmpty { e.optString("date") },
            )
        }
    }.getOrDefault(fallback())

    private fun fallback(): List<NewsItem> = listOf(
        NewsItem(
            "Minecraft patch notes",
            "https://www.minecraft.net/en-us/article",
            "Latest Java Edition changes are published by Mojang at minecraft.net. Open the link for the full list.",
            "live",
        ),
        NewsItem(
            "CP Launcher Plus",
            "https://github.com/ps9287219-droid/CP-LAUNCHER-PLUS",
            "Source, build instructions and release APKs are published on GitHub.",
            "now",
        ),
    )

    companion object {
        const val PATCH_NOTES = "https://launchercontent.mojang.com/v2/javaPatchNotes.json"
    }
}

/** Convenience: version list + type filtering used by the library screen. */
class VersionCatalog(private val manifest: com.cplauncher.plus.core.versions.VersionManifest) {
    suspend fun releases(): List<McVersion> = manifest.refresh(false).filter { it.type == "release" }
    suspend fun snapshots(): List<McVersion> = manifest.refresh(false).filter { it.type == "snapshot" }
    suspend fun legacy(): List<McVersion> = manifest.refresh(false).filter { it.type in setOf("old_beta", "old_alpha") }
}
