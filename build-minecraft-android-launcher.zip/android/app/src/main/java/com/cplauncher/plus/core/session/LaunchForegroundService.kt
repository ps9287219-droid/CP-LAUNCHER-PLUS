package com.cplauncher.plus.core.session

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.cplauncher.plus.R
import com.cplauncher.plus.core.launch.SessionEventBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Counts real playtime while the game process is alive and keeps the process alive
 * with a foreground notification (required for long background work on Android 12+).
 */
class LaunchForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var seconds = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1001, buildNotification("Minecraft session started"))
        scope.launch {
            while (isActive) {
                delay(1000)
                seconds++
                PlayTimeTracker(applicationContext).tick(seconds)
            }
        }
        val sub = SessionEventBus.subscribe { line ->
            if (line.contains("Setting user:") || line.contains("Backend library: LWJGL")) {
                updateNotification("In game")
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Game sessions", NotificationManager.IMPORTANCE_LOW),
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("CP Launcher Plus")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1001, buildNotification(text))
    }

    companion object {
        const val CHANNEL_ID = "cp_game_session"

        fun start(context: Context) {
            context.startForegroundService(Intent(context, LaunchForegroundService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, LaunchForegroundService::class.java))
        }
    }
}

/** Durable playtime bookkeeping (per profile + global totals). */
class PlayTimeTracker(private val context: Context) {

    data class Session(val version: String, val loader: String, val startedAt: Long)

    @Volatile
    private var current: Session? = null

    @Volatile
    private var liveSeconds = 0L

    fun beginSession(version: String, loader: String) {
        current = Session(version, loader, System.currentTimeMillis())
        liveSeconds = 0
        LaunchForegroundService.start(context)
    }

    fun tick(seconds: Long) {
        liveSeconds = seconds
    }

    fun endSession(seconds: Long) {
        val session = current ?: return
        LaunchForegroundService.stop(context)
        val total = seconds.takeIf { it > 0 } ?: liveSeconds
        HistoryStore(context).append(session, total)
        current = null
    }

    fun liveSeconds(): Long = liveSeconds
}
