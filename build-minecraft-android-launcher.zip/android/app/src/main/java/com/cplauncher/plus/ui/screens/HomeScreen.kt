package com.cplauncher.plus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.cplauncher.plus.LauncherViewModel
import com.cplauncher.plus.data.model.Account
import com.cplauncher.plus.data.model.LaunchStage
import com.cplauncher.plus.ui.common.CpCard
import com.cplauncher.plus.ui.common.GlowBacking
import com.cplauncher.plus.ui.common.ProgressBar
import com.cplauncher.plus.ui.common.SectionTitle
import com.cplauncher.plus.ui.common.StatusPill
import com.cplauncher.plus.ui.common.formatDuration

@Composable
fun HomeScreen(vm: LauncherViewModel, onOpenLibrary: () -> Unit = {}) {
    val settings by vm.settings.collectAsState()
    val state by vm.launchState.collectAsState()
    val accounts by vm.accountsList.collectAsState()
    val news by vm.news.collectAsState()
    val caps by vm.capabilities.collectAsState()
    val history by vm.playtime7.collectAsState()
    val accent = MaterialTheme.colorScheme.primary
    val profile = vm.allProfiles().firstOrNull { it.id == settings.activeProfileId } ?: vm.allProfiles().firstOrNull()
    val account = accounts.firstOrNull { it.active } ?: accounts.firstOrNull()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        // ---------------- header ----------------
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CP LAUNCHER PLUS", style = MaterialTheme.typography.headlineMedium, color = accent)
                Text("Minecraft: Java Edition for Android", style = MaterialTheme.typography.bodySmall)
            }
            StatusPill(
                text = when {
                    state.isRunning -> "IN GAME"
                    state.isLaunching -> state.stage.name
                    else -> "READY"
                },
            )
        }
        Spacer(Modifier.height(16.dp))

        // ---------------- PLAY ----------------
        CpCard {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Box(contentAlignment = Alignment.Center) {
                    GlowBacking(220, accent)
                    Button(
                        onClick = { vm.play() },
                        enabled = !state.isLaunching,
                        shape = RoundedCornerShape(28.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = accent),
                        modifier = Modifier.size(180.dp),
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("PLAY", fontSize = 34.sp, fontWeight = FontWeight.Black)
                            Text(
                                profile?.let { "${it.loader.name} ${it.mcVersion}" } ?: "No profile",
                                fontSize = 12.sp,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (state.stage != LaunchStage.IDLE) {
                    ProgressBar(state.label, state.progressCurrent, state.progressTotal, state.indeterminate)
                    state.preFlightProblems.forEach { Text("• $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
                state.lastError?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onOpenLibrary) { Text("Change version") }
                    OutlinedButton(onClick = { /* open logs */ }) { Text("Live log") }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // ---------------- profile ----------------
        CpCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(56.dp).clip(CircleShape).background(accent.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center,
                ) {
                    val skin = (account as? Account.Microsoft)?.skinUrl
                    if (skin != null) AsyncImage(model = skin, contentDescription = null)
                    else Text((account?.name ?: "P").take(1).uppercase(), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(account?.name ?: "No account", style = MaterialTheme.typography.titleLarge)
                    Text(
                        when (account) {
                            is Account.Microsoft -> if ((account as Account.Microsoft).ownsGame) "Microsoft · Java Edition verified" else "Microsoft · no Java entitlement found"
                            is Account.Offline -> "Local profile (offline)"
                            else -> "Sign in to use your Minecraft account"
                        },
                        style = MaterialTheme.typography.bodySmall,
                    )
                    (account as? Account.Microsoft)?.uuid?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                }
                StatusPill(
                    when (account) {
                        is Account.Microsoft -> "MSA"
                        is Account.Offline -> "LOCAL"
                        else -> "NONE"
                    },
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        SectionTitle("Session statistics")
        CpCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Stat("Total play", formatDuration(history.sumOf { it.second }))
                Stat("7 days", formatDuration(history.takeLast(7).sumOf { it.second }))
                Stat("Sessions", history.count { it.second > 0 }.toString())
                Stat("RAM", "${caps?.javaHeapMb ?: 0} MB heap")
            }
        }

        Spacer(Modifier.height(16.dp))
        SectionTitle("News")
        news.forEach { item ->
            CpCard(Modifier.padding(vertical = 4.dp)) {
                Text(item.title, style = MaterialTheme.typography.titleMedium)
                Text(item.summary, style = MaterialTheme.typography.bodySmall, maxLines = 2)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column {
        Text(value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}
