package com.cplauncher.plus.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cplauncher.plus.LauncherViewModel
import com.cplauncher.plus.data.model.Account
import com.cplauncher.plus.ui.common.CpCard
import com.cplauncher.plus.ui.common.SectionTitle
import com.cplauncher.plus.ui.common.StatusPill

@Composable
fun AccountsScreen(vm: LauncherViewModel) {
    val accounts by vm.accountsList.collectAsState()
    var userCode by remember { mutableStateOf<String?>(null) }
    var verifyUrl by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var localName by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        SectionTitle("Accounts")

        CpCard {
            Text("Microsoft account", style = MaterialTheme.typography.titleMedium)
            Text(
                "Uses Microsoft's official device-code flow: you enter a short code at microsoft.com/link in any browser. " +
                    "CP Launcher Plus never asks for, sees, or stores your password. Entitlement to Java Edition is checked " +
                    "against the Minecraft Services entitlements endpoint.",
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                message = null
                vm.startMicrosoftSignIn(
                    onCode = { code, url -> userCode = code; verifyUrl = url },
                    onDone = { result ->
                        result.onSuccess { message = "Signed in as ${it.name}" }
                            .onFailure { message = "Sign-in failed: ${it.message}" }
                    },
                )
            }) { Text("Sign in with Microsoft") }

            userCode?.let { code ->
                Spacer(Modifier.height(8.dp))
                Text("Your code: $code", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                Text("Open $verifyUrl and enter the code above.", style = MaterialTheme.typography.bodySmall)
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("Saved accounts")
        accounts.forEach { a ->
            CpCard(Modifier.padding(vertical = 4.dp)) {
                Row {
                    Column(Modifier.weight(1f)) {
                        Text(a.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            when (a) {
                                is Account.Microsoft -> if (a.ownsGame) "Microsoft · Java Edition owned" else "Microsoft · no Java entitlement"
                                is Account.Offline -> "Local profile (offline)"
                            },
                            style = MaterialTheme.typography.bodySmall,
                        )
                        when (a) {
                            is Account.Microsoft -> Text(a.uuid, style = MaterialTheme.typography.bodySmall)
                            is Account.Offline -> Text(a.derivedUuid, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Column {
                        if (a.active) StatusPill("ACTIVE")
                        else Button(onClick = { vm.switchAccount(a.id) }) { Text("Switch") }
                        OutlinedButton(onClick = { vm.removeAccount(a.id) }) { Text("Remove") }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("Local (offline) profile")
        CpCard {
            Text(
                "A local profile is not a Minecraft account. It derives a UUID from the name the same way the vanilla " +
                    "game does in offline mode. It works for singleplayer and for servers that allow offline names; it " +
                    "cannot join Mojang-authenticated servers.",
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = localName, onValueChange = { localName = it.take(16) }, label = { Text("Player name") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedButton(enabled = localName.length >= 3, onClick = { vm.addLocalProfile(localName) }) {
                Text("Create local profile")
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
