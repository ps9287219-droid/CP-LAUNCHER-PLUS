package com.cplauncher.plus.core.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Single shared HTTP client for every network subsystem
 * (Mojang piston-meta, Microsoft auth, Modrinth, runtime downloads).
 */
object Net {
    @Volatile
    var downloadPause: Boolean = false

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    /** Client used for large artefacts: long timeouts, no retries storming. */
    val bigClient: OkHttpClient = client.newBuilder()
        .readTimeout(5, TimeUnit.MINUTES)
        .build()

    suspend fun text(url: String): String = withContext(Dispatchers.IO) {
        client.newCall(Request.Builder().url(url).build()).await().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code} for $url")
            resp.body?.string() ?: ""
        }
    }

    suspend fun json(url: String): JSONObject = withContext(Dispatchers.IO) {
        val body = text(url)
        // Modrinth returns valid JSON; Mojang returns valid JSON; both are safe here.
        JSONObject(body)
    }

    suspend fun postJson(url: String, body: JSONObject, headers: Map<String, String> = emptyMap()): String =
        withContext(Dispatchers.IO) {
            val b = Request.Builder()
                .url(url)
                .post(body.toString().toRequestBody("application/json".toMediaType()))
            headers.forEach { (k, v) -> b.header(k, v) }
            client.newCall(b.build()).await().use { resp ->
                resp.body?.string() ?: ""
            }
        }

    suspend fun postForm(url: String, form: Map<String, String>): String = withContext(Dispatchers.IO) {
        val fb = okhttp3.FormBody.Builder()
        form.forEach { (k, v) -> fb.add(k, v) }
        client.newCall(Request.Builder().url(url).post(fb.build()).build()).await().use { resp ->
            resp.body?.string() ?: ""
        }
    }

    /**
     * Streamed download with progress callback. Downloads are resumable by re-running:
     * partial files are written to `.part` and moved on completion.
     */
    fun downloadToFile(
        url: String,
        target: File,
        onProgress: (bytesRead: Long, total: Long) -> Unit = { _, _ -> },
    ): File {
        target.parentFile?.mkdirs()
        val part = File(target.parentFile, target.name + ".part")
        val request = Request.Builder().url(url).build()
        bigClient.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code} downloading $url")
            val body = resp.body ?: throw IOException("Empty body for $url")
            val total = body.contentLength()
            body.byteStream().use { input ->
                part.outputStream().use { output ->
                    val buf = ByteArray(DEFAULT_BUFFER_SIZE * 8)
                    var read: Int
                    var seen = 0L
                    while (input.read(buf).also { read = it } != -1) {
                        while (Net.downloadPause) Thread.sleep(200)
                        output.write(buf, 0, read)
                        seen += read
                        onProgress(seen, total)
                    }
                }
            }
        }
        if (!part.renameTo(target)) {
            part.copyTo(target, overwrite = true)
            part.delete()
        }
        return target
    }

    private suspend fun Call.await(): Response = withContext(Dispatchers.IO) { execute() }
}

class HttpException(val code: Int, message: String) : IOException(message)
