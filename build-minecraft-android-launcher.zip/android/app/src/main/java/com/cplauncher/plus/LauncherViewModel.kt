package com.cplauncher.plus

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.cplauncher.plus.core.accounts.AccountStore
import com.cplauncher.plus.core.accounts.MicrosoftAuth
import com.cplauncher.plus.core.discord.DiscordPresence
import com.cplauncher.plus.core.launch.GameLauncher
import com.cplauncher.plus.core.mods.ModManager
import com.cplauncher.plus.core.packs.PackageManager
import com.cplauncher.plus.core.perf.DeviceCapabilities
import com.cplauncher.plus.core.perf.DeviceProfile
import com.cplauncher.plus.core.perf.PerformanceProfiles
import com.cplauncher.plus.core.runtime.JreManager
import com.cplauncher.plus.core.session.HistoryStore
import com.cplauncher.plus.core.settings.LauncherSettings
import com.cplauncher.plus.core.settings.SettingsRepository
import com.cplauncher.plus.core.versions.VersionManifest
import com.cplauncher.plus.data.NewsProvider
import com.cplauncher.plus.data.ProfileRepository
import com.cplauncher.plus.data.model.Account
import com.cplauncher.plus.data.model.InstallProfile
import com.cplauncher.plus.data.model.LaunchStage
import com.cplauncher.plus.data.model.Loader
import com.cplauncher.plus.data.model.McVersion
import com.cplauncher.plus.data.model.PackEntry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class LauncherViewModel(
    private val app: CPLauncherApp,
) : ViewModel() {

    private val settingsRepo = app.settingsRepo
    private val accounts = app.accountStore
    private val jre = app.jreManager
    private val profiles = ProfileRepository(app)
    private val manifest = VersionManifest(app)
    private val history = HistoryStore(app)
    private val discord = DiscordPresence(app)

    val settings: StateFlow<LauncherSettings> = settingsRepo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, LauncherSettings())
    val launchState = app.launcher.state
    val capabilities = MutableStateFlow<DeviceCapabilities?>(null)
    val versions = MutableStateFlow<List<McVersion>>(emptyList())
    val accountsList = MutableStateFlow<List<Account>>(emptyList())
    val news = MutableStateFlow<List<NewsProvider.NewsItem>>(emptyList())
    val playtime7 = MutableStateFlow<List<Pair<String, Long>>>(emptyList())
    val deviceLog = MutableStateFlow<List<String>>(emptyList())

    init {
        viewModelScope.launch { capabilities.value = DeviceProfile.read(app) }
        viewModelScope.launch { versions.value = runCatching { manifest.refresh(true) }.getOrDefault(emptyList()) }
        viewModelScope.launch { news.value = runCatching { NewsProvider().fetch() }.getOrDefault(emptyList()) }
        viewModelScope.launch { refreshAccounts() }
        viewModelScope.launch { playtime7.value = history.last7Days() }
        viewModelScope.launch {
            settingsRepo.settings.collect { deviceLog.value = listOf("settings refreshed", it.performanceProfile) }
        }
    }

    fun setSettings(block: (LauncherSettings) -> LauncherSettings) = viewModelScope.launch {
        settingsRepo.update(block)
    }

    fun applyPerformanceProfile(id: String) = setSettings { s -> PerformanceProfiles.applyTo(s, PerformanceProfiles.byId(id)) }

    // ------------------------------------------------------------------ accounts

    fun refreshAccounts() {
        val list = accounts.loadMicrosoftAccounts().map { e ->
            Account.Microsoft(
                id = e.id,
                name = e.mcName,
                uuid = e.uuid,
                skinUrl = e.skinUrl,
                capeUrl = e.capeUrl,
                ownsGame = e.ownsGame,
                lastRefresh = e.lastRefresh,
                active = accounts.activeAccountId() == e.id,
            )
        }
        val locals = accounts.localProfiles().map { (name, uuid) ->
            Account.Offline(uuid, name, uuid, active = accounts.activeAccountId() == uuid && list.isEmpty())
        }
        accountsList.value = list + locals
    }

    fun startMicrosoftSignIn(onCode: (String, String) -> Unit, onDone: (Result<Account.Microsoft>) -> Unit) {
        viewModelScope.launch {
            runCatching {
                val auth = MicrosoftAuth(BuildConfig.MS_CLIENT_ID)
                val start = auth.startDeviceCode()
                onCode(start.userCode, start.verificationUri)
                val token = auth.pollDeviceCode(start) { }
                val result = auth.completeChain(
                    msAccessToken = token.getString("access_token"),
                    msRefreshToken = token.getString("refresh_token"),
                    expiresInSec = token.optLong("expires_in", 3600),
                )
                val entry = com.cplauncher.plus.core.accounts.AccountStoreEntry(
                    id = result.mcUuid,
                    mcName = result.mcName,
                    uuid = result.mcUuid,
                    skinUrl = result.skinUrl,
                    capeUrl = result.capeUrl,
                    ownsGame = result.ownsGame,
                    accessToken = result.mcAccessToken,
                    refreshToken = result.msRefreshToken,
                    expiresAt = result.expiresAtMs,
                    lastRefresh = System.currentTimeMillis(),
                )
                accounts.saveMicrosoftAccount(entry)
                accounts.setActiveAccount(entry.id)
                refreshAccounts()
                result
            }.onSuccess { r ->
                onDone(
                    Result.success(
                        Account.Microsoft(r.mcUuid, r.mcName, r.mcUuid, r.skinUrl, r.capeUrl, r.ownsGame, System.currentTimeMillis(), true),
                    ),
                )
            }.onFailure { onDone(Result.failure(it)) }
        }
    }

    fun switchAccount(id: String) {
        accounts.setActiveAccount(id)
        refreshAccounts()
    }

    fun removeAccount(id: String) {
        accounts.deleteAccount(id)
        refreshAccounts()
    }

    fun addLocalProfile(name: String) {
        accounts.saveLocalProfile(name, MicrosoftAuth.offlineUuid(name))
        accounts.setActiveAccount(MicrosoftAuth.offlineUuid(name))
        refreshAccounts()
    }

    // ------------------------------------------------------------------ launching

    fun play() {
        val s = settings.value
        val profile = profiles.byId(s.activeProfileId) ?: profiles.defaults().first()
        val account = accountsList.value.firstOrNull { it.active } ?: Account.Offline("local", "Player", MicrosoftAuth.offlineUuid("Player"), true)
        viewModelScope.launch {
            val loaderJson = if (profile.loader == Loader.VANILLA) null else runCatching {
                val file = File(
                    com.cplauncher.plus.core.util.Fs.gameRoot(app, profile.gameDirName),
                    "versions/${profile.loader.name.lowercase()}-${profile.mcVersion}/${profile.loader.name.lowercase()}-${profile.mcVersion}.json",
                )
                org.json.JSONObject(file.readText())
            }.getOrNull()
            app.launcher.launch(
                mcVersionId = profile.mcVersion,
                loader = profile.loader,
                loaderVersion = profile.loaderVersion,
                resolvedLoaderJson = loaderJson,
                account = account,
                offlineUuid = MicrosoftAuth.offlineUuid(account.name),
            )
        }
    }

    fun createProfile(name: String, mcVersion: String, loader: Loader, loaderVersion: String?) {
        val id = "${loader.name.lowercase()}-$mcVersion-${System.currentTimeMillis()}"
        profiles.upsert(InstallProfile(id = id, name = name, mcVersion = mcVersion, loader = loader, loaderVersion = loaderVersion))
        setSettings { it.copy(activeProfileId = id) }
    }

    fun deleteProfile(id: String) {
        profiles.delete(id)
        setSettings { it.copy(activeProfileId = profiles.all().firstOrNull()?.id ?: "vanilla-latest") }
    }

    fun allProfiles(): List<InstallProfile> = profiles.all()

    // ------------------------------------------------------------------ mods & packs

    fun mods(): List<File> = ModManager(app).list()

    fun modAudit(): List<String> = ModManager(app).audit()

    fun packs(kind: PackEntry.Kind): List<PackEntry> = PackageManager(app).list(kind)

    fun shaderSupport(modIds: Set<String>): PackageManager.ShaderSupport =
        PackageManager(app).shaderSupportState(settings.value, modIds)

    // ------------------------------------------------------------------ runtime

    fun installRuntime(id: String, onProgress: (String, Long, Long) -> Unit) = viewModelScope.launch {
        val spec = jre.catalogue().firstOrNull { it.id == id } ?: return@launch
        runCatching { jre.downloadAndExtract(spec, onProgress) }
            .onFailure { onProgress("Failed: ${it.message}", 0, 1) }
    }

    fun runtimes() = jre.catalogue()

    fun installedRuntimes() = jre.installedIds()

    fun requiredJava(mcVersion: String) = jre.requiredJavaMajor(mcVersion)

    fun historyStore() = history

    fun discordPresence() = discord
}

class LauncherViewModelFactory(private val app: CPLauncherApp) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = LauncherViewModel(app) as T
}
