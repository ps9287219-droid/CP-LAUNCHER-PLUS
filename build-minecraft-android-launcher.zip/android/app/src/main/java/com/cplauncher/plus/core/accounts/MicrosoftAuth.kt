package com.cplauncher.plus.core.accounts

import com.cplauncher.plus.core.util.Net
import org.json.JSONObject
import java.util.UUID

/**
 * Official Microsoft authentication chain used by every legitimate launcher:
 *
 *  1. Microsoft Entra ID device-code flow (user proves identity in a browser).
 *  2. Xbox Live (XBL) user token.
 *  3. XSTS token (Xbox Security Token).
 *  4. Minecraft Services login_with_xbox -> Minecraft access token.
 *  5. minecraft/profile -> username + UUID + skin + cape.
 *  6. entitlements/mcstore -> verifies the user actually owns Java Edition.
 *
 * This class NEVER handles a password. Device codes are exchanged by the user in a
 * browser on any device, so the launcher only ever receives OAuth tokens.
 *
 * Configure your own Azure "Public client/native (mobile & desktop)" application and
 * put its client id in BuildConfig.MS_CLIENT_ID (see app/build.gradle.kts).
 */
class MicrosoftAuth(private val clientId: String) {

    data class DeviceCodeStart(val deviceCode: String, val userCode: String, val verificationUri: String, val intervalSec: Int, val expiresSec: Int)

    data class AuthResult(
        val mcAccessToken: String,
        val mcUuid: String,
        val mcName: String,
        val skinUrl: String?,
        val capeUrl: String?,
        val ownsGame: Boolean,
        val msRefreshToken: String,
        val expiresAtMs: Long,
    )

    // ---------------------------------------------------------------- device code

    suspend fun startDeviceCode(): DeviceCodeStart {
        val body = JSONObject()
            .put("client_id", clientId)
            .put("scope", "XboxLive.signin offline_access")
        val raw = Net.postJson(TENANT_DEVICE_CODE, body)
        return DeviceCodeStart(
            deviceCode = raw.getString("device_code"),
            userCode = raw.getString("user_code"),
            verificationUri = raw.getString("verification_uri"),
            intervalSec = raw.optInt("interval", 5),
            expiresSec = raw.optInt("expires_in", 900),
        )
    }

    suspend fun pollDeviceCode(start: DeviceCodeStart, onUserCodeNeeded: (DeviceCodeStart) -> Unit): JSONObject {
        onUserCodeNeeded(start)
        val deadline = System.currentTimeMillis() + start.expiresSec * 1000L
        while (System.currentTimeMillis() < deadline) {
            kotlinx.coroutines.delay(start.intervalSec * 1000L)
            val body = JSONObject()
                .put("client_id", clientId)
                .put("grant_type", "urn:ietf:params:oauth:grant-type:device_code")
                .put("device_code", start.deviceCode)
            val raw = Net.postJson(TOKEN_ENDPOINT, body)
            val error = raw.optString("error")
            when {
                error.isEmpty() -> return raw
                error == "authorization_pending" -> continue
                error == "slow_down" -> kotlinx.coroutines.delay(3000)
                else -> throw IllegalStateException("Microsoft sign-in failed: $error")
            }
        }
        throw IllegalStateException("Sign-in timed out. Please try again.")
    }

    /** Refresh an existing Microsoft session without user interaction. */
    suspend fun refresh(refreshToken: String): JSONObject {
        val raw = Net.postJson(
            TOKEN_ENDPOINT,
            JSONObject()
                .put("client_id", clientId)
                .put("grant_type", "refresh_token")
                .put("refresh_token", refreshToken),
        )
        if (raw.has("error")) throw IllegalStateException("Token refresh rejected: " + raw.optString("error"))
        return raw
    }

    // ---------------------------------------------------------------- XBL / XSTS

    private suspend fun xblToken(msAccessToken: String): Pair<String, String> {
        val body = JSONObject().put(
            "Properties",
            JSONObject().put("AuthMethod", "RPS").put("SiteName", "user.auth.xboxlive.com")
                .put("RpsTicket", "d=$msAccessToken"),
        ).put("RelyingParty", "http://auth.xboxlive.com").put("TokenType", "JWT")

        val raw = Net.postJson("https://user.auth.xboxlive.com/user/authenticate", body)
        val token = raw.getString("Token")
        val uhs = raw.getJSONObject("DisplayClaims").getJSONArray("xui").getJSONObject(0).getString("uhs")
        return token to uhs
    }

    private suspend fun xstsToken(xblToken: String): Pair<String, String> {
        val body = JSONObject().put(
            "Properties",
            JSONObject().put("SandboxId", "RETAIL")
                .put("UserTokens", org.json.JSONArray().put(xblToken)),
        ).put("RelyingParty", "rp://api.minecraftservices.com/").put("TokenType", "JWT")
        val raw = Net.postJson("https://xsts.auth.xboxlive.com/xsts/authorize", body)
        val token = raw.getString("Token")
        val uhs = raw.getJSONObject("DisplayClaims").getJSONArray("xui").getJSONObject(0).getString("uhs")
        return token to uhs
    }

    // ---------------------------------------------------------------- Minecraft services

    private suspend fun minecraftToken(xsts: String, uhs: String): String {
        val raw = Net.postJson(
            "https://api.minecraftservices.com/authentication/login_with_xbox",
            JSONObject().put("identityToken", "XBL3.0 x=$uhs;$xsts"),
        )
        return raw.getString("access_token")
    }

    suspend fun fetchProfile(mcToken: String): JSONObject =
        JSONObject(Net.text("https://api.minecraftservices.com/minecraft/profile"))

    suspend fun checkEntitlements(mcToken: String): Boolean = runCatching {
        val raw = JSONObject(
            Net.text("https://api.minecraftservices.com/entitlements/mcstore"),
        )
        val items = raw.optJSONArray("items") ?: return@runCatching false
        (0 until items.length()).any { i ->
            items.getJSONObject(i).optString("name") in setOf("product_minecraft", "game_minecraft")
        }
    }.getOrDefault(false)

    /** Runs the complete chain end-to-end from a Microsoft OAuth token response. */
    suspend fun completeChain(msAccessToken: String, msRefreshToken: String, expiresInSec: Long): AuthResult {
        val (xbl, _) = xblToken(msAccessToken)
        val (xsts, uhs) = xstsToken(xbl)
        val mc = minecraftToken(xsts, uhs)
        val profile = fetchProfile(mc)
        val owns = checkEntitlements(mc)

        val id = profile.optString("id")           // unsigned UUID (no dashes)
        val dashed = if (id.length == 32) dashedUuid(id) else id
        val skins = profile.optJSONArray("skins")
        var skin: String? = null
        var cape: String? = null
        skins?.let {
            (0 until it.length()).forEach { i ->
                val s = it.getJSONObject(i)
                if (s.optString("state") == "ACTIVE" && s.optString("alias") == "Standard") skin = s.optString("url")
            }
        }
        profile.optJSONArray("capes")?.let { capes ->
            if (capes.length() > 0) cape = capes.getJSONObject(0).optString("url")
        }

        return AuthResult(
            mcAccessToken = mc,
            mcUuid = dashed,
            mcName = profile.optString("name"),
            skinUrl = skin,
            capeUrl = cape,
            ownsGame = owns,
            msRefreshToken = msRefreshToken,
            expiresAtMs = System.currentTimeMillis() + expiresInSec * 1000L,
        )
    }

    companion object {
        const val TENANT_DEVICE_CODE =
            "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode"
        const val TOKEN_ENDPOINT = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token"

        /** Offline-mode UUID derivation (sha1 of "OfflinePlayer:<name>"), same as vanilla. */
        fun offlineUuid(name: String): String {
            val digest = java.security.MessageDigest.getInstance("MD5")
                .digest("OfflinePlayer:$name".toByteArray(Charsets.UTF_8))
            val bytes = digest.copyOf(16)
            bytes[6] = ((bytes[6].toInt() and 0x0F) or 0x30).toByte()
            bytes[8] = ((bytes[8].toInt() and 0x3F) or 0x80).toByte()
            val bb = java.nio.ByteBuffer.wrap(bytes)
            return UUID(bb.long, bb.long).toString()
        }

        fun dashedUuid(compact: String): String =
            UUID.fromString(
                compact.replaceFirst(
                    "(\\p{XDigit}{8})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}+)".toRegex(),
                    "$1-$2-$3-$4-$5",
                ),
            ).toString()
    }
}
