package com.cplauncher.plus.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cplauncher.plus.LauncherViewModel
import com.cplauncher.plus.data.model.Loader
import com.cplauncher.plus.ui.common.CpCard
import com.cplauncher.plus.ui.common.SectionTitle
import com.cplauncher.plus.ui.common.StatusPill
import kotlinx.coroutines.launch

@Composable
fun LibraryScreen(vm: LauncherViewModel) {
    val versions by vm.versions.collectAsState()
    val settings by vm.settings.collectAsState()
    val state by vm.launchState.collectAsState()
    var query by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("release") }
    var loader by remember { mutableStateOf(Loader.VANILLA) }
    var loaderVersions by remember { mutableStateOf<List<String>>(emptyList()) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        SectionTitle("Installations")
        val profiles = vm.allProfiles()
        profiles.forEach { p ->
            CpCard(Modifier.padding(vertical = 4.dp)) {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, style = MaterialTheme.typography.titleMedium)
                        Text("${p.loader.displayName} · ${p.mcVersion}", style = MaterialTheme.typography.bodySmall)
                        if (p.totalPlaySeconds > 0) Text("Played ${p.totalPlaySeconds / 60} min", style = MaterialTheme.typography.bodySmall)
                    }
                    if (p.id == settings.activeProfileId) StatusPill("ACTIVE")
                    else AssistChip(onClick = { vm.setSettings { it.copy(activeProfileId = p.id) } }, label = { Text("Use") })
                    AssistChip(onClick = { vm.deleteProfile(p.id) }, label = { Text("✕") })
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("Create installation")
        CpCard {
            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search versions") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("release" to "Releases", "snapshot" to "Snapshots", "old_beta" to "Beta").forEach { (id, label) ->
                    FilterChip(selected = type == id, onClick = { type = id }, label = { Text(label) })
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Loader.entries.forEach { l ->
                    FilterChip(
                        selected = loader == l,
                        onClick = {
                            loader = l
                            scope.launch {
                                loaderVersions = runCatching {
                                    when (l) {
                                        Loader.FABRIC -> com.cplauncher.plus.core.mods.LoaderInstaller(vm.run { com.cplauncher.plus.CPLauncherApp.instance }).fabricLoaderVersions().take(12)
                                        else -> emptyList()
                                    }
                                }.getOrDefault(emptyList())
                            }
                        },
                        label = { Text(l.displayName) },
                    )
                }
            }
            if (loaderVersions.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text("Loader: ${loaderVersions.first()}", style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(8.dp))

            val filtered = versions.filter { it.type == type && it.id.contains(query, ignoreCase = true) }.take(40)
            LazyColumn(Modifier.fillMaxWidth().height(260.dp)) {
                items(filtered) { v ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text(v.id, style = MaterialTheme.typography.bodyMedium)
                            Text(v.releaseTime.take(10), style = MaterialTheme.typography.bodySmall)
                        }
                        Button(onClick = {
                            vm.createProfile(
                                name = "${loader.displayName} $v",
                                mcVersion = v.id,
                                loader = loader,
                                loaderVersion = loaderVersions.firstOrNull(),
                            )
                        }) { Text("Install") }
                    }
                }
            }
            if (state.stage != com.cplauncher.plus.data.model.LaunchStage.IDLE) {
                Spacer(Modifier.height(8.dp))
                com.cplauncher.plus.ui.common.ProgressBar(state.label, state.progressCurrent, state.progressTotal, state.indeterminate)
            }
        }
    }
}
