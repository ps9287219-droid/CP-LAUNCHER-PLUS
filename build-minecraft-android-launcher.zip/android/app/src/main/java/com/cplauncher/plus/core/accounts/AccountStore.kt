package com.cplauncher.plus.core.accounts

import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/**
 * Token storage backed by EncryptedSharedPreferences (AES-256 GCM, hardware keystore).
 *
 * SECURITY NOTE: only OAuth refresh/access tokens are stored. Passwords are never
 * requested, seen, or persisted by this launcher.
 */
class AccountStore(context: Context) {

    private val prefs by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "cp_launcher_accounts",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    fun saveMicrosoftAccount(account: AccountStoreEntry) {
        prefs.edit()
            .putString("acct_" + account.id, account.toJson().toString())
            .apply()
    }

    fun loadMicrosoftAccounts(): List<AccountStoreEntry> {
        val all = prefs.all ?: return emptyList()
        return all.entries
            .filter { it.key.startsWith("acct_") }
            .mapNotNull {
                runCatching { AccountStoreEntry.fromJson(JSONObject(it.value.toString())) }.getOrNull()
            }
            .sortedByDescending { it.lastRefresh }
    }

    fun deleteAccount(id: String) {
        prefs.edit().remove("acct_$id").apply()
    }

    fun setActiveAccount(id: String) {
        prefs.edit().putString("active_account", id).apply()
    }

    fun activeAccountId(): String? = prefs.getString("active_account", null)

    fun tokensFor(id: String): Tokens? {
        val raw = prefs.getString("acct_$id", null) ?: return null
        return runCatching { Tokens.from(JSONObject(raw)) }.getOrNull()
    }

    fun saveLocalProfile(name: String, derivedUuid: String) {
        val arr = JSONArray(prefs.getString("local_profiles", "[]"))
        val obj = JSONObject().put("name", name).put("uuid", derivedUuid).put("created", System.currentTimeMillis())
        arr.put(obj)
        prefs.edit().putString("local_profiles", arr.toString()).apply()
    }

    fun localProfiles(): List<Pair<String, String>> {
        val arr = runCatching { JSONArray(prefs.getString("local_profiles", "[]")) }.getOrDefault(JSONArray())
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            o.optString("name") to o.optString("uuid")
        }
    }
}

data class Tokens(val accessToken: String, val refreshToken: String, val expiresAt: Long)

data class AccountStoreEntry(
    val id: String,
    val mcName: String,
    val uuid: String,
    val skinUrl: String?,
    val capeUrl: String?,
    val ownsGame: Boolean,
    val accessToken: String,
    val refreshToken: String,
    val expiresAt: Long,
    val lastRefresh: Long,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", mcName)
        .put("uuid", uuid)
        .put("skin", skinUrl ?: "")
        .put("cape", capeUrl ?: "")
        .put("owns", ownsGame)
        .put("expiresAt", expiresAt)
        .put("lastRefresh", lastRefresh)
        .put("at", Base64.encodeToString(accessToken.toByteArray(), Base64.NO_WRAP))
        .put("rt", Base64.encodeToString(refreshToken.toByteArray(), Base64.NO_WRAP))

    companion object {
        fun fromJson(o: JSONObject): AccountStoreEntry = AccountStoreEntry(
            id = o.getString("id"),
            mcName = o.getString("name"),
            uuid = o.getString("uuid"),
            skinUrl = o.optString("skin").ifEmpty { null },
            capeUrl = o.optString("cape").ifEmpty { null },
            ownsGame = o.optBoolean("owns", false),
            accessToken = Base64.decode(o.getString("at"), Base64.NO_WRAP).decodeToString(),
            refreshToken = Base64.decode(o.getString("rt"), Base64.NO_WRAP).decodeToString(),
            expiresAt = o.getLong("expiresAt"),
            lastRefresh = o.optLong("lastRefresh"),
        )
    }

    fun toTokens(): Tokens = Tokens(accessToken, refreshToken, expiresAt)
}
