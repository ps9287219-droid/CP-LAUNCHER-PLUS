package com.cplauncher.plus.core.runtime

import android.content.Context
import android.os.Build
import com.cplauncher.plus.core.util.Fs
import com.cplauncher.plus.core.util.Net
import java.io.File

/**
 * Manages Android-compatible OpenJDK runtimes.
 *
 * Source: PojavLauncherTeam/android-openjdk-build-multiarch releases.
 *   License: GNU GPLv2 + Classpath exception (OpenJDK) — redistribution permitted,
 *   and these builds are patched for Android (bionic libc, no glibc dependency).
 *   Only aarch64 and x86_64 are usable for Minecraft 1.13+ (1.7 needs Java 8 arm32).
 */
class JreManager(private val context: Context) {

    data class RuntimeSpec(
        val id: String,
        val javaMajor: Int,
        val abi: String,
        val url: String,
        val sha256: String,
        val sizeBytes: Long,
        val minApi: Int,
        val description: String,
    )

    val abi: String =
        when (Build.SUPPORTED_ABIS.firstOrNull()) {
            "arm64-v8a" -> "arm64"
            "x86_64" -> "x86_64"
            "armeabi-v7a" -> "arm32"
            else -> "unknown"
        }

    val supported: Boolean get() = abi == "arm64" || abi == "x86_64"

    /**
     * Catalogue of maintained OpenJDK builds for Android.
     * URLs are overridable from Settings so a mirror or self-hosted build can be used.
     */
    fun catalogue(): List<RuntimeSpec> {
        val base = "https://github.com/PojavLauncherTeam/android-openjdk-build-multiarch/releases/download"
        return listOf(
            RuntimeSpec(
                id = "jre21-$abi", javaMajor = 21, abi = abi,
                url = "$base/jre21-2024-bin/jre21-$abi.tar.xz",
                sha256 = "", sizeBytes = 70_000_000, minApi = 26,
                description = "OpenJDK 21 JRE — required for Minecraft 1.20.5+",
            ),
            RuntimeSpec(
                id = "jre17-$abi", javaMajor = 17, abi = abi,
                url = "$base/jre17-2023-bin/jre17-$abi.tar.xz",
                sha256 = "", sizeBytes = 55_000_000, minApi = 26,
                description = "OpenJDK 17 JRE — Minecraft 1.17 → 1.20.4",
            ),
            RuntimeSpec(
                id = "jre11-$abi", javaMajor = 11, abi = abi,
                url = "$base/jre11-2023-bin/jre11-$abi.tar.xz",
                sha256 = "", sizeBytes = 45_000_000, minApi = 26,
                description = "OpenJDK 11 JRE — Minecraft 1.13 → 1.16.5",
            ),
            RuntimeSpec(
                id = "jre8-$abi", javaMajor = 8, abi = abi,
                url = "$base/jre8-2023-bin/jre8-$abi.tar.xz",
                sha256 = "", sizeBytes = 35_000_000, minApi = 26,
                description = "OpenJDK 8 JRE — Minecraft 1.7.10 → 1.12.2",
            ),
        )
    }

    fun requiredJavaMajor(mcVersion: String): Int {
        val v = mcVersion.substringBefore('-')
        val parts = v.split('.').map { it.toIntOrNull() ?: 0 }
        val major = parts.getOrElse(0) { 1 }
        val minor = parts.getOrElse(1) { 0 }
        val patch = parts.getOrElse(2) { 0 }
        return when {
            major >= 1 && (minor > 20 || (minor == 20 && patch >= 5)) -> 21
            major >= 1 && minor >= 17 -> 17
            major >= 1 && minor >= 13 -> 11
            else -> 8
        }
    }

    fun runtimeFor(javaMajor: Int): RuntimeSpec =
        catalogue().first { it.javaMajor == javaMajor }

    fun isInstalled(spec: RuntimeSpec): Boolean {
        val dir = Fs.runtimeDir(context, spec.id)
        return File(dir, "bin/java").exists() || File(dir, "lib/libjvm.so").exists()
    }

    fun installedIds(): List<String> =
        Fs.baseDir(context).resolve("runtimes").listFiles()?.filter { it.isDirectory }
            ?.filter { File(it, "lib/libjvm.so").exists() || File(it, "bin/java").exists() }
            ?.map { it.name } ?: emptyList()

    suspend fun downloadAndExtract(spec: RuntimeSpec, onProgress: (label: String, read: Long, total: Long) -> Unit) {
        val archive = File(context.cacheDir, "${spec.id}.tar.xz")
        onProgress("Downloading ${spec.id}", 0, spec.sizeBytes)
        Net.downloadToFile(spec.url, archive) { r, t -> onProgress("Downloading ${spec.id}", r, t) }
        onProgress("Extracting ${spec.id}", 0, 0)
        val dest = Fs.runtimeDir(context, spec.id)
        Fs.deleteRecursive(dest)
        Fs.extractTarXz(archive, dest, stripRoot = true)
        // Make the JVM shared objects + binaries executable
        dest.walkBottomUp().filter { it.isFile }.forEach { f ->
            if (f.extension == "so" || f.parentFile.name == "bin") f.setExecutable(true, false)
        }
        archive.delete()
        onProgress("Runtime ready", spec.sizeBytes, spec.sizeBytes)
    }

    fun deleteRuntime(id: String) = Fs.deleteRecursive(Fs.runtimeDir(context, id))

    fun runtimeSize(id: String): Long = Fs.dirSize(Fs.runtimeDir(context, id))

    fun jvmHome(spec: RuntimeSpec): File {
        val root = Fs.runtimeDir(context, spec.id)
        // Some builds extract to a single sub-directory
        val single = root.listFiles()?.singleOrNull { it.isDirectory }
        return if (File(root, "lib/libjvm.so").exists()) root else single ?: root
    }
}
