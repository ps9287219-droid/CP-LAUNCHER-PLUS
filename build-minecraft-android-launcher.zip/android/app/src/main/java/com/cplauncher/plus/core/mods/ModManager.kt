package com.cplauncher.plus.core.mods

import android.content.Context
import com.cplauncher.plus.core.util.Fs
import com.cplauncher.plus.core.util.Net
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.jar.JarFile

/**
 * Real mod management: files land in games/<profile>/mods and are actually loaded by
 * the installed mod loader. Enable/disable works by renaming to `.disabled`, which is
 * the mechanism both Fabric Loader and Forge respect.
 */
class ModManager(private val context: Context, private val profileDir: String = "default") {

    private val modsDir: File get() = Fs.dir(context, Fs.MODS, profileDir)
    private val indexFile: File get() = File(Fs.baseDir(context), "mod-index-$profileDir.json")
    private val api = ModrinthApi()

    fun list(): List<File> = (modsDir.listFiles() ?: emptyArray()).filter { it.isFile && it.extension == "jar" }

    fun disabledNames(): Set<String> {
        return modsDir.listFiles()?.filter { it.name.endsWith(".jar.disabled") }?.map { it.name }?.toSet() ?: emptySet()
    }

    data class Inspection(
        val fileName: String,
        val modId: String?,
        val version: String?,
        val name: String?,
        val mcVersions: List<String>,
        val depends: List<String>,
        val conflicts: List<String>,
    )

    /** Reads fabric.mod.json / mods.toml from a jar to validate compatibility. */
    fun inspect(file: File): Inspection {
        return runCatching {
            JarFile(file).use { jar ->
                val fabric = jar.getJarEntry("fabric.mod.json")
                if (fabric != null) {
                    val json = JSONObject(jar.getInputStream(fabric).bufferedReader().readText())
                    return Inspection(
                        fileName = file.name,
                        modId = json.optString("id"),
                        version = json.optString("version"),
                        name = json.optString("name"),
                        mcVersions = listOf(json.optJSONObject("depends")?.optString("minecraft").orEmpty())
                            .filter { it.isNotBlank() },
                        depends = json.optJSONObject("depends")?.keys()?.asSequence()?.toList()
                            ?.filter { it != "minecraft" && it != "java" } ?: emptyList(),
                        conflicts = json.optJSONObject("conflicts")?.keys()?.asSequence()?.toList() ?: emptyList(),
                    )
                }
                val toml = jar.getJarEntry("META-INF/mods.toml")
                val forge = jar.getJarEntry("META-INF/neoforge.mods.toml") ?: toml
                if (forge != null) {
                    val text = jar.getInputStream(forge).bufferedReader().readText()
                    val modId = Regex("\\bmodId\\s*=\\s*\"([^\"]+)\"").find(text)?.groupValues?.get(1)
                    val display = Regex("\\bdisplayName\\s*=\\s*\"([^\"]+)\"").find(text)?.groupValues?.get(1)
                    val version = Regex("^\\s*version\\s*=\\s*\"([^\"]+)\"", RegexOption.MULTILINE).find(text)?.groupValues?.get(1)
                    val deps = Regex("\\bmodId\\s*=\\s*\"([^\"]+)\"").findAll(text).map { it.groupValues[1] }
                        .filter { it != modId }.toList()
                    return Inspection(file.name, modId, version, display, emptyList(), deps, emptyList())
                }
                Inspection(file.name, null, null, null, emptyList(), emptyList(), emptyList())
            }
        }.getOrElse { Inspection(file.name, null, null, null, emptyList(), emptyList(), emptyList()) }
    }

    /** Detects duplicate mod ids and dependency conflicts across the mods folder. */
    fun audit(): List<String> {
        val problems = mutableListOf<String>()
        val byId = mutableMapOf<String, MutableList<File>>()
        val present = mutableSetOf<String>()
        list().forEach { f ->
            val insp = inspect(f)
            insp.modId?.let { id ->
                byId.getOrPut(id) { mutableListOf() }.add(f)
                present.add(id)
            }
        }
        byId.filterValues { it.size > 1 }.forEach { (id, files) ->
            problems += "Duplicate mod id '$id': " + files.joinToString(", ") { it.name }
        }
        list().forEach { f ->
            val insp = inspect(f)
            insp.depends.forEach { dep ->
                if (dep !in present) problems += "${f.name} requires '$dep' which is not installed"
            }
        }
        return problems
    }

    suspend fun installFromModrinth(ref: ModrinthApi.FileRef, onProgress: (Long, Long) -> Unit): File =
        withContext(Dispatchers.IO) {
            val f = api.download(ref, modsDir, onProgress)
            recordIndex(f, ref)
            f
        }

    fun importLocal(file: File): File {
        val target = File(modsDir, file.name)
        file.copyTo(target, overwrite = true)
        recordIndex(target, null)
        return target
    }

    fun setEnabled(file: File, enabled: Boolean) {
        if (enabled) {
            val target = File(modsDir, file.name.removeSuffix(".disabled"))
            file.renameTo(target)
        } else {
            val target = File(modsDir, file.name + ".disabled")
            file.renameTo(target)
        }
    }

    fun delete(file: File) {
        file.delete()
        removeFromIndex(file.name)
    }

    fun backup(dest: File): File {
        val out = File(dest, "mods-backup-${System.currentTimeMillis()}.zip")
        java.util.zip.ZipOutputStream(dest.outputStream().let { java.io.FileOutputStream(out) }).use { zos ->
            (list() + disabledFiles()).forEach { f ->
                zos.putNextEntry(java.util.zip.ZipEntry(f.name))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
        return out
    }

    fun restore(zip: File) {
        Fs.unzipStream(zip.inputStream(), modsDir)
    }

    fun disabledFiles(): List<File> = modsDir.listFiles()?.filter { it.name.endsWith(".disabled") } ?: emptyList()

    private fun recordIndex(file: File, ref: ModrinthApi.FileRef?) {
        val arr = JSONArray(Fs.readText(indexFile).ifEmpty { "[]" })
        val obj = JSONObject()
            .put("file", file.name)
            .put("size", file.length())
            .put("added", System.currentTimeMillis())
        ref?.let {
            obj.put("slug", it.filename.substringBefore('-'))
                .put("versionId", it.versionId)
                .put("mcVersions", JSONArray(it.gameVersions))
                .put("loaders", JSONArray(it.loaders))
        }
        arr.put(obj)
        Fs.writeText(indexFile, arr.toString())
    }

    private fun removeFromIndex(name: String) {
        val arr = runCatching { JSONArray(Fs.readText(indexFile).ifEmpty { "[]" }) }.getOrDefault(JSONArray())
        val out = JSONArray()
        (0 until arr.length()).forEach { i ->
            val o = arr.optJSONObject(i) ?: return@forEach
            if (o.optString("file") != name) out.put(o)
        }
        Fs.writeText(indexFile, out.toString())
    }
}

/**
 * Installs mod loaders by fetching the loader's own version manifest and jar list.
 *
 *  Fabric   : https://meta.fabricmc.net/v2/versions/loader/<mc>/<loader>/profile/json
 *             (returns a standard launcher profile JSON; Apache-2.0/CDDL tooling)
 *  Quilt    : https://meta.quiltmc.org/v3/versions/loader/<mc>/<loader>/profile/json
 *  NeoForge : https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge
 *  Forge    : https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json
 *             (installer is run inside the JVM the same way the game is)
 */
class LoaderInstaller(private val context: Context, private val profileDir: String = "default") {

    suspend fun fabricProfile(mcVersion: String, loaderVersion: String = "latest"): JSONObject {
        val lv = if (loaderVersion == "latest") {
            val arr = JSONArray(Net.text("https://meta.fabricmc.net/v2/versions/loader"))
            arr.getJSONObject(0).getString("version")
        } else loaderVersion
        val json = Net.text("https://meta.fabricmc.net/v2/versions/loader/$mcVersion/$lv/profile/json")
        return JSONObject(json)
    }

    suspend fun fabricLoaderVersions(): List<String> {
        val arr = JSONArray(Net.text("https://meta.fabricmc.net/v2/versions/loader"))
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("version") }
    }

    suspend fun quiltProfile(mcVersion: String, loaderVersion: String = "latest"): JSONObject {
        val lv = if (loaderVersion == "latest") {
            val arr = JSONArray(Net.text("https://meta.quiltmc.org/v3/versions/loader"))
            arr.getJSONObject(0).getString("version")
        } else loaderVersion
        return JSONObject(Net.text("https://meta.quiltmc.org/v3/versions/loader/$mcVersion/$lv/profile/json"))
    }

    suspend fun neoForgeVersions(mcVersion: String): List<String> {
        val raw = Net.text("https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge")
        val arr = JSONObject(raw).optJSONArray("versions") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optString(it) }.filter { it.startsWith(mcVersion) }.reversed()
    }

    suspend fun forgePromotions(): JSONObject = Net.json("https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json")

    suspend fun downloadForgeInstaller(mcVersion: String, forgeVersion: String, onProgress: (Long, Long) -> Unit): File {
        val build = "$mcVersion-$forgeVersion"
        val url = "https://maven.minecraftforge.net/net/minecraftforge/forge/$build/forge-$build-installer.jar"
        val dest = File(Fs.dir(context, "loaders", profileDir), "forge-$build-installer.jar")
        Net.downloadToFile(url, dest) { r, t -> onProgress(r, t) }
        return dest
    }

    suspend fun downloadNeoForgeInstaller(mcVersion: String, neoVersion: String, onProgress: (Long, Long) -> Unit): File {
        val url = "https://maven.neoforged.net/releases/net/neoforged/neoforge/$neoVersion/neoforge-$neoVersion-installer.jar"
        val dest = File(Fs.dir(context, "loaders", profileDir), "neoforge-$neoVersion-installer.jar")
        Net.downloadToFile(url, dest) { r, t -> onProgress(r, t) }
        return dest
    }

    /**
     * Loader installers are Java programs: we run them inside the launcher's JVM the same
     * way we run the game, writing into the profile's game directory.
     */
    fun runInstaller(jvmHome: File, installer: File, gameDir: File, onLog: (String) -> Unit) {
        val cmd = mutableListOf(
            File(jvmHome, "bin/java").absolutePath,
            "-jar", installer.absolutePath,
            "--installClient", gameDir.absolutePath,
        )
        val pb = ProcessBuilder(cmd).directory(gameDir).redirectErrorStream(true)
        pb.environment()["JAVA_HOME"] = jvmHome.absolutePath
        val p = pb.start()
        p.inputStream.bufferedReader().useLines { onLog(it) }
        p.waitFor()
    }

    /** Writes the version manifest entry so the launcher can select the loader version. */
    fun saveLoaderProfile(mcVersion: String, loader: com.cplauncher.plus.data.model.Loader, profileJson: JSONObject): File {
        val dir = File(Fs.gameRoot(context, profileDir), "versions/${loader.name.lowercase()}-$mcVersion").apply { mkdirs() }
        val f = File(dir, "${loader.name.lowercase()}-$mcVersion.json")
        Fs.writeText(f, profileJson.toString())
        return f
    }
}
