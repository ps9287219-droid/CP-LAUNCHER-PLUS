package com.cplauncher.plus.core.util

import android.content.Context
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.utils.IOUtils
import org.tukaani.xz.XZInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

/** Filesystem helpers rooted at the launcher's private game directory. */
object Fs {
    const val ROOT = "games"
    const val RUNTIMES = "runtimes"
    const val MODS = "mods"
    const val SHADERS = "shaderpacks"
    const val RESOURCE_PACKS = "resourcepacks"
    const val SKINS = "skins"
    const val LOGS = "logs"
    const val CRASH = "crash-reports"

    fun gameRoot(ctx: Context, profileDir: String = "default"): File =
        File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "$ROOT/$profileDir").apply { mkdirs() }

    fun baseDir(ctx: Context): File =
        (ctx.getExternalFilesDir(null) ?: ctx.filesDir).apply { mkdirs() }

    fun runtimeDir(ctx: Context, id: String): File =
        File(baseDir(ctx), "$RUNTIMES/$id").apply { mkdirs() }

    fun dir(ctx: Context, name: String, profileDir: String = "default"): File =
        File(gameRoot(ctx, profileDir), name).apply { mkdirs() }

    fun dirSize(f: File): Long = if (f.isFile) f.length() else f.walkBottomUp().filter { it.isFile }.sumOf { it.length() }

    fun deleteRecursive(f: File?) {
        if (f == null || !f.exists()) return
        if (f.isDirectory) f.listFiles()?.forEach { deleteRecursive(it) }
        f.delete()
    }

    fun readText(f: File): String = if (f.exists()) f.readText() else ""

    fun writeText(f: File, content: String) {
        f.parentFile?.mkdirs()
        f.writeText(content)
    }

    /** Extract a `.tar.xz` archive (OpenJDK/JRE builds are shipped this way). */
    fun extractTarXz(archive: File, destination: File, stripRoot: Boolean = true) {
        destination.mkdirs()
        XZInputStream(FileInputStream(archive)).use { xz ->
            TarArchiveInputStream(xz).use { tar ->
                var entry: TarArchiveEntry? = tar.nextTarEntry as TarArchiveEntry?
                var firstSeen = true
                while (entry != null) {
                    var name = entry.name
                    if (stripRoot && firstSeen && name.startsWith("./") || name.startsWith("/")) {
                        // strip the leading directory component (e.g. `jdk-17.0.9+9/`)
                        name = name.substringAfter('/' , "")
                    }
                    firstSeen = false
                    if (name.isBlank()) {
                        entry = tar.nextTarEntry as TarArchiveEntry?
                        continue
                    }
                    val out = File(destination, name)
                    val canonical = destination.canonicalFile.path
                    if (!out.canonicalPath.startsWith(canonical)) {
                        throw IOException("Blocked zip-slip entry: " + entry.name)
                    }
                    if (entry.isDirectory) out.mkdirs()
                    else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { IOUtils.copy(tar, it) }
                        // Preserve the executable bit from the tar entry
                        val mode = entry.mode
                        if (mode and 0b001000000 != 0) out.setExecutable(true, false)
                    }
                    entry = tar.nextTarEntry as TarArchiveEntry?
                }
            }
        }
    }

    /** Extract a zip, optionally only entries matching a prefix, into destination. */
    fun extractZip(archive: File, destination: File, prefix: String = "", flatten: Boolean = false) {
        destination.mkdirs()
        ZipFile(archive).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val e = entries.nextElement() as ZipEntry
                if (!e.name.startsWith(prefix)) continue
                val rel = e.name.removePrefix(prefix).trimStart('/')
                if (rel.isBlank()) continue
                val out = File(destination, if (flatten) rel.substringAfterLast('/') else rel)
                if (!out.canonicalPath.startsWith(destination.canonicalFile.path)) continue
                if (e.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    zip.getInputStream(e).use { input -> FileOutputStream(out).use { input.copyTo(it) } }
                }
            }
        }
    }

    fun unzipStream(stream: java.io.InputStream, destination: File) {
        destination.mkdirs()
        ZipInputStream(stream.buffered()).use { zis ->
            var e: ZipEntry? = zis.nextEntry
            while (e != null) {
                val out = File(destination, e.name)
                if (!out.canonicalPath.startsWith(destination.canonicalFile.path)) {
                    e = zis.nextEntry; continue
                }
                if (e.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zis.copyTo(it) }
                }
                zis.closeEntry()
                e = zis.nextEntry
            }
        }
    }
}
