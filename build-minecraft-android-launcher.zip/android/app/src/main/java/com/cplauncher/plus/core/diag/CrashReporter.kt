package com.cplauncher.plus.core.launch

import android.content.Context
import android.os.Build
import com.cplauncher.plus.core.util.Fs
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Writes human-readable crash/diagnostic reports into games/<profile>/crash-reports. */
object CrashReporter {

    fun writeCrashReport(
        context: Context,
        mcVersion: String,
        exit: JvmBridge.ExitInfo?,
        logs: List<String>,
    ): File {
        val dir = Fs.dir(context, Fs.CRASH)
        val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
        val f = File(dir, "cplauncher-$stamp.txt")
        val tail = logs.takeLast(120).joinToString("\n")

        f.writeText(
            """
            |CP Launcher Plus — crash report
            |Time: ${Date()}
            |Minecraft: $mcVersion
            |Device: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT})
            |ABI: ${Build.SUPPORTED_ABIS.joinToString(", ")}
            |Runtime: ART ${System.getProperty("java.vm.version")}
            |
            |Exit code: ${exit?.exitCode}
            |Duration: ${exit?.durationMs} ms
            |Summary: ${exit?.message}
            |
            |--- common causes -------------------------------------------------
            | * exit -1001/-1003 : OpenJDK runtime missing or ABI mismatch (need arm64/x86_64)
            | * UnsatisfiedLinkError in lwjgl : natives dir incomplete — re-install version
            | * OutOfMemoryError : lower "Memory limit" in Performance
            | * GL errors : switch renderer (gl4es ↔ ANGLE/Zink) in Settings
            |
            |--- last log lines -------------------------------------------------
            $tail
            """.trimMargin(),
        )
        return f
    }

    fun installDefaultHandler(context: Context) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching {
                val dir = Fs.dir(context, Fs.LOGS)
                val f = File(dir, "launcher-uncaught-${System.currentTimeMillis()}.log")
                f.writeText(
                    "Thread: ${thread.name}\n" +
                        android.util.Log.getStackTraceString(throwable),
                )
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    fun list(context: Context): List<File> {
        val dir = Fs.dir(context, Fs.CRASH)
        val logs = Fs.dir(context, Fs.LOGS)
        return (dir.listFiles()?.toList() ?: emptyList()) + (logs.listFiles()?.toList() ?: emptyList())
    }

    fun clear(context: Context) {
        list(context).forEach { it.delete() }
    }

    /** Diagnostic bundle used by the "Export diagnostics" button. */
    fun exportBundle(context: Context, settings: String, accounts: String): File {
        val dir = Fs.dir(context, Fs.LOGS)
        val f = File(dir, "diagnostics-${System.currentTimeMillis()}.txt")
        f.writeText(
            buildString {
                appendLine("CP Launcher Plus diagnostics")
                appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL} / Android ${Build.VERSION.RELEASE}")
                appendLine("ABIs: ${Build.SUPPORTED_ABIS.joinToString()}")
                appendLine("Total RAM (MB): ${totalRamMb()}")
                appendLine()
                appendLine("--- settings ---")
                appendLine(settings)
                appendLine("--- account summary (no tokens) ---")
                appendLine(accounts)
                appendLine("--- crash reports ---")
                list(context).forEach { appendLine(it.name) }
            },
        )
        return f
    }

    fun totalRamMb(context: Context): Long {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
            ?: return 0L
        val mi = android.os.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.totalMem / (1024 * 1024)
    }
}
