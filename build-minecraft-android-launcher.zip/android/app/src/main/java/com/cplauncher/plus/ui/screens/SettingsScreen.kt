package com.cplauncher.plus.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cplauncher.plus.LauncherViewModel
import com.cplauncher.plus.ui.common.CpCard
import com.cplauncher.plus.ui.common.SectionTitle
import com.cplauncher.plus.ui.common.SettingRow
import com.cplauncher.plus.ui.common.SliderRow
import com.cplauncher.plus.ui.common.SwitchRow

@Composable
fun SettingsScreen(vm: LauncherViewModel, onOpen: (String) -> Unit = {}) {
    val settings by vm.settings.collectAsState()
    val caps by vm.capabilities.collectAsState()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        SectionTitle("Settings")

        CpCard {
            Text("Appearance", style = MaterialTheme.typography.titleMedium)
            Row {
                listOf("dark" to "Dark", "light" to "Light", "amoled" to "AMOLED", "system" to "System").forEach { (id, label) ->
                    FilterChip(selected = settings.themeMode == id, onClick = { vm.setSettings { it.copy(themeMode = id) } }, label = { Text(label) })
                }
            }
            Spacer(Modifier.height(6.dp))
            Row {
                listOf("emerald" to "Emerald", "lime" to "Lime", "teal" to "Teal", "violet" to "Violet", "amber" to "Amber").forEach { (id, label) ->
                    FilterChip(selected = settings.accent == id, onClick = { vm.setSettings { it.copy(accent = id) } }, label = { Text(label) })
                }
            }
            Spacer(Modifier.height(6.dp))
            SwitchRow("Animations", "Motion effects in the launcher UI", settings.animations) { vm.setSettings { s -> s.copy(animations = it) } }
            SwitchRow("Notifications", "Session and download notifications", settings.notifications) { vm.setSettings { s -> s.copy(notifications = it) } }
        }

        Spacer(Modifier.height(12.dp))
        CpCard {
            Text("Game directory & storage", style = MaterialTheme.typography.titleMedium)
            SettingRow("Game root", "games/default inside the app's external files directory")
            SettingRow("Mods folder", "games/default/mods")
            SettingRow("Shader packs", "games/default/shaderpacks")
            SettingRow("Resource packs", "games/default/resourcepacks")
            Spacer(Modifier.height(6.dp))
            Row {
                AssistChip(onClick = { onOpen("runtimes") }, label = { Text("Manage runtimes") })
                AssistChip(onClick = { onOpen("diagnostics") }, label = { Text("Crash logs") })
            }
        }

        Spacer(Modifier.height(12.dp))
        CpCard {
            Text("Java & JVM", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = settings.jvmArgs,
                onValueChange = { vm.setSettings { s -> s.copy(jvmArgs = it) } },
                label = { Text("Extra JVM arguments") },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
            SliderRow("Initial heap (-Xms)", settings.minMemoryMb.toFloat(), 256f..(settings.maxMemoryMb.toFloat()), format = { "${it.toInt()} MB" }) {
                vm.setSettings { s -> s.copy(minMemoryMb = it.toInt()) }
            }
            Text(
                "Applied on the next launch. Unsafe flags are passed through as-is — invalid options will make the JVM exit immediately and the crash log will say so.",
                style = MaterialTheme.typography.bodySmall,
            )
        }

        Spacer(Modifier.height(12.dp))
        CpCard {
            Text("Downloads", style = MaterialTheme.typography.titleMedium)
            SliderRow("Parallel downloads", settings.concurrentDownloads.toFloat(), 1f..8f, steps = 6, format = { "${it.toInt()}×" }) {
                vm.setSettings { s -> s.copy(concurrentDownloads = it.toInt()) }
            }
            SwitchRow("Auto-update version list", "Refreshes Mojang's manifest every 24h", settings.autoUpdateVersions) {
                vm.setSettings { s -> s.copy(autoUpdateVersions = it) }
            }
            SwitchRow("Retry failed downloads", "Checksum failures are re-fetched", settings.retryFailedDownloads) {
                vm.setSettings { s -> s.copy(retryFailedDownloads = it) }
            }
        }

        Spacer(Modifier.height(12.dp))
        CpCard {
            Text("Privacy", style = MaterialTheme.typography.titleMedium)
            SwitchRow("Discord presence", "Off by default — see the Discord screen for what is actually possible on Android", settings.discordPresence) {
                vm.setSettings { s -> s.copy(discordPresence = it) }
            }
            SwitchRow("Share diagnostics", "Nothing leaves the device unless you enable this", settings.telemetry) {
                vm.setSettings { s -> s.copy(telemetry = it) }
            }
            Text("Tokens are stored in Android Keystore-encrypted preferences. Passwords are never requested.", style = MaterialTheme.typography.bodySmall)
        }

        Spacer(Modifier.height(12.dp))
        CpCard {
            Text("Diagnostics", style = MaterialTheme.typography.titleMedium)
            Row {
                Button(onClick = { onOpen("diagnostics") }) { Text("Open logs") }
                Spacer(Modifier.height(0.dp))
                OutlinedButton(onClick = { onOpen("settings") }) { Text("Reset defaults") }
            }
            Text("Device: ${caps?.abi} · ${caps?.totalRamMb} MB RAM", style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(24.dp))
    }
}
