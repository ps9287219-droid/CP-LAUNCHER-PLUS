package com.cplauncher.plus.core.launch

import android.util.Log
import java.io.File

/**
 * Bridges the launcher process to a real JVM.
 *
 * Two strategies exist on Android:
 *
 *  1. IN-PROCESS (default) — dlopen() libjvm.so from the extracted OpenJDK and call
 *     JNI_CreateJavaVM. This is how PojavLauncher and its forks work, because Android 10+
 *     blocks exec() of files inside an app's private data directory
 *     (SELinux `untrusted_app` noexec on /data). The native side lives in
 *     `app/src/main/cpp/cp_jvm.c`.
 *
 *  2. SUBPROCESS — spawn `$JAVA_HOME/bin/java`. Only works on rooted devices, older
 *     Android (<=9) or when targetSdk <= 28 keeps the legacy exec allowance.
 *     It is offered as a diagnostic path so users can compare logs.
 */
object JvmBridge {

    enum class Mode { IN_PROCESS, SUBPROCESS }

    const val NATIVE_LIB = "cp_jvm"

    init {
        runCatching { System.loadLibrary(NATIVE_LIB) }
            .onFailure { Log.e("JvmBridge", "Native bridge missing — in-process launch disabled", it) }
    }

    fun isNativeAvailable(): Boolean = runCatching {
        System.loadLibrary(NATIVE_LIB)
        true
    }.isSuccess

    /** Result of a launch attempt. Never optimistic — it reports reality. */
    data class ExitInfo(
        val exitCode: Int,
        val crashed: Boolean,
        val message: String,
        val durationMs: Long,
    )

    // ---------------------------------------------------------------- in-process

    /**
     * Blocking call executed on a dedicated thread:
     * creates the VM, attaches the current thread and invokes `mainClass.main(args)`.
     * Returns when the JVM returns (i.e. when Minecraft exits).
     */
    fun startInProcess(
        jvmHome: File,
        jvmArgs: Array<String>,
        mainClass: String,
        gameArgs: Array<String>,
        env: Map<String, String>,
        nativesDir: File,
        onLog: (String) -> Unit,
    ): ExitInfo {
        val started = System.currentTimeMillis()
        val code = nativeLaunch(
            jvmHome.absolutePath,
            nativesDir.absolutePath,
            env.entries.joinToString("\n") { "${it.key}=${it.value}" },
            jvmArgs,
            mainClass,
            gameArgs,
        )
        val ms = System.currentTimeMillis() - started
        return ExitInfo(
            exitCode = code,
            crashed = code != 0,
            message = if (code == 0) "Minecraft exited normally" else "JVM returned exit code $code (see crash log)",
            durationMs = ms,
        )
    }

    private external fun nativeLaunch(
        jvmHome: String,
        nativesDir: String,
        envBlock: String,
        jvmArgs: Array<String>,
        mainClass: String,
        gameArgs: Array<String>,
    ): Int

    /** Called from C++ when Minecraft writes to stdout/stderr. */
    @JvmStatic
    fun onNativeLog(line: String) {
        SessionEventBus.publish(line)
    }

    // ---------------------------------------------------------------- subprocess

    fun startSubprocess(
        javaBinary: File,
        jvmArgs: List<String>,
        mainClass: String,
        gameArgs: List<String>,
        env: Map<String, String>,
        workDir: File,
        onLog: (String) -> Unit,
    ): ExitInfo {
        val started = System.currentTimeMillis()
        require(javaBinary.exists()) { "java binary not found at ${javaBinary.path}" }
        javaBinary.setExecutable(true, false)

        val cmd = mutableListOf(javaBinary.absolutePath).apply {
            addAll(jvmArgs)
            add(mainClass)
            addAll(gameArgs)
        }
        val pb = ProcessBuilder(cmd).directory(workDir).redirectErrorStream(true)
        val environment = pb.environment()
        environment.putAll(env)

        val process = try {
            pb.start()
        } catch (e: Throwable) {
            return ExitInfo(-1, true, "exec() blocked by Android SELinux policy: ${e.message}", 0)
        }
        process.inputStream.bufferedReader().useLines { lines ->
            lines.forEach { onLog(it) }
        }
        val code = process.waitFor()
        val ms = System.currentTimeMillis() - started
        return ExitInfo(code, code != 0, if (code == 0) "Minecraft exited normally" else "Exit code $code", ms)
    }
}

/** Tiny process-wide bus so the UI (and Discord/playtime trackers) can follow game logs. */
object SessionEventBus {
    private val listeners = mutableListOf<(String) -> Unit>()

    fun subscribe(l: (String) -> Unit) {
        synchronized(listeners) { listeners.add(l) }
    }

    fun unsubscribe(l: (String) -> Unit) {
        synchronized(listeners) { listeners.remove(l) }
    }

    fun publish(line: String) {
        synchronized(listeners) { listeners.forEach { runCatching { it(line) } } }
    }
}
