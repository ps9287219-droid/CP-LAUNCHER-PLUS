package com.cplauncher.plus.core.versions

import android.content.Context
import com.cplauncher.plus.core.util.Fs
import com.cplauncher.plus.core.util.Net
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/**
 * Installs everything a Minecraft Java version needs:
 *   client jar  -> games/<profile>/versions/<id>/<id>.jar
 *   libraries   -> games/<profile>/libraries/<maven path>
 *   assets      -> games/<profile>/assets/objects/<xx>/<hash>
 *   natives     -> games/<profile>/versions/<id>/natives
 */
class VersionInstaller(private val context: Context, private val profileDir: String) {

    private val root get() = Fs.gameRoot(context, profileDir)

    data class InstallProgress(val label: String, val done: Int, val total: Int, val bytes: Long, val totalBytes: Long)

    suspend fun install(resolved: ResolvedVersion, onProgress: (InstallProgress) -> Unit): File =
        withContext(Dispatchers.IO) {
            val versionDir = File(root, "versions/${resolved.id}").apply { mkdirs() }
            val libDir = File(root, "libraries")
            val assetsDir = File(root, "assets")
            val versionJson = File(versionDir, "${resolved.id}.json")

            Fs.writeText(versionJson, resolveRawJson(resolved.id) ?: "{}")

            // 1) client jar -------------------------------------------------------
            val clientJar = File(versionDir, "${resolved.id}.jar")
            if (!clientJar.exists() || clientJar.length() != resolved.clientSize) {
                onProgress(InstallProgress("Downloading client ${resolved.id}", 0, 1, 0, resolved.clientSize))
                Net.downloadToFile(resolved.clientUrl, clientJar) { r, t -> onProgress(InstallProgress("Downloading client", 1, 1, r, t)) }
                verify(clientJar, resolved.clientSha1)
            }

            // 2) libraries --------------------------------------------------------
            val applicable = resolved.libraries.filter { it.appliesToAndroid }
            val totalBytes = applicable.sumOf { it.size }
            var doneBytes = 0L
            var index = 0
            coroutineScope {
                val sem = kotlinx.coroutines.sync.Semaphore(concurrency)
                applicable.map { lib ->
                    async {
                        sem.withPermit {
                            val target = File(libDir, lib.path)
                            if (!target.exists() || (lib.size > 0 && target.length() != lib.size)) {
                                Net.downloadToFile(lib.url, target) { _, _ -> }
                                verify(target, lib.sha1)
                            }
                            synchronized(index) {
                                index++
                                doneBytes += lib.size
                                onProgress(InstallProgress("Libraries (${lib.name.substringAfterLast(':')})", index, applicable.size, doneBytes, totalBytes))
                            }
                        }
                    }
                }.awaitAll()
            }

            // 3) asset index + assets --------------------------------------------
            val assetIndexFile = File(assetsDir, "indexes/${resolved.assetsIndexId}.json")
            val indexJson = JSONObject(Net.text(resolved.assetIndexUrl))
            Fs.writeText(assetIndexFile, indexJson.toString())

            val objects = indexJson.optJSONObject("objects") ?: JSONObject()
            val keys = objects.keys().asSequence().toList()
            val virtualAssets = indexJson.optBoolean("virtual", false)
            var assetDone = 0
            coroutineScope {
                val sem = kotlinx.coroutines.sync.Semaphore(concurrency)
                keys.map { key ->
                    async {
                        sem.withPermit {
                            val o = objects.getJSONObject(key)
                            val hash = o.getString("hash")
                            val sub = hash.substring(0, 2)
                            val target = File(assetsDir, "objects/$sub/$hash")
                            if (!target.exists() || target.length() != o.optLong("size", -1L)) {
                                val url = "https://resources.download.minecraft.net/$sub/$hash"
                                runCatching { Net.downloadToFile(url, target) { _, _ -> } }
                            }
                            if (virtualAssets) {
                                val virt = File(assetsDir, "virtual/legacy/$key")
                                if (!virt.exists()) {
                                    virt.parentFile?.mkdirs()
                                    target.copyTo(virt, overwrite = true)
                                }
                            }
                            synchronized(assetDone) {
                                assetDone++
                                onProgress(InstallProgress("Assets ($key)", assetDone, keys.size, assetDone.toLong(), keys.size.toLong()))
                            }
                        }
                    }
                }.awaitAll()
            }

            // 4) natives ----------------------------------------------------------
            val nativesDir = File(versionDir, "natives").apply { mkdirs() }
            applicable.filter { it.nativeClassifier != null }.forEach { lib ->
                val nativeUrl = "https://libraries.minecraft.net/${lib.nativeClassifier}"
                val zip = File(versionDir, "natives/${lib.nativeClassifier.substringAfterLast('/')}")
                if (!zip.exists()) Net.downloadToFile(nativeUrl, zip) { _, _ -> }
                Fs.extractZip(zip, nativesDir)
            }

            clientJar
        }

    private suspend fun resolveRawJson(id: String): String? = runCatching {
        val versions = VersionManifest(context).refresh(false)
        versions.firstOrNull { it.id == id }?.let { Net.text(it.url) }
    }.getOrNull()

    private fun verify(file: File, sha1: String) {
        if (sha1.isBlank()) return
        val md = MessageDigest.getInstance("SHA-1")
        file.inputStream().use { input ->
            val buf = ByteArray(65536)
            var n: Int
            while (input.read(buf).also { n = it } != -1) md.update(buf, 0, n)
        }
        val actual = md.digest().joinToString("") { "%02x".format(it) }
        check(actual == sha1) { "Checksum mismatch for ${file.name} ($actual != $sha1)" }
    }

    var concurrency: Int = 4

    private suspend fun kotlinx.coroutines.sync.Semaphore.withPermit(block: suspend () -> Unit) {
        acquire()
        try {
            block()
        } finally {
            release()
        }
    }
}
