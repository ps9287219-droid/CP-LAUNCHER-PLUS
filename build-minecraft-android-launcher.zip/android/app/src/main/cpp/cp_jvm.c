/*
 * CP Launcher Plus — Android JVM bridge.
 *
 * Loads an Android OpenJDK (PojavLauncherTeam builds, GPLv2+CE) inside the launcher
 * process and invokes the Minecraft main class. Android 10+ forbids exec() of
 * binaries stored in an app's data directory, so in-process dlopen is the only
 * reliable route on modern devices.
 *
 * Build: CMake + NDK. Output: libcplauncher_jvm.so
 */
#include <jni.h>
#include <dlfcn.h>
#include <pthread.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <android/log.h>

#define LOG_TAG "CPJvmBridge"
#define ALOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define ALOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

typedef jint (*JNI_CreateJavaVM_t)(JavaVM **, JNIEnv **, void *);

static JavaVM *g_vm = NULL;
static JNIEnv *g_env = NULL;

/* Java callback: com.cplauncher.plus.core.launch.JvmBridge.onNativeLog(String) */
static void jni_log_to_java(JNIEnv *env, const char *line) {
    if (env == NULL || g_vm == NULL) return;
    jclass cls = (*env)->FindClass(env, "com/cplauncher/plus/core/launch/JvmBridge");
    if (cls == NULL) { (*env)->ExceptionClear(env); return; }
    jmethodID mid = (*env)->GetStaticMethodID(env, cls, "onNativeLog", "(Ljava/lang/String;)V");
    if (mid == NULL) { (*env)->ExceptionClear(env); return; }
    jstring str = (*env)->NewStringUTF(env, line);
    (*env)->CallStaticVoidMethod(env, cls, mid, str);
    (*env)->DeleteLocalRef(env, str);
    (*env)->DeleteLocalRef(env, cls);
}

/* stdout/stderr tee -> launcher log screen */
static void *stderr_pump(void *arg) {
    int fd = (int) (intptr_t) arg;
    char buf[1024];
    ssize_t n;
    FILE *fp = fdopen(dup(fd), "r");
    if (fp == NULL) return NULL;
    while ((n = fread(buf, 1, sizeof(buf) - 1, fp)) > 0) {
        buf[n] = '\0';
        ALOGI("%s", buf);
        JNIEnv *env;
        if ((*g_vm)->AttachCurrentThread(g_vm, &env, NULL) == JNI_OK) {
            jni_log_to_java(env, buf);
        }
    }
    fclose(fp);
    return NULL;
}

static int set_env_from_block(const char *block) {
    if (block == NULL) return 0;
    char *copy = strdup(block);
    char *line = strtok(copy, "\n");
    while (line != NULL) {
        char *eq = strchr(line, '=');
        if (eq != NULL) {
            *eq = '\0';
            setenv(line, eq + 1, 1);
        }
        line = strtok(NULL, "\n");
    }
    free(copy);
    return 0;
}

JNIEXPORT jint JNICALL
Java_com_cplauncher_plus_core_launch_JvmBridge_nativeLaunch(
        JNIEnv *env, jclass clazz,
        jstring jvmHome, jstring nativesDir, jstring envBlock,
        jobjectArray jvmArgs, jstring mainClass, jobjectArray gameArgs) {

    const char *home = (*env)->GetStringUTFChars(env, jvmHome, NULL);
    const char *natives = (*env)->GetStringUTFChars(env, nativesDir, NULL);
    const char *envs = envBlock ? (*env)->GetStringUTFChars(env, envBlock, NULL) : NULL;
    const char *cls = (*env)->GetStringUTFChars(env, mainClass, NULL);

    ALOGI("Launching JVM from %s (natives=%s)", home, natives);

    set_env_from_block(envs);
    setenv("JAVA_HOME", home, 1);
    setenv("LD_LIBRARY_PATH", natives, 1);

    char libjvm[1024];
    const char *candidates[] = {"%s/lib/server/libjvm.so", "%s/lib/client/libjvm.so", "%s/lib/libjvm.so"};
    void *handle = NULL;
    for (size_t i = 0; i < 3 && handle == NULL; i++) {
        snprintf(libjvm, sizeof(libjvm), candidates[i], home);
        handle = dlopen(libjvm, RTLD_NOW | RTLD_GLOBAL);
        if (handle == NULL) ALOGE("dlopen(%s) failed: %s", libjvm, dlerror());
    }
    if (handle == NULL) {
        ALOGE("libjvm.so could not be loaded — runtime not installed or ABI mismatch");
        return -1001;
    }

    JNI_CreateJavaVM_t create = (JNI_CreateJavaVM_t) dlsym(handle, "JNI_CreateJavaVM");
    if (create == NULL) {
        ALOGE("JNI_CreateJavaVM symbol missing: %s", dlerror());
        return -1002;
    }

    int jvmArgc = (*env)->GetArrayLength(env, jvmArgs);
    JavaVMOption *options = malloc(sizeof(JavaVMOption) * (jvmArgc + 4));
    int count = 0;
    for (int i = 0; i < jvmArgc; i++) {
        jstring s = (jstring) (*env)->GetObjectArrayElement(env, jvmArgs, i);
        const char *c = (*env)->GetStringUTFChars(env, s, NULL);
        options[count++].optionString = strdup(c);
        (*env)->ReleaseStringUTFChars(env, s, c);
    }
    options[count++].optionString = strdup("-Djava.awt.headless=true");
    options[count++].optionString = strdup("-Dandroid=true");

    JavaVMInitArgs vm_args;
    memset(&vm_args, 0, sizeof(vm_args));
    vm_args.version = JNI_VERSION_1_6;
    vm_args.nOptions = count;
    vm_args.options = options;
    vm_args.ignoreUnrecognized = JNI_TRUE;

    jint rc = create(&g_vm, &g_env, &vm_args);
    if (rc != JNI_OK) {
        ALOGE("JNI_CreateJavaVM failed: %d", rc);
        return -1003;
    }
    ALOGI("JVM created (options=%d)", count);

    /* Thread the JVM stdout/stderr into the launcher log view. */
    pthread_t pump;
    pthread_create(&pump, NULL, stderr_pump, (void *) (intptr_t) fileno(stderr));

    const char *main_name = cls;
    if (strchr(main_name, '/') == NULL && strchr(main_name, '.') != NULL) {
        char *dotted = strdup(main_name);
        for (char *p = dotted; *p; p++) if (*p == '.') *p = '/';
        main_name = dotted;
    }

    jclass mainCls = (*g_env)->FindClass(g_env, main_name);
    if (mainCls == NULL) {
        (*g_env)->ExceptionDescribe(g_env);
        (*g_env)->ExceptionClear(g_env);
        ALOGE("Main class not found: %s", main_name);
        return -1004;
    }
    jmethodID mainMid = (*g_env)->GetStaticMethodID(g_env, mainCls, "main", "([Ljava/lang/String;)V");
    if (mainMid == NULL) {
        (*g_env)->ExceptionClear(g_env);
        ALOGE("main(String[]) not found on %s", main_name);
        return -1005;
    }

    int gameArgc = (*env)->GetArrayLength(env, gameArgs);
    jobjectArray argsArr = (*g_env)->NewObjectArray(g_env, gameArgc, (*g_env)->FindClass(g_env, "java/lang/String"), NULL);
    for (int i = 0; i < gameArgc; i++) {
        jobject o = (*env)->GetObjectArrayElement(env, gameArgs, i);
        (*g_env)->SetObjectArrayElement(g_env, argsArr, i, o);
    }

    ALOGI("Invoking %s.main(%d args)", cls, gameArgc);
    (*g_env)->CallStaticVoidMethod(g_env, mainCls, mainMid, argsArr);

    if ((*g_env)->ExceptionCheck(g_env)) {
        (*g_env)->ExceptionDescribe(g_env);
        (*g_env)->ExceptionClear(g_env);
        return -1006;
    }

    (*g_vm)->DetachCurrentThread(g_vm);
    ALOGI("Minecraft main() returned");

    free(options);
    (*env)->ReleaseStringUTFChars(env, jvmHome, home);
    (*env)->ReleaseStringUTFChars(env, nativesDir, natives);
    if (envs) (*env)->ReleaseStringUTFChars(env, envBlock, envs);
    (*env)->ReleaseStringUTFChars(env, mainClass, cls);
    return 0;
}

JNIEXPORT void JNICALL
Java_com_cplauncher_plus_core_launch_JvmBridge_requestExit(JNIEnv *env, jclass clazz) {
    if (g_vm != NULL) (*g_vm)->DestroyJavaVM(g_vm);
    g_vm = NULL;
}
