# CP-LAUNCHER-PLUS — Android Minecraft Java launcher

Kotlin + Jetpack Compose launcher for Minecraft: Java Edition on Android (arm64-v8a / x86_64).

## Build

```bash
# 1. JDK 17 + Android SDK 35 (or just let GitHub Actions do it)
cd android
gradle :app:assembleDebug        # debug APK
gradle :app:assembleRelease      # release APK (signed with the debug key)
```

CI: `.github/workflows/android-build.yml` builds both and uploads them as artifacts, and attaches
them to a GitHub release on `main`. `MS_CLIENT_ID` is an optional repo secret holding an Azure
**Public client** application id used by the Microsoft device-code sign-in flow.

## Honest feature status

### Implemented in code (needs a device/emulator to exercise end-to-end)
| Feature | Where |
|---|---|
| Version manifest + full installer (client jar, libraries, assets, natives, SHA-1 verification, parallel downloads) | `core/versions/VersionInstaller.kt`, `VersionManifest.kt` |
| Real JVM launch — in-process `JNI_CreateJavaVM` bridge (`app/src/main/cpp/cp_jvm.c`) + subprocess fallback | `core/launch/JvmBridge.kt`, `LaunchConfigurator.kt`, `GameLauncher.kt` |
| OpenJDK runtime manager for Android (GPLv2+CE builds, tar.xz extraction, executable bits) | `core/runtime/JreManager.kt` |
| Microsoft device-code OAuth → XBL → XSTS → Minecraft Services → profile + entitlement check | `core/accounts/MicrosoftAuth.kt` |
| Token storage in Android Keystore (EncryptedSharedPreferences), multi-account, switching, refresh | `core/accounts/AccountStore.kt` |
| Local/offline profiles clearly separated from authenticated accounts | `MicrosoftAuth.offlineUuid()` |
| Modrinth v2 search/download with required-dependency resolution | `core/mods/ModrinthApi.kt` |
| Real mod installation into `games/<profile>/mods`, enable/disable via `.disabled`, delete, backup/restore, duplicate-id + missing-dependency audit reading `fabric.mod.json` / `mods.toml` | `core/mods/ModManager.kt` |
| Fabric / Quilt / NeoForge / Forge loader metadata + installer download & run | `core/mods/LoaderInstaller.kt` |
| Shader + resource-pack install into the real folders, shader-capability matrix | `core/packs/PackageManager.kt`, `core/perf/RendererMatrix.kt` |
| Official skin upload (`/minecraft/profile/skins`), model detection, local skin library | `core/skins/SkinManager.kt` |
| Performance profiles, memory clamping to the device's real Java heap, thermal/RAM warnings | `core/perf/DeviceProfile.kt`, `PerformanceProfiles.kt` |
| Playtime history (per session, per day), foreground session service | `core/session/*` |
| Crash reports + diagnostic export | `core/diag/CrashReporter.kt` |
| Compose UI: Home/PLAY, Library, Mods, Packs, Performance, Customize, Accounts, Runtimes, Discord, Diagnostics, Settings; phone + tablet layouts; themes/accent switching; DataStore persistence | `ui/**`, `core/settings/SettingsRepository.kt` |

### Partially implemented
* **Discord Rich Presence** — the desktop local-IPC transport does not exist on Android. `core/discord/DiscordPresence.kt` implements a socket probe + the documented op-code protocol, a deep-link/share hand-off, and local playtime. It never reports "connected" unless a handshake succeeds.
* **Forge/NeoForge full install** — installer download and execution are implemented; the Forge installer itself still needs a native-libs post-processing step on some versions.
* **Shaders** — the chain (Iris/Oculus + Zink/Vulkan GL) is validated and the packs are installed correctly; actual rendering quality depends on the device GPU driver, which no launcher can promise.

### Not supported (and will not be faked)
* Increasing the device's physical RAM, "RAM cleaner" buttons, background-app killing.
* Rich Presence that reliably shows activity on the stock Discord Android app.
* Custom capes visible on vanilla multiplayer servers.
* Running Minecraft Java on 32-bit ABIs.
* Requesting or storing Microsoft passwords, or Discord user tokens.

## Legal
* Game files are downloaded **only** from Mojang's official endpoints (`piston-meta.mojang.com`, `resources.download.minecraft.net`) and only for versions the user already has rights to play.
* Mods come from Modrinth under their own licences; no pirated or unofficial game binaries are bundled or fetched.
* OpenJDK Android builds: OpenJDK GPLv2 with Classpath exception.
